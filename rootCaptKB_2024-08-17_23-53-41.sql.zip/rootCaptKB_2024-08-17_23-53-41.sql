-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: rootCaptKB
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(90) NOT NULL,
  `announcement` text NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category_id` tinyint(3) unsigned NOT NULL,
  `content` text NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `helpful` int(10) unsigned NOT NULL DEFAULT 0,
  `not_helpful` int(10) unsigned NOT NULL DEFAULT 0,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `visibility` tinyint(3) unsigned NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'Password okay','Testme okay',2,'<h1 style=\"text-align: center; \"><span style=\"font-size: 36px;\">Passwords are really cool and this is demo data okay :)</span></h1>','Test','Test',1,0,9,1,1699426255,1699426169);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles_categories`
--

DROP TABLE IF EXISTS `articles_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles_categories` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles_categories`
--

LOCK TABLES `articles_categories` WRITE;
/*!40000 ALTER TABLE `articles_categories` DISABLE KEYS */;
INSERT INTO `articles_categories` VALUES (1,'Test Category','test-category',NULL,'Testing the keyword','Test',1,NULL,1699426128),(2,'Testing the keyword','Test of my password',1,'Password Okay?','Password',1,NULL,1699426144);
/*!40000 ALTER TABLE `articles_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles_votes`
--

DROP TABLE IF EXISTS `articles_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles_votes`
--

LOCK TABLES `articles_votes` WRITE;
/*!40000 ALTER TABLE `articles_votes` DISABLE KEYS */;
INSERT INTO `articles_votes` VALUES (1,'174.172.110.201',1);
/*!40000 ALTER TABLE `articles_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attempts`
--

DROP TABLE IF EXISTS `attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `type` varchar(30) NOT NULL,
  `count` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `is_locked` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `attempted_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attempts`
--

LOCK TABLES `attempts` WRITE;
/*!40000 ALTER TABLE `attempts` DISABLE KEYS */;
INSERT INTO `attempts` VALUES (3,'support@rootcapture.com,','184.180.186.178','login',2,0,1662751988),(5,'admin','184.180.186.178','login',2,0,1664210715),(6,'admindemo','184.180.186.178','login',1,0,1664210721),(8,'support@rootcapture.com','72.200.103.144','login',2,0,1665252226),(9,'john','103.87.59.65','login',1,0,1689695907),(10,'ankpan','103.87.59.35','login',2,0,1694847159),(11,'admin@rootcapture.com','103.87.59.117','login',1,0,1695231845),(12,'admindemo','154.192.48.85','login',1,0,1699347818),(13,'admindemo','24.251.69.73','login',1,0,1699017931),(14,'admindemo','154.192.47.65','login',1,0,1699508543);
/*!40000 ALTER TABLE `attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_file` varchar(50) NOT NULL,
  `backup_option` tinyint(3) unsigned NOT NULL,
  `backup_action` tinyint(3) unsigned NOT NULL,
  `taken_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `canned_replies`
--

DROP TABLE IF EXISTS `canned_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `canned_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(60) NOT NULL,
  `message` text NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canned_replies`
--

LOCK TABLES `canned_replies` WRITE;
/*!40000 ALTER TABLE `canned_replies` DISABLE KEYS */;
INSERT INTO `canned_replies` VALUES (1,'Working on Issue','Hi {REQUESTER_NAME},\r\n\r\nThanks for reaching out to us. We\'ve started working on your issue and will get back to you soon.\r\n\r\nIf you have some more questions, please let us know. We\'ll be happy to help you.\r\n\r\nThanks,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627110924),(2,'Work in Progress','Hi {REQUESTER_NAME},\r\n\r\nYour issue is currently in progress. The team is working hard on it. We\'ll get back to you in [NUMBER OF HOURS] hours. Thanks for your patience.\r\n\r\nRegards,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627110988),(3,'Issue Resolved','Hi {REQUESTER_NAME},\r\n\r\nWe\'ve resolved your issue. If there is something else you need help with, please feel free to reply to this ticket or open a new one.\r\n\r\nThanks again for reaching out to us.\r\n\r\nRegards,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627111036),(4,'Going to Close','Hi {REQUESTER_NAME},\r\n\r\nThanks for taking the time to speak about {SUBJECT}.\r\n\r\nIt\'s been [NUMBER OF DAYS] days since we\'ve heard from you, so I wanted to let you know that we are going to close this ticket.\r\n\r\nPlease feel free to open a new ticket if you need any further assistance.\r\n\r\nThanks again for reaching out to us.\r\n\r\nRegards,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627111158),(5,'Requester is Angry','Hi {REQUESTER_NAME},\r\n\r\nI\'m sorry about the {SUBJECT} issue that you faced. You\'re right that it shouldn\'t take long to fix.\r\n\r\nI\'ve got our team working on your issue. I will keep you informed until we have resolved your issue.\r\n\r\nAgain, we are sorry for the inconvenience.\r\n\r\nRegards,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627111248),(6,'Header and Footer','Hi {REQUESTER_NAME},\r\n\r\nThanks for reaching out to us. [PLEASE ADD DETAILS HERE]\r\n\r\nThanks,\r\n{AGENT_NAME}\r\n{SITE_NAME} Support',NULL,1627138443);
/*!40000 ALTER TABLE `canned_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(90) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_read_assigned` int(10) unsigned NOT NULL DEFAULT 1,
  `sub_status` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `ended_by` int(10) unsigned DEFAULT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_month_year` varchar(7) NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats`
--

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chats_replies`
--

DROP TABLE IF EXISTS `chats_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chats_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chat_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `area` tinyint(3) unsigned NOT NULL DEFAULT 2,
  `replied_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats_replies`
--

LOCK TABLES `chats_replies` WRITE;
/*!40000 ALTER TABLE `chats_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `chats_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_sessions`
--

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;
INSERT INTO `ci_sessions` VALUES ('00c6848d9eb14dec1d2227f1afb351696da1675c','184.180.186.178',1662674039,'__ci_last_regenerate|i:1662674039;'),('02nejdgm2t2h5q5uvc47pd6eksp6a4al','24.251.69.73',1665588480,'__ci_last_regenerate|i:1665588480;login_redirect|s:0:\"\";'),('07ular4fmu9503gbmaifog2fdn8nugmk','174.172.110.201',1699425722,'__ci_last_regenerate|i:1699425722;z_user_token|s:85:\"4de88705b725bc0726e8c2840aa33033cbd0fd27e664b1aa7ac2b7604ab80104d52d7b26654b2c755e1ae\";'),('0s0re3bt4l5vhee22bcugd4o9enol2vr','174.172.110.201',1670720183,'__ci_last_regenerate|i:1670720183;login_redirect|s:0:\"\";'),('119f2db8da8dabf19eacf746e9a5c41f152b6011','184.180.186.178',1662684251,'__ci_last_regenerate|i:1662684251;login_redirect|s:0:\"\";'),('11d5530a4688909015fb4612bfb27c8fd712fac5','184.180.186.178',1662680198,'__ci_last_regenerate|i:1662680198;login_redirect|s:0:\"\";'),('13ffa0e71e08b29a82579291af0827ea73703c83','70.175.24.196',1662698321,'__ci_last_regenerate|i:1662698321;login_redirect|s:0:\"\";'),('14214b293488dd84a60e05b70a21160ad58776ec','2600:1011:b18e:2633:90e1:e897:9c7a:df87',1662673947,'__ci_last_regenerate|i:1662673947;login_redirect|s:0:\"\";'),('16a65feea1840f5e2d833b1519afff42b434523f','184.180.186.178',1662763212,'__ci_last_regenerate|i:1662763212;login_redirect|s:0:\"\";'),('19441a3ced660aa0fde20dbb9def3dc83890e80d','70.175.24.196',1662699830,'__ci_last_regenerate|i:1662699830;login_redirect|s:0:\"\";'),('1a6efd7b2b330ecee1c04953d2796934734e7177','70.175.24.196',1662783819,'__ci_last_regenerate|i:1662783819;login_redirect|s:0:\"\";'),('1c82168bb67a6949092d57b97626cce8ab9f432c','70.175.24.196',1662690748,'__ci_last_regenerate|i:1662690730;z_user_token|s:85:\"b7560f60441b7b90c36aebc745509d5e68ecc766ff4f2fb303ec4e79ab3cdb66ad7eab53631aa1172c253\";'),('228daaaf6ac09553f9ab597f49821007f054727e','184.180.186.178',1662675159,'__ci_last_regenerate|i:1662675159;login_redirect|s:0:\"\";'),('22mo8k2agf183homtvv4794j8mmaqcpb','174.172.110.201',1687417255,'__ci_last_regenerate|i:1687417155;login_redirect|s:0:\"\";'),('2308ec891da5bb12dce2db5912c15951489d83df','184.180.186.178',1662752120,'__ci_last_regenerate|i:1662751975;login_redirect|s:0:\"\";'),('234ivm2l2sf1urg4tqt0840li6a29grk','206.84.142.45',1697356961,'__ci_last_regenerate|i:1697356961;login_redirect|s:0:\"\";'),('25e7r5pllvtudj4keuf1d2hllfoe4l8c','184.180.186.178',1663699017,'__ci_last_regenerate|i:1663699017;login_redirect|s:0:\"\";'),('262e942aec200ac1a659fafca4784170970d8a05','184.180.186.178',1662680563,'__ci_last_regenerate|i:1662680521;z_user_token|s:85:\"a85c4db82d0f701ba42266f64ff227ff294270aeb5470d7c6d28be22d8e24d57dffb47ed631a7d3fbc5a0\";'),('26bd68a2bc1da3044344c1a0dcfb394be6a9bb2d','70.175.24.196',1662698496,'__ci_last_regenerate|i:1662698496;login_redirect|s:0:\"\";'),('27p0b3tscspic9rp4oo1oclkj3a84ict','103.251.19.196',1687495485,'__ci_last_regenerate|i:1687495370;login_redirect|s:4:\"faqs\";'),('2d98ffd04a721370071c23daa36ecf1fe1e7a2cf','184.180.186.178',1662680521,'__ci_last_regenerate|i:1662680521;z_user_token|s:85:\"a85c4db82d0f701ba42266f64ff227ff294270aeb5470d7c6d28be22d8e24d57dffb47ed631a7d3fbc5a0\";'),('2g24m4qacd8t9ld3ssq6ur5bb30ro7gj','103.87.59.117',1695232025,'__ci_last_regenerate|i:1695231836;login_redirect|s:4:\"faqs\";'),('2hmpcsvbtt699u093kkh5e8ggaedmma3','106.205.130.25',1672299390,'__ci_last_regenerate|i:1672299390;login_redirect|s:0:\"\";'),('2i7e9pdnpt92georirecsrsv209dqoid','169.149.230.78',1673842931,'__ci_last_regenerate|i:1673842931;login_redirect|s:0:\"\";'),('2jjbs956bvfadhgrgqhm2j7ioq3s8og7','154.192.48.94',1699701538,'__ci_last_regenerate|i:1699701538;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('2pihjjkolhulkpbkahv0vactcht2a457','174.172.110.201',1672049198,'__ci_last_regenerate|i:1672049198;login_redirect|s:0:\"\";'),('2qdo8egc2t6o34ma327rbhv73g319rnb','174.238.229.174',1695588194,'__ci_last_regenerate|i:1695588194;login_redirect|s:0:\"\";'),('3a78ffa17e23cc5a6d74c8e1dd2de7c08229a757','2a03:2880:13ff:d::face:b00c',1662736059,'__ci_last_regenerate|i:1662736059;login_redirect|s:0:\"\";'),('3achaaau89c97vrgni4aao7as65292t8','154.192.48.85',1699342933,'__ci_last_regenerate|i:1699342933;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";'),('3liqh7ghb2qiplmkbn8eeprhevc24dh6','174.231.19.139',1663482410,'__ci_last_regenerate|i:1663482410;login_redirect|s:0:\"\";'),('4mpb6cprb6busbadovus3mdgbtjhrjfl','72.200.103.144',1663827387,'__ci_last_regenerate|i:1663827387;login_redirect|s:0:\"\";'),('4ng74jdab458lnpgrr25h9ekb434rq3r','103.46.200.47',1671687823,'__ci_last_regenerate|i:1671687823;login_redirect|s:0:\"\";'),('4obnrtpi93fftbs2lek7bgu03bcg1u9l','174.172.110.201',1672552122,'__ci_last_regenerate|i:1672552102;login_redirect|s:0:\"\";'),('4qntferjoj2kelb671v6icmdhu29uu1l','72.200.103.144',1664597693,'__ci_last_regenerate|i:1664597611;login_redirect|s:5:\"terms\";'),('4riltk0to5814l83i1mtenunsupkv05o','24.251.69.73',1674752499,'__ci_last_regenerate|i:1674752499;login_redirect|s:0:\"\";'),('4tnvkvhmefekhgde5sihdm8bu19i9ofo','174.172.110.201',1672122983,'__ci_last_regenerate|i:1672122983;login_redirect|s:0:\"\";'),('4u7qcl956r0thno5k74tp5s8foueqti8','24.251.69.73',1675111576,'__ci_last_regenerate|i:1675111576;login_redirect|s:0:\"\";'),('53dmh60m48sa6pkch1h1k0oigq0ds8e7','3.238.29.127',1692250601,'__ci_last_regenerate|i:1692250601;login_redirect|s:0:\"\";'),('57hkpucg65vgve1nosv6bj9ka8nhqr0v','184.180.186.178',1665003491,'__ci_last_regenerate|i:1665003491;z_user_token|s:85:\"983e2def8bb71cb21f2bed8946801ea509267f7386df805a9ef4eb3ecf7b5b36b9447697633de9fb00b92\";'),('58ju0sbhq6ejo4r8cv6v6mbp9qdsslus','72.200.103.144',1663560026,'__ci_last_regenerate|i:1663560026;login_redirect|s:4:\"faqs\";'),('59mctki8dfu82be5pqn780o9qhhrrprk','174.196.131.68',1695238903,'__ci_last_regenerate|i:1695238901;login_redirect|s:0:\"\";'),('5ab2d06bed21b4ccc4a88af171919b3f2fdaeae7','184.180.186.178',1662675024,'__ci_last_regenerate|i:1662675024;login_redirect|s:0:\"\";'),('5at344401dff5v4f8uik1ab9cmsb3i8l','169.149.230.78',1673842933,'__ci_last_regenerate|i:1673842933;login_redirect|s:0:\"\";'),('5bbgr8j7j63hhdf5e1sahi18ik5l6u3v','72.200.103.144',1664597685,'__ci_last_regenerate|i:1664597622;z_user_token|s:85:\"62952c8e8b168dfe087a8549cde6c4581266d0a46544dcc36c30806665ab514bff3734ab6337bbdd34e4e\";success|s:42:\"The updation command is successfully done.\";__ci_vars|a:1:{s:7:\"success\";s:3:\"old\";}'),('5n4ipngqp7pib1ktgeqmo2k88g21h8j5','174.172.110.201',1698980473,'__ci_last_regenerate|i:1698980444;login_redirect|s:26:\"user/support/create_ticket\";'),('5ohtg48638m940b35gt8vtro4mfrr01b','174.172.110.201',1698815317,'__ci_last_regenerate|i:1698815190;login_redirect|s:0:\"\";'),('5r5rar95g13neptb6p21lvhv4qtu6d8d','132.154.51.39',1671615397,'__ci_last_regenerate|i:1671615397;login_redirect|s:0:\"\";'),('5uaji771pbl24p4pum6m8pseqcd8uqot','24.251.69.73',1669577825,'__ci_last_regenerate|i:1669577825;login_redirect|s:0:\"\";'),('61f9c92vgacrb22jqfopoh6jijp5ot44','154.192.48.85',1699343648,'__ci_last_regenerate|i:1699343648;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";'),('622k7immkeoenh53b2go0ic50j2l91er','154.192.48.85',1699347791,'__ci_last_regenerate|i:1699347791;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";'),('65catmkqi5dvfs97je5u5krs9tqdgm4p','174.172.110.201',1699426367,'__ci_last_regenerate|i:1699426085;login_redirect|s:0:\"\";'),('65nm7jdt52i15d1s6vfupr37j91khjno','174.172.110.201',1698990387,'__ci_last_regenerate|i:1698990387;login_redirect|s:4:\"faqs\";'),('660qnmb9beskuuvqq6p2f0js0d9bqvl3','174.240.18.210',1664017659,'__ci_last_regenerate|i:1664017615;login_redirect|s:0:\"\";'),('698grqnmhndrkkgcm73cdm41pg6od4g1','24.251.69.73',1668741461,'__ci_last_regenerate|i:1668741461;login_redirect|s:0:\"\";'),('6au09snkb7pnnbtegcqqt9dgdlgg0a0u','154.192.48.85',1699328347,'__ci_last_regenerate|i:1699328347;z_user_token|s:85:\"742bdeb19a7208cbba4a21488b9ab832fadb82a362c2d5e5966e142b3091afbd1af2444d6549aeb1bde86\";'),('6lsai3j5hq9ikjbkstol4uovac91pkjf','184.180.186.178',1665097199,'__ci_last_regenerate|i:1665097199;z_user_token|s:85:\"246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1\";'),('70b62a76defb6b556af7fc8454b745319cd630c1','2a03:2880:3ff:6::face:b00c',1662736040,'__ci_last_regenerate|i:1662736040;login_redirect|s:0:\"\";'),('71b405qum3th6v6vp599nlj1mb9gjhvg','154.192.48.96',1696834360,'__ci_last_regenerate|i:1696834360;login_redirect|s:0:\"\";'),('7252514e6af9293d06c42f4d73e3d7dd7db7eff1','70.175.24.196',1662698734,'__ci_last_regenerate|i:1662698734;login_redirect|s:0:\"\";'),('72ja24i4hhlgnghipgc4akvr0bsscft4','103.87.59.226',1684950936,'__ci_last_regenerate|i:1684950917;login_redirect|s:26:\"user/support/create_ticket\";'),('72lb577to519i6r4a3dgs7jvocn6th0a','72.200.103.144',1665030847,'__ci_last_regenerate|i:1665030847;login_redirect|s:0:\"\";'),('761f4e42cff51229bc55e33f517001370309bd93','2a03:2880:3ff:2::face:b00c',1662736040,'__ci_last_regenerate|i:1662736040;login_redirect|s:0:\"\";'),('7648k2l32adna8i83l40roqahap5uaf0','72.200.103.144',1665114465,'__ci_last_regenerate|i:1665114465;z_user_token|s:85:\"7f508de6a097854845cc638220a0093453324d34a2132337c99e873f93ed79bf4a1f028b633f9e6fa45e1\";'),('76b112581f8458d4139734fc02a012c347d31cbe','184.180.186.178',1662674313,'__ci_last_regenerate|i:1662674313;login_redirect|s:0:\"\";'),('78h1nhjpg9qva5puhaqpgmknbfb27lg2','174.172.110.201',1699426085,'__ci_last_regenerate|i:1699426085;z_user_token|s:85:\"4de88705b725bc0726e8c2840aa33033cbd0fd27e664b1aa7ac2b7604ab80104d52d7b26654b2c755e1ae\";'),('7ac98d49b77cf2ec6b659bda68f05b0f770c210a','2a03:2880:13ff:1::face:b00c',1662736059,'__ci_last_regenerate|i:1662736059;login_redirect|s:0:\"\";'),('7asq3ourl8gff7dcmflq6l899n5v0lru','206.84.142.80',1696910293,'__ci_last_regenerate|i:1696910293;login_redirect|s:0:\"\";'),('7ee066dd0fc3088c66add86d69260ca0dd3bd384','2a03:2880:22ff:15::face:b00c',1662736059,'__ci_last_regenerate|i:1662736059;login_redirect|s:0:\"\";'),('7om0jvg3trj7174o188n7u33p53obaft','174.240.18.210',1664017615,'__ci_last_regenerate|i:1664017615;login_redirect|s:0:\"\";'),('7pjg3cpn0u7po72c2dj1aldsmq0kt93e','72.200.103.144',1663967315,'__ci_last_regenerate|i:1663967315;login_redirect|s:22:\"admin/settings/general\";'),('7vb8351292m1tfip05vc6ed8nl976atp','184.180.186.178',1665003502,'__ci_last_regenerate|i:1665003491;'),('85hk1hapd3mtdoafdq30bik6la0tuhlr','154.192.48.85',1698919684,'__ci_last_regenerate|i:1698919684;login_redirect|s:4:\"faqs\";'),('8oabibqdfsb69j1k45inh328qcrjcjq3','184.180.186.178',1664570170,'__ci_last_regenerate|i:1664570098;z_user_token|s:85:\"774db55f277853d1e99d795a912b3516ade878dc6953a2db80c6b5e9b0e48d56b824dea1633753289281b\";'),('8ottv7bllk0s4h00cnokbjbi7orcrsj6','174.172.110.201',1698990715,'__ci_last_regenerate|i:1698990697;z_user_token|s:85:\"5aa2985e9a470b9c70946fd386892abcfbab9d860fc14d994a1bbe229b22b44c8da64cfb6544893fd5e93\";'),('928p30k8fd1n9cnu3ur06fhb0ks1h1ar','174.172.110.201',1671154815,'__ci_last_regenerate|i:1671154785;login_redirect|s:0:\"\";'),('92k5na9sa2hmmgdrp6mtq820j8bhde6f','102.165.56.57',1691474351,'__ci_last_regenerate|i:1691474351;login_redirect|s:0:\"\";'),('92tn4s8bqlhuejihsgs2e271ettuu7kc','154.192.47.65',1699517559,'__ci_last_regenerate|i:1699517521;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('94q0qnnabkj1j04cer5v9h3u843um1ul','198.71.94.196',1664017237,'__ci_last_regenerate|i:1664017201;login_redirect|s:0:\"\";'),('97489dabb7a113d04ce7741d1b1f69c0d57d0b58','70.175.24.196',1662690186,'__ci_last_regenerate|i:1662690186;z_user_token|s:85:\"b7560f60441b7b90c36aebc745509d5e68ecc766ff4f2fb303ec4e79ab3cdb66ad7eab53631aa1172c253\";'),('99a83503no8iip9qq4dgjqfd9utdkdb7','184.73.45.158',1691397535,'__ci_last_regenerate|i:1691397535;login_redirect|s:0:\"\";'),('9aufts05mji8tmbdr7ufqqm6bvegpmkm','72.200.103.144',1663582895,'__ci_last_regenerate|i:1663582895;login_redirect|s:0:\"\";'),('9bfggrvnbsg6t0tm731e7422sj6epa4q','96.231.40.110',1699040458,'__ci_last_regenerate|i:1699040458;'),('9e3ikpms36ti9bgsj8urod4mik5bn643','24.251.69.73',1680818563,'__ci_last_regenerate|i:1680818563;login_redirect|s:0:\"\";'),('9l62mh904hc92hprbv6ta0i8gas48af5','103.87.59.35',1694846895,'__ci_last_regenerate|i:1694846876;login_redirect|s:0:\"\";'),('9ml2qkmnc2cr8bd9ebd29h7k3gvkbc59','103.87.59.8',1694575473,'__ci_last_regenerate|i:1694575460;login_redirect|s:0:\"\";'),('9qqs91i52g3pchsnjig4s22tstavkc0q','154.192.48.85',1699329145,'__ci_last_regenerate|i:1699329145;'),('a392rbh7f083bqcs11uiavhnqq0ae5qi','72.200.103.144',1663560051,'__ci_last_regenerate|i:1663560026;login_redirect|s:0:\"\";'),('a8gghpgmg0veg0b6sjlr3h77oshmk1q4','122.163.155.34',1667789157,'__ci_last_regenerate|i:1667789157;login_redirect|s:0:\"\";'),('a9f50606ccaf79364a9ea5e9cafc4cba40eb2f84','70.175.24.196',1662689849,'__ci_last_regenerate|i:1662689849;z_user_token|s:85:\"b7560f60441b7b90c36aebc745509d5e68ecc766ff4f2fb303ec4e79ab3cdb66ad7eab53631aa1172c253\";'),('aa42ad06e30484334993800b8b6d411f1367b489','2607:fb90:2d06:eb14:5848:277b:2be9:6bee',1662673973,'__ci_last_regenerate|i:1662673973;login_redirect|s:0:\"\";'),('agjtcq41q6hvq4qgcu2ea34aeqj2vmjj','72.200.103.144',1665526486,'__ci_last_regenerate|i:1665526486;login_redirect|s:0:\"\";'),('ah5jov6snvrhbj8nib20c10frfl6iptk','174.172.110.201',1691397233,'__ci_last_regenerate|i:1691397054;login_redirect|s:0:\"\";'),('ao9rooiitcp2h4ivrmrjoh3e6t7sl0em','34.229.74.122',1687481099,'__ci_last_regenerate|i:1687481099;login_redirect|s:0:\"\";'),('arkkb01l3lc2n69cku5q5k6rbm5eeplm','154.192.48.12',1699677544,'__ci_last_regenerate|i:1699677544;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('b10hfp5afscudu43lgg00jcoh1enu4le','154.192.48.85',1699348845,'__ci_last_regenerate|i:1699348845;z_user_token|s:85:\"eb2e349d6168b703d140e802d1017b8ad4d47c193e99516121fa7c0eda2b757c6e9fc64f6549fd88a759f\";'),('b1g45j78d7in9q3c9h2faposiou2quvp','154.192.48.85',1699336102,'__ci_last_regenerate|i:1699336102;'),('bajdc06v25q912q28pgsbuu5763ug9hl','42.111.16.118',1670985460,'__ci_last_regenerate|i:1670985460;login_redirect|s:0:\"\";'),('bp1hgc8qeie594o6nhblp0s4h3m7fh2n','24.251.69.73',1669768120,'__ci_last_regenerate|i:1669768064;login_redirect|s:0:\"\";'),('bqal4oc427rju1e3h5q0ccid1hathuur','174.172.110.201',1698247599,'__ci_last_regenerate|i:1698247599;login_redirect|s:0:\"\";'),('c090cf81a2808b7dcf44fd7e0c9652693fc5c3fe','70.175.24.196',1662690730,'__ci_last_regenerate|i:1662690730;z_user_token|s:85:\"b7560f60441b7b90c36aebc745509d5e68ecc766ff4f2fb303ec4e79ab3cdb66ad7eab53631aa1172c253\";'),('c2ca815699e2b4a4b702f4075568289d0ee19d46','66.249.80.122',1662674043,'__ci_last_regenerate|i:1662674043;login_redirect|s:0:\"\";'),('c3bkld5thefgp5hrdvtc2g1gc35bu9c1','72.200.103.144',1665115224,'__ci_last_regenerate|i:1665115224;z_user_token|s:85:\"7f508de6a097854845cc638220a0093453324d34a2132337c99e873f93ed79bf4a1f028b633f9e6fa45e1\";'),('cc8bf711bd222335757c9a22f6825b633c000b07','72.200.103.144',1662733675,'__ci_last_regenerate|i:1662733613;z_user_token|s:85:\"89eae39b1a66a16feae7956f5824aa3311e7d0b68b053fbf1916645b8c46b8a440668ef6631b4d521a3af\";'),('cojhv3cm6bhcrerfnbsq5un32pvg5ih3','102.165.56.57',1691398046,'__ci_last_regenerate|i:1691397848;login_redirect|s:0:\"\";'),('culu0orpsho1tuneepu1boa49e1ulscr','72.200.103.144',1663654407,'__ci_last_regenerate|i:1663654407;login_redirect|s:0:\"\";'),('d1dqn3ftp9k590e1si3ev98ojhgvrfba','42.111.8.184',1671602784,'__ci_last_regenerate|i:1671602784;login_redirect|s:0:\"\";'),('d7209f558f0b57d139fab22045c728c906963e62','70.175.24.196',1662699830,'__ci_last_regenerate|i:1662699830;login_redirect|s:0:\"\";'),('d85v0k49eqo7uraqhvkkg7ulkh7q2be9','103.87.59.117',1695231836,'__ci_last_regenerate|i:1695231836;login_redirect|s:0:\"\";'),('d8gctsmccv6bbet2fp8o9q5rc4fs7589','174.172.110.201',1674066199,'__ci_last_regenerate|i:1674066199;login_redirect|s:0:\"\";'),('degp3fb4fsl5mfvl5fmdag00eg9gt8oo','103.87.59.138',1685643043,'__ci_last_regenerate|i:1685643032;login_redirect|s:0:\"\";'),('e191fa1b45eb2a771ca8c1baeff9bdf0cc52678c','184.180.186.178',1662751975,'__ci_last_regenerate|i:1662751975;'),('e216234fb7d2785a53b7d5cb9b7721074fdb0220','2a03:2880:22ff:c::face:b00c',1662736059,'__ci_last_regenerate|i:1662736059;login_redirect|s:0:\"\";'),('e2shv45p3fkf0ma76lp1gqdju2ovo6cl','174.240.21.40',1665001570,'__ci_last_regenerate|i:1665001570;login_redirect|s:0:\"\";'),('e4pujgf52bjerauce6sjnso6n4ej7q9n','3.88.148.124',1691484434,'__ci_last_regenerate|i:1691484434;login_redirect|s:0:\"\";'),('e9lutjka6c52n71fulp9ae11mr19vuog','72.200.103.144',1663653884,'__ci_last_regenerate|i:1663653884;login_redirect|s:0:\"\";'),('e9nq4bebmlrgeecg45ce13725hdpvghj','72.200.103.144',1663927501,'__ci_last_regenerate|i:1663927437;login_redirect|s:0:\"\";'),('eae56d0675c2be7857c377495c6abf71482dac8a','184.180.186.178',1662674851,'__ci_last_regenerate|i:1662674851;z_user_token|s:85:\"2730c02551b1296befe16dda82f09480043708da8eb0cfde704b93909626773ae4e439d6631a66a6b25d3\";success|s:42:\"The updation command is successfully done.\";__ci_vars|a:1:{s:7:\"success\";s:3:\"new\";}'),('eak5moogffqv7101396dpbeh8pft8nr9','72.200.103.144',1665456773,'__ci_last_regenerate|i:1665456773;login_redirect|s:0:\"\";'),('ee0df40c235da453c425108d46a262a5c3d2d7e0','2600:1011:b13d:bfd9:e1d0:77ec:fff:6b57',1662751475,'__ci_last_regenerate|i:1662751466;login_redirect|s:0:\"\";'),('eedl5j1keqvjjo81pq4qmbedcsskmbhk','103.87.59.217',1673431663,'__ci_last_regenerate|i:1673431663;login_redirect|s:0:\"\";'),('eep4qp6ng0n8amjmp7jtb1s1le15ep2o','154.192.48.85',1699169776,'__ci_last_regenerate|i:1699169776;login_redirect|s:4:\"faqs\";'),('eeqk3kkntrke4i7v2f08h5aft1dfjb79','24.251.69.73',1694355435,'__ci_last_regenerate|i:1694355435;login_redirect|s:0:\"\";'),('ehahdivgb3od6d4ok758c745u3vlklpo','42.111.16.118',1670985460,'__ci_last_regenerate|i:1670985460;login_redirect|s:0:\"\";'),('f0ps1gh6b7rn7r71t2ps36l6mg4hqnkq','154.192.45.40',1697022361,'__ci_last_regenerate|i:1697022358;login_redirect|s:0:\"\";'),('f451057cc41c6d3a14b5ec877cf14d14f8021397','2600:1011:b13d:bfd9:e1d0:77ec:fff:6b57',1662751466,'__ci_last_regenerate|i:1662751466;login_redirect|s:0:\"\";'),('f7l3dje7h01tbda5ifsp0vam5ojnrga5','174.172.110.201',1698990697,'__ci_last_regenerate|i:1698990697;z_user_token|s:85:\"5aa2985e9a470b9c70946fd386892abcfbab9d860fc14d994a1bbe229b22b44c8da64cfb6544893fd5e93\";'),('f8breabubd68ksnk2rbdjfen8sn7pc18','108.174.8.21',1699426195,'__ci_last_regenerate|i:1699426195;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('ff2h23t59dm9h7mh6obqqmt91s5hiet3','154.192.48.94',1699701538,'__ci_last_regenerate|i:1699701538;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('fnh0qi4fln1njvjdof8kf100k4fo0979','184.180.186.178',1663699017,'__ci_last_regenerate|i:1663699017;login_redirect|s:0:\"\";'),('fp41ecu213o96g9voak46diuprjfimvc','174.172.110.201',1671585719,'__ci_last_regenerate|i:1671585719;login_redirect|s:0:\"\";'),('ftostbm4kjloakj918l8pb4gsf66r1ea','154.192.47.65',1699508765,'__ci_last_regenerate|i:1699508536;z_user_token|s:85:\"5d121feb3e1a83f4765a81c0a8f8812040aa00195d17fa00ce63f9b93b62904eba928bd0654c71612515f\";'),('fu2ikrqiqudk8hjqk9luc0o6s52du7se','72.200.103.144',1664721046,'__ci_last_regenerate|i:1664721046;login_redirect|s:0:\"\";'),('g0pqc8n0465dbr4rc25sm3chg2u5400t','184.180.186.178',1665100758,'__ci_last_regenerate|i:1665100758;z_user_token|s:85:\"246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1\";'),('g53rnbrikl8mmvnte6j9sl4ft5ccujq8','52.114.32.28',1671679370,'__ci_last_regenerate|i:1671679370;login_redirect|s:0:\"\";'),('g7rtu3e09lc4l0rlfbqv92dt9pqn29p9','18.206.218.123',1694846707,'__ci_last_regenerate|i:1694846707;login_redirect|s:0:\"\";'),('gb0octg1emanlk7pq9a11nmd3hj7k9uk','154.192.48.85',1699348845,'__ci_last_regenerate|i:1699348845;z_user_token|s:85:\"eb2e349d6168b703d140e802d1017b8ad4d47c193e99516121fa7c0eda2b757c6e9fc64f6549fd88a759f\";'),('gboda7vknp68arc2spbi665q2b2r27g1','72.200.103.144',1665031009,'__ci_last_regenerate|i:1665030847;login_redirect|s:0:\"\";'),('gd4k957dkoet06ai6u2kdom10obihn4u','72.200.103.144',1663479785,'__ci_last_regenerate|i:1663479785;login_redirect|s:0:\"\";'),('ge8jrlm258qtgfpd40v2b9o3c6e3coan','72.200.103.144',1664597622,'__ci_last_regenerate|i:1664597622;z_user_token|s:85:\"62952c8e8b168dfe087a8549cde6c4581266d0a46544dcc36c30806665ab514bff3734ab6337bbdd34e4e\";success|s:42:\"The updation command is successfully done.\";__ci_vars|a:1:{s:7:\"success\";s:3:\"new\";}'),('giqo9436inan2i86j1b7vl7e8ljsm79v','72.200.103.144',1665114129,'__ci_last_regenerate|i:1665114129;z_user_token|s:85:\"7f508de6a097854845cc638220a0093453324d34a2132337c99e873f93ed79bf4a1f028b633f9e6fa45e1\";'),('gmk4p5svvgo9f9na43ulabenpb3fpuuf','72.200.103.144',1663650372,'__ci_last_regenerate|i:1663650372;login_redirect|s:0:\"\";'),('gngbnughh36vdop8muad8sqhukeietab','154.192.48.85',1699333015,'__ci_last_regenerate|i:1699333015;'),('gvbjlr07f187obit9cos2l19m6v6ve4g','72.200.103.144',1664733205,'__ci_last_regenerate|i:1664733205;login_redirect|s:0:\"\";'),('h42mi25qbi5m29a7b99u0dbkdv7dr5oj','72.200.103.144',1665456773,'__ci_last_regenerate|i:1665456773;'),('h6h6rdeq72e4mrs24c0vb7n6fdl762it','184.180.186.178',1665100761,'__ci_last_regenerate|i:1665100758;z_user_token|s:85:\"246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1\";'),('h7562oc145o3k5opns4ob1qq9v2ooc3f','103.46.200.47',1671679496,'__ci_last_regenerate|i:1671679496;login_redirect|s:0:\"\";'),('hbf9lv7m20rtfqli41icf75mcug2ti3c','27.58.146.252',1669179727,'__ci_last_regenerate|i:1669179727;login_redirect|s:0:\"\";'),('i883rf0f0gh4i1qr3n95oe3mutu2upng','154.192.47.65',1699517521,'__ci_last_regenerate|i:1699517521;login_redirect|s:9:\"dashboard\";'),('icgv7j9hr9d1pbfhum0gsvkbeihs6a6c','154.192.45.40',1697012438,'__ci_last_regenerate|i:1697012438;login_redirect|s:0:\"\";'),('idsedhijofq9626prnb9edr5595gackb','3.235.89.250',1691598868,'__ci_last_regenerate|i:1691598868;login_redirect|s:0:\"\";'),('ih816u3ml2ems042vh1ao1nvlhasjqc0','122.161.74.160',1674111997,'__ci_last_regenerate|i:1674111997;login_redirect|s:0:\"\";'),('io5i28ias5ds1g23qoe9pkrvqa5u6toa','171.48.65.49',1672302724,'__ci_last_regenerate|i:1672302724;login_redirect|s:0:\"\";'),('is3dmvf4sa2q3r4o311qk85u7gre0e6a','72.200.103.144',1663644989,'__ci_last_regenerate|i:1663644989;login_redirect|s:0:\"\";'),('ivvjfbtbvf48mbjh285bdo8g6m9dimjf','174.172.110.201',1699591269,'__ci_last_regenerate|i:1699591269;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('j593qar2scejsjm8qkculk451ti8gaum','184.180.186.178',1665096695,'__ci_last_regenerate|i:1665096695;z_user_token|s:85:\"246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1\";'),('j8hcmh4jbloph0rrn2pju7fe657rb113','171.48.65.49',1672302725,'__ci_last_regenerate|i:1672302724;login_redirect|s:0:\"\";'),('jclevj1pmbijniehbf3h5ndoof5nbd1k','154.192.48.85',1698919684,'__ci_last_regenerate|i:1698919684;login_redirect|s:14:\"privacy-policy\";'),('jcs9vnflc4ca9cndi7989286i361e2uf','34.232.64.213',1691418245,'__ci_last_regenerate|i:1691418245;login_redirect|s:0:\"\";'),('jf92kdbo6tc04fdg0u6tv10s18pmaq8e','154.192.48.85',1698916725,'__ci_last_regenerate|i:1698916725;login_redirect|s:5:\"terms\";'),('jmpfabisuqr09e7mtcabqdoq2f4khdmg','72.200.103.144',1663571215,'__ci_last_regenerate|i:1663571215;login_redirect|s:0:\"\";'),('jpjjvocgeu04l93dhej1ptd5pgr0s473','154.192.48.59',1698306943,'__ci_last_regenerate|i:1698306943;login_redirect|s:0:\"\";'),('jrguunh7qcvfg48odehnlf6ik4v337gp','24.251.69.73',1665169152,'__ci_last_regenerate|i:1665169152;login_redirect|s:0:\"\";'),('k425530kndc08i984mutcrl8m92ia8tb','72.200.103.144',1663654524,'__ci_last_regenerate|i:1663654407;z_user_token|s:85:\"655c2d0b540be6828d490debf7a37c385860bcab7299ca6ffec9eb117184c3a8b612e93963295a1b8fc15\";'),('kar4m1n7ob5cma67r6kova7g4qj2tn5b','174.240.16.170',1663573911,'__ci_last_regenerate|i:1663573911;login_redirect|s:0:\"\";'),('kjmeos8jl4pl5sm1ooat4ovv9a8ln4r3','72.200.103.144',1665115082,'__ci_last_regenerate|i:1665115079;login_redirect|s:26:\"user/support/create_ticket\";'),('knn04699p4otit458rhhlhl6affle0ci','108.174.8.25',1699426183,'__ci_last_regenerate|i:1699426183;login_redirect|s:36:\"knowledge-base/article/Testme%20okay\";'),('kov6mb6cpi6e6btjdgm0jd8etugoboos','174.172.110.201',1687481091,'__ci_last_regenerate|i:1687481091;login_redirect|s:0:\"\";'),('lattiehe0utdm5ctfq40ku5um04idulh','111.88.149.90',1691424725,'__ci_last_regenerate|i:1691424725;login_redirect|s:0:\"\";'),('lc1s14u6548l8vqdodh5ta62d6lt2fjf','174.172.110.201',1688920788,'__ci_last_regenerate|i:1688920788;login_redirect|s:0:\"\";'),('lcpt2md7tb3fvvk5dv3kb5d024k2ak89','102.165.56.57',1691418282,'__ci_last_regenerate|i:1691418282;login_redirect|s:0:\"\";'),('lm7jrmaoh5ece4ih85lk4ts0ufil92hg','174.172.110.201',1698247599,'__ci_last_regenerate|i:1698247599;login_redirect|s:0:\"\";'),('m34vtksivkgtpn1att1vc7110bicaecb','72.200.103.144',1663927437,'__ci_last_regenerate|i:1663927437;login_redirect|s:0:\"\";'),('m7qhnud5v2cqsu0mdunae4oqmfmg7cgs','24.251.69.73',1669917777,'__ci_last_regenerate|i:1669917777;login_redirect|s:0:\"\";'),('mkfb0idrgbtov2bi5490bd6n889hkbh8','24.251.69.73',1699017931,'__ci_last_regenerate|i:1699017922;'),('mlmd38ll4lb51g52473akmi0p1fpn52c','72.200.103.144',1666378877,'__ci_last_regenerate|i:1666378875;login_redirect|s:0:\"\";'),('n3b3k6mj3lhcen14uq7mvfm29d3m7ovl','182.185.171.196',1691484417,'__ci_last_regenerate|i:1691484417;login_redirect|s:0:\"\";'),('n8eatqne12872fcegrc8edfc4sguets3','184.180.186.178',1664210809,'__ci_last_regenerate|i:1664210638;login_redirect|s:0:\"\";'),('nl6fu17ucb39tadrv1cdqn6c3sic5nk7','72.200.103.144',1664597611,'__ci_last_regenerate|i:1664597611;login_redirect|s:14:\"privacy-policy\";'),('nmsdne5hc7qh9b8bb1v776bhspuj2j27','103.134.253.192',1672210776,'__ci_last_regenerate|i:1672210776;login_redirect|s:0:\"\";'),('nr9dfvhmsot7bg7jouh1elf6g68cl8rd','103.134.253.192',1672210776,'__ci_last_regenerate|i:1672210776;login_redirect|s:0:\"\";'),('ns50uv6st1nv5id03lcnad5bp7cva93n','122.161.51.211',1680076280,'__ci_last_regenerate|i:1680076280;login_redirect|s:0:\"\";'),('ob2lt9ff2smisl898nlk3sudko0s7t2u','24.251.69.73',1676732455,'__ci_last_regenerate|i:1676732455;login_redirect|s:0:\"\";'),('ocq3rae93unl8fao89l0jkfrfquq9c3c','185.107.56.165',1686291403,'__ci_last_regenerate|i:1686291389;login_redirect|s:0:\"\";'),('ocu8m1mmhv3dr0ukdnlm86g4kle9qaut','24.251.69.73',1665504516,'__ci_last_regenerate|i:1665504516;login_redirect|s:0:\"\";'),('omt7g45nquggivd9sqbgh5heb9vavqfr','103.87.59.65',1689696031,'__ci_last_regenerate|i:1689695885;login_redirect|s:26:\"user/support/create_ticket\";'),('oqi8f560re0slv1981vs43f0hng6p1a2','103.87.59.87',1681750059,'__ci_last_regenerate|i:1681750059;login_redirect|s:0:\"\";'),('ouul6pbjfh10vkdvr0qbsbd9r1h1joj0','184.180.186.178',1664903335,'__ci_last_regenerate|i:1664903312;login_redirect|s:0:\"\";'),('p4s5p1871thq8sj9ijbvq8bcme23qioj','154.192.48.85',1699342337,'__ci_last_regenerate|i:1699342337;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";'),('pa21vdrflndfvjohlt1buuu55d5srr7r','103.87.59.148',1673249306,'__ci_last_regenerate|i:1673249306;login_redirect|s:0:\"\";'),('plofucojjgcasjftpf41a90j9netc3i9','174.172.110.201',1671003009,'__ci_last_regenerate|i:1671003009;login_redirect|s:0:\"\";'),('pu33d11pg9224a1ea7vkoampd6rc32l6','103.87.59.129',1682615720,'__ci_last_regenerate|i:1682615720;login_redirect|s:0:\"\";'),('q0jgfbncnm75873raecf0a9em1aqfabn','172.56.12.10',1673897397,'__ci_last_regenerate|i:1673897383;login_redirect|s:0:\"\";'),('q2lf1ugr2r3777huu2a9ln168f4rq46k','103.87.59.117',1695230986,'__ci_last_regenerate|i:1695230781;login_redirect|s:0:\"\";'),('q7evggco57t7nrb7lih4l76e8cpnsd6e','72.200.103.144',1664087186,'__ci_last_regenerate|i:1664087186;login_redirect|s:0:\"\";'),('qekltsp189pu9gi9l1ua9impa9fdj0ht','24.251.69.73',1675098099,'__ci_last_regenerate|i:1675098099;login_redirect|s:0:\"\";'),('qi4nutiu6r79320ihkfflvnshm7cfu5u','184.180.186.178',1664905493,'__ci_last_regenerate|i:1664905493;login_redirect|s:0:\"\";'),('qjunu4i83rgsmh436rvvufm9tlkf750c','103.87.59.171',1694850207,'__ci_last_regenerate|i:1694850202;login_redirect|s:0:\"\";'),('qmhqcrq90om2cpgf567qa89l9ck3qqki','154.192.48.85',1699339838,'__ci_last_regenerate|i:1699339838;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";'),('r7fniutp03sh2b1jqfpikddur3ekknca','174.216.176.250',1672215598,'__ci_last_regenerate|i:1672215598;login_redirect|s:0:\"\";'),('rcps9hsq5ciefdqbrcb5u7dev6jvfc39','174.172.110.201',1699426394,'__ci_last_regenerate|i:1699426394;login_redirect|s:0:\"\";'),('rd3jb37iqrfq0qsia2e19pnc1g03dvlr','103.87.59.49',1681301354,'__ci_last_regenerate|i:1681301354;login_redirect|s:0:\"\";'),('rd9jso86u4u4v31urpk0im5cvrdq1ghr','42.111.8.184',1671602784,'__ci_last_regenerate|i:1671602784;login_redirect|s:0:\"\";'),('rkatpg9jiicnp3bc8bfjdnu2qdhes5g9','154.192.47.65',1699517069,'__ci_last_regenerate|i:1699517069;login_redirect|s:4:\"faqs\";'),('rrbkar449qp0m21avlcbve1ve4vtietd','24.251.69.73',1675359031,'__ci_last_regenerate|i:1675359031;login_redirect|s:0:\"\";'),('ru64jd1ujteco9b72d111ebgm45afqcf','184.180.186.178',1665096065,'__ci_last_regenerate|i:1665096065;z_user_token|s:85:\"246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1\";'),('s0r5vu7uqv45cj575sa4045q1bvpmfe5','182.185.171.196',1691599065,'__ci_last_regenerate|i:1691599065;login_redirect|s:0:\"\";'),('s17inan7rgjoaarpu73p3s0m3rt302f0','174.172.110.201',1687417155,'__ci_last_regenerate|i:1687417155;login_redirect|s:0:\"\";'),('s19mft3doqh3dg6j8g8dbrgv1k7i989m','72.200.103.144',1665252234,'__ci_last_regenerate|i:1665252161;login_redirect|s:0:\"\";'),('s1fnoukstvic45q9al2b02uhanq97l35','174.172.110.201',1674326931,'__ci_last_regenerate|i:1674326931;login_redirect|s:0:\"\";'),('skcoct884guk7jqum3arol4jrfsvt5p3','144.51.12.131',1698994297,'__ci_last_regenerate|i:1698994184;login_redirect|s:4:\"faqs\";'),('sm4l34e032tv1q78a9rknl3bueu21mq6','154.192.48.85',1699335172,'__ci_last_regenerate|i:1699335172;'),('t0co62n5h3a09ndm1trmq1vu2psk2klt','42.111.8.88',1671672792,'__ci_last_regenerate|i:1671672792;login_redirect|s:0:\"\";'),('t7iggsonquddl7bbr9mc9225k9naous6','103.134.253.174',1674037171,'__ci_last_regenerate|i:1674037171;login_redirect|s:0:\"\";'),('t9bq6fvm8qb6l2d96p6j4ar7ankk8182','103.87.59.35',1694850202,'__ci_last_regenerate|i:1694850202;login_redirect|s:26:\"user/support/create_ticket\";'),('tdtqlts6ondg1eoio642l8vbr1ml17ot','154.192.48.85',1698919186,'__ci_last_regenerate|i:1698919186;login_redirect|s:5:\"terms\";'),('thaprdgq2696jso5mi84p7edqfs5v6tu','72.200.103.144',1664721046,'__ci_last_regenerate|i:1664721046;login_redirect|s:4:\"faqs\";'),('trbmc2fk0cecfbk4kbna4556vptfi1f7','174.172.110.201',1672990381,'__ci_last_regenerate|i:1672990381;login_redirect|s:0:\"\";'),('tuv0mt4gsd8o5h5srjg1pet6cf1lif5g','154.192.48.85',1698912205,'__ci_last_regenerate|i:1698912205;login_redirect|s:14:\"privacy-policy\";'),('u40rb2siqj93t921qblsp23ub2lrdi7h','103.87.59.102',1685869728,'__ci_last_regenerate|i:1685869728;login_redirect|s:0:\"\";'),('uaekf3e1j2mlj41425m5ln6rp09iecdo','27.58.146.252',1669179727,'__ci_last_regenerate|i:1669179727;login_redirect|s:0:\"\";'),('ubk9hga19pc5elvoklnm8ro5k0b3657t','157.37.213.54',1671515494,'__ci_last_regenerate|i:1671515494;login_redirect|s:0:\"\";'),('uelch0dkt9r0oseautc2lcpd9jvulrli','184.180.186.178',1665088925,'__ci_last_regenerate|i:1665088925;login_redirect|s:0:\"\";'),('umh97kb4keb4qabanm980t7ulgpvbl3g','184.180.186.178',1665092164,'__ci_last_regenerate|i:1665092164;login_redirect|s:0:\"\";'),('uru6u9tlpdhneint29p3vsduobkp058n','72.200.103.144',1665116529,'__ci_last_regenerate|i:1665116529;login_redirect|s:0:\"\";'),('uummjk3qb3slnechsh3u79flmgmr7v56','72.200.103.144',1664597306,'__ci_last_regenerate|i:1664597306;z_user_token|s:85:\"62952c8e8b168dfe087a8549cde6c4581266d0a46544dcc36c30806665ab514bff3734ab6337bbdd34e4e\";success|s:42:\"The updation command is successfully done.\";__ci_vars|a:1:{s:7:\"success\";s:3:\"new\";}'),('v0tlfkkq6crs08ajppi6rb09c8ajj4mg','174.172.110.201',1671585719,'__ci_last_regenerate|i:1671585719;login_redirect|s:4:\"faqs\";'),('v3u31t3k4kepkm9i39tqggscbv78s25k','72.200.103.144',1663571215,'__ci_last_regenerate|i:1663571215;login_redirect|s:0:\"\";'),('vdvjogia61i75ufu6pog99cda9t8m3o9','72.200.103.144',1665115244,'__ci_last_regenerate|i:1665115224;z_user_token|s:85:\"7f508de6a097854845cc638220a0093453324d34a2132337c99e873f93ed79bf4a1f028b633f9e6fa45e1\";'),('vhim3sjtek95ortnii6mls3r7j5ih2qo','103.251.19.196',1687446594,'__ci_last_regenerate|i:1687446581;login_redirect|s:0:\"\";'),('vlf4gs01fchq9ddh7bc7qqtlaifgevui','174.240.21.40',1665001600,'__ci_last_regenerate|i:1665001570;login_redirect|s:5:\"terms\";'),('vmifpe30sleu7af324u4gpd169har0ku','154.192.48.85',1699336524,'__ci_last_regenerate|i:1699336524;z_user_token|s:85:\"0c5f059e6331cb4c43384f48f11a87c4318655be4adf9e41f33de49f38da5a6a76d022ce6549d0096dbcd\";');
/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(90) NOT NULL,
  `type` varchar(30) NOT NULL,
  `options` varchar(1500) NOT NULL,
  `is_required` tinyint(3) unsigned NOT NULL,
  `guide_text` varchar(255) NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(90) NOT NULL,
  `subject` varchar(90) NOT NULL,
  `hook` varchar(50) NOT NULL,
  `language` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `is_built_in` tinyint(3) unsigned NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'Email Verification','Please Verify your Account','email_verification','english','<p>Hi {USER_NAME},<br><br>Thank you so much for joining the {SITE_NAME}.<br><br>Please verify your account by clicking on the following link:<br><a href=\"{EMAIL_LINK}\" target=\"_blank\">Click here</a><br><br>If you did not register, please kindly ignore this email.<br><br>Thanks,<br>{SITE_NAME}<br></p>',1,NULL,1611059287),(2,'Forgot Password','Password Reset','forgot_password','english','<p>Hi {USER_NAME},<br><br>We\'ve received a password reset request. Please click on the following link to proceed:<br><a href=\"{EMAIL_LINK}\" target=\"_blank\">Reset Password</a><br><br>The link will expire after a limited time. If you didn\'t request to reset your password, please kindly ignore this message.<br><br>Thanks,<br>{SITE_NAME}<br></p>',1,NULL,1611135272),(3,'Ticket Replied by Agent','Your Ticket Has Been Replied','ticket_replied_agent','english','<p>Hi {USER_NAME},<br><br>Your ticket has been replied to by our agent. You can see the ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Thanks,<br>{SITE_NAME} Support<br></p>',1,NULL,1611135470),(4,'Member Invite','Sign Up Invitation','member_invite','english','<p>Hi there,<br><br>You have been invited to sign up as a member of {SITE_NAME}.<br><br>Please click on the following link to proceed:<br><a href=\"{EMAIL_LINK}\" target=\"_blank\">Register now</a><br><br>Thanks,<br>{SITE_NAME}<br></p>',1,NULL,1611136036),(5,'Change Email','Please Verify your Email Address','change_email','english','<p>Hi there,<br><br>We\'ve received a request to change your email address. Please click on the following link to proceed:<br><a href=\"{EMAIL_LINK}\" target=\"_blank\">Click here</a><br><br>If you didn\'t request, please kindly ignore this email.<br><br>Thanks,<br>{SITE_NAME}</p>',1,NULL,1614102803),(6,'Changed Password','Password Changed','changed_password','english','<p>Hi {USER_NAME},<br><br>Your account password is successfully changed. If you didn\'t request the change, please send us a message.<br><br>Thanks,<br>{SITE_NAME} Support</p>',1,NULL,1616355883),(7,'Welcome User','Your Account is Successfully Registered','welcome_user','english','<p>Hi {USER_NAME},<br><br>You\'re welcome to {SITE_NAME}.<br><br>You can login to your account with username: {LOGIN_USERNAME} and the password that you created when registering.<br><br>You can go to the login page by clicking on the following link:<br><a href=\"{EMAIL_LINK}\" target=\"_blank\">Click here</a><br><br>Thanks,<br>{SITE_NAME}</p>',1,NULL,1625991429),(8,'Department Ticket','New Ticket Assigned to Department: {DEPARTMENT_NAME}','department_ticket','english','<p>Hi {USER_NAME},<br><br>A new ticket has been assigned to your <b>{DEPARTMENT_NAME}</b> department.<br><br>You can see the assigned ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1627205276),(9,'Ticket Replied by User','User Replied to Assigned Ticket','ticket_replied_user','english','<p>Hi {USER_NAME},<br><br>The user has replied to the ticket that\'s assigned to you. You can see the ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Thanks,<br>{SITE_NAME} Support<br></p>',1,NULL,1627224733),(10,'Ticket Assigned','Ticket Assigned','ticket_assigned','english','<p>Hi {USER_NAME},<br><br>You have been assigned a ticket. You can see the ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1628170959),(11,'Department Chat','New Chat Assigned to Department: {DEPARTMENT_NAME}','department_chat','english','<p>Hi {USER_NAME},<br><br>A new chat has been assigned to your <b>{DEPARTMENT_NAME}</b> department.<br><br>You can see the assigned chat by clicking on the following link:<br><a href=\"{CHAT_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1638553679),(12,'Ticket Created (Unregistered User)','New Ticket Created For You','ticket_created_unregistered_user','english','<p>Dear Customer,<br><br>A new ticket has been created for you by our support agent.<br><br>You can reach that ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1638868973),(13,'Chat Assigned','Chat Assigned','chat_assigned','english','<p>Hi {USER_NAME},<br><br>You have been assigned a chat. You can see the chat by clicking on the following link:<br><a href=\"{CHAT_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1639160537),(14,'Ticket Created by Guest','New Guest Ticket Created','ticket_created_guest','english','<p>Dear Customer,<br><br>We have received a ticket submission request and a guest ticket has been successfully created for you.<br><br>Please kindly verify that the request was submitted by you, otherwise, you will not be able to add the replies:&nbsp;<a href=\"{EMAIL_LINK}\" target=\"_blank\">Verify Now</a><br><br>You can access it by clicking:&nbsp;<a href=\"{TICKET_URL}\" target=\"_blank\">View Ticket</a><br><br>If you didn\'t submit it, please kindly ignore this email (possibly the email address typing mistake).<br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1660817123),(15,'Resend Ticket Access','Re-sent Guest Ticket Access URL','resend_ticket_access','english','<p>Dear Customer,<br><br>We have resent the URL of your guest ticket #{TICKET_ID}.<br><br>You can access that ticket by clicking on the following link:<br><a href=\"{TICKET_URL}\" target=\"_blank\">Click here</a><br><br>Regards,<br>{SITE_NAME} Support</p>',1,NULL,1660931621);
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_tokens`
--

DROP TABLE IF EXISTS `email_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `token` varchar(32) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `requested_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_tokens`
--

LOCK TABLES `email_tokens` WRITE;
/*!40000 ALTER TABLE `email_tokens` DISABLE KEYS */;
INSERT INTO `email_tokens` VALUES (1,1,'password_reset','e466a5013dcff78b6edabc6cbe1d1c3b','184.180.186.178',1665003502),(2,1,'password_reset','ca1fa2c4af3388e2e68ccefbaf1db42b','72.200.103.144',1665028828),(3,1,'password_reset','93042b31ce44ae4f275e6c12e09fc91e','72.200.103.144',1665030851),(4,1,'password_reset','d48dadc92dcd5153fb7064a18b01e79b','184.180.186.178',1665086993),(5,1,'password_reset','d8f63903f8827b2bfebafc3ff3fa5c0c','184.180.186.178',1665088968),(6,2,'change_email','3ba7ce542d425a94449daa7f5fc620e8','174.172.110.201',1698990621);
/*!40000 ALTER TABLE `email_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(90) NOT NULL,
  `answer` text NOT NULL,
  `category_id` tinyint(3) unsigned NOT NULL,
  `visibility` tinyint(3) unsigned NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'How Can I Access rootCapture\'s Support System?','Access to the rootCapture Support System is granted to those authorized only. If you are a part of an entity that has either of the following services with us: an added support contract or service, and/or your organization is an Enterprise Client with rootCapture Services, outside of that criteria, you are not given access to the rootCapture Enterprise Support System. Should you believe that you were not given access to rootCapture Enterprise Support System in error, please feel free to email support@rootcapture.com for further assistance.',1,1,1665115163,1665096051),(2,'How Do I Reset My Password?','Password resets',1,1,NULL,1665115221);
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs_categories`
--

DROP TABLE IF EXISTS `faqs_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs_categories` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs_categories`
--

LOCK TABLES `faqs_categories` WRITE;
/*!40000 ALTER TABLE `faqs_categories` DISABLE KEYS */;
INSERT INTO `faqs_categories` VALUES (1,'rootCapture Support - The Basics',NULL,1665002103);
/*!40000 ALTER TABLE `faqs_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_key` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `for_team_member` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'notify_ticket_assigned_department','admin/tickets/ticket/1',1,1,0,1699425491),(2,'notify_ticket_assigned_department','admin/tickets/ticket/2',1,1,0,1699425577),(3,'notify_ticket_assigned_department','admin/tickets/ticket/3',1,1,0,1699425603);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'<p>The rootCapture\'s website located at https://rootcapture.com is a copyrighted work belonging to rootCapture. Certain features of the Site may be subject to additional guidelines, terms, or rules, which will be posted on the Site in connection with such features.<br><br>All such additional terms, guidelines, and rules are incorporated by reference into these Terms.<br><br>These Terms of Use described the legally binding terms and conditions that oversee your use of the Site. BY LOGGING INTO THE SITE, YOU ARE BEING COMPLIANT THAT THESE TERMS and you represent that you have the authority and capacity to enter into these Terms. YOU SHOULD BE AT LEAST 18 YEARS OF AGE TO ACCESS THE SITE. IF YOU DISAGREE WITH ALL OF THE PROVISION OF THESE TERMS, DO NOT LOG INTO AND/OR USE THE SITE.<br><br>These terms require the use of arbitration Section 10.2 on an individual basis to resolve disputes and also limit the remedies available to you in the event of a dispute.</p><h4>Accounts</h4><b>Account Creation.</b> For you to use the Site, you have to start an account and provide information about yourself. You warrant that: (a) all required registration information you submit is truthful, up-to-date and accurate; (b) you will maintain the accuracy of such information. You may delete your Account at any time by following the instructions on the Site. Company may suspend or terminate your Account in accordance with Section.<br><br><b>Account Responsibilities.</b> You are responsible for maintaining the confidentiality of your Account login information and are fully responsible for all activities that occur under your Account. You approve to immediately notify the Company of any unauthorized use, or suspected unauthorized use of your Account. Company cannot and will not be liable for any loss or damage arising from your failure to comply with the above requirements.<br><br><h4>Access to the Site</h4><b>Subject to these Terms.</b> Company grants you a non-transferable, non-exclusive, revocable, limited license to access the Site solely for your own personal, noncommercial use.<br><br><b>Certain Restrictions.</b> The rights approved to you in these Terms are subject to the following restrictions: (a) you shall not sell, rent, lease, transfer, assign, distribute, host, or otherwise commercially exploit the Site; (b) you shall not change, make derivative works of, disassemble, reverse compile or reverse engineer any part of the Site; (c) you shall not access the Site in order to build a similar or competitive website; and (d) except as expressly stated herein, no part of the Site may be copied, reproduced, distributed, republished, downloaded, displayed, posted or transmitted in any form or by any means unless otherwise indicated, any future release, update, or other addition to functionality of the Site shall be subject to these Terms. All copyright and other proprietary notices on the Site must be retained on all copies thereof.<br><br>Company reserves the right to change, suspend, or cease the Site with or without notice to you. You approved that Company will not be held liable to you or any third-party for any change, interruption, or termination of the Site or any part.<br><br><b>No Support or Maintenance.</b> You agree that Company will have no obligation to provide you with any support in connection with the Site.<br><br>Excluding any User Content that you may provide, you are aware that all the intellectual property rights, including copyrights, patents, trademarks, and trade secrets, in the Site and its content are owned by Company or Company\'s suppliers. Note that these Terms and access to the Site do not give you any rights, title or interest in or to any intellectual property rights, except for the limited access rights expressed in Section 2.1. Company and its suppliers reserve all rights not granted in these Terms.<br><br><h4>User Content</h4><b>User Content.</b> “User Content” means any and all information and content that a user submits to the Site. You are exclusively responsible for your User Content. You bear all risks associated with use of your User Content. You hereby certify that your User Content does not violate our Acceptable Use Policy. You may not represent or imply to others that your User Content is in any way provided, sponsored or endorsed by Company. Because you alone are responsible for your User Content, you may expose yourself to liability. Company is not obliged to backup any User Content that you post; also, your User Content may be deleted at any time without prior notice to you. You are solely responsible for making your own backup copies of your User Content if you desire.<br><br>You hereby grant to Company an irreversible, nonexclusive, royalty-free and fully paid, worldwide license to reproduce, distribute, publicly display and perform, prepare derivative works of, incorporate into other works, and otherwise use and exploit your User Content, and to grant sublicenses of the foregoing rights, solely for the purposes of including your User Content in the Site. You hereby irreversibly waive any claims and assertions of moral rights or attribution with respect to your User Content.<br><br><b>Acceptable Use Policy.</b> The following terms constitute our “Acceptable Use Policy”: You agree not to use the Site to collect, upload, transmit, display, or distribute any User Content (i) that violates any third-party right or any intellectual property or proprietary right; (ii) that is unlawful, harassing, abusive, tortious, threatening, harmful, invasive of another\'s privacy, vulgar, defamatory, false, intentionally misleading, trade libelous, pornographic, obscene, patently offensive, promotes racism, bigotry, hatred, or physical harm of any kind against any group or individual; (iii) that is harmful to minors in any way; or (iv) that is in violation of any law, regulation, or obligations or restrictions imposed by any third party.<br><br>In addition, you agree not to: (i) upload, transmit, or distribute to or through the Site any software intended to damage or alter a computer system or data; (ii) send through the Site unsolicited or unauthorized advertising, promotional materials, junk mail, spam, chain letters, pyramid schemes, or any other form of duplicative or unsolicited messages; (iii) use the Site to harvest, collect, gather or assemble information or data regarding other users without their consent; (iv) interfere with, disrupt, or create an undue burden on servers or networks connected to the Site, or violate the regulations, policies or procedures of such networks; (v) attempt to gain unauthorized access to the Site, whether through password mining or any other means; (vi) harass or interfere with any other user\'s use and enjoyment of the Site; or (vi) use software or automated agents or scripts to produce multiple accounts on the Site, or to generate automated searches, requests, or queries to the Site.<br><br>We reserve the right to review any User Content, and to investigate and/or take appropriate action against you in our sole discretion if you violate the Acceptable Use Policy or any other provision of these Terms or otherwise create liability for us or any other person. Such action may include removing or modifying your User Content, terminating your Account in accordance with Section 8, and/or reporting you to law enforcement authorities.<br><br>If you provide Company with any feedback or suggestions regarding the Site, you hereby assign to Company all rights in such Feedback and agree that Company shall have the right to use and fully exploit such Feedback and related information in any manner it believes appropriate. Company will treat any Feedback you provide to Company as non-confidential and non-proprietary.<br><br>You agree to indemnify and hold Company and its officers, employees, and agents harmless, including costs and attorneys\' fees, from any claim or demand made by any third-party due to or arising out of (a) your use of the Site, (b) your violation of these Terms, (c) your violation of applicable laws or regulations or (d) your User Content. Company reserves the right to assume the exclusive defense and control of any matter for which you are required to indemnify us, and you agree to cooperate with our defense of these claims. You agree not to settle any matter without the prior written consent of Company. Company will use reasonable efforts to notify you of any such claim, action or proceeding upon becoming aware of it.<br><br><h4>Third-Party Links & Ads; Other Users</h4><b>Third-Party Links & Ads.</b> The Site may contain links to third-party websites and services, and/or display advertisements for third-parties. Such Third-Party Links & Ads are not under the control of Company, and Company is not responsible for any Third-Party Links & Ads. Company provides access to these Third-Party Links & Ads only as a convenience to you, and does not review, approve, monitor, endorse, warrant, or make any representations with respect to Third-Party Links & Ads. You use all Third-Party Links & Ads at your own risk, and should apply a suitable level of caution and discretion in doing so. When you click on any of the Third-Party Links & Ads, the applicable third party\'s terms and policies apply, including the third party\'s privacy and data gathering practices.<br><br><b>Other Users.</b> Each Site user is solely responsible for any and all of its own User Content. Because we do not control User Content, you acknowledge and agree that we are not responsible for any User Content, whether provided by you or by others. You agree that Company will not be responsible for any loss or damage incurred as the result of any such interactions. If there is a dispute between you and any Site user, we are under no obligation to become involved.<br><br>You hereby release and forever discharge the Company and our officers, employees, agents, successors, and assigns from, and hereby waive and relinquish, each and every past, present and future dispute, claim, controversy, demand, right, obligation, liability, action and cause of action of every kind and nature, that has arisen or arises directly or indirectly out of, or that relates directly or indirectly to, the Site. If you are a California resident, you hereby waive California civil code section 1542 in connection with the foregoing, which states: “a general release does not extend to claims which the creditor does not know or suspect to exist in his or her favor at the time of executing the release, which if known by him or her must have materially affected his or her settlement with the debtor.”<br><br><b>Cookies and Web Beacons.</b> Like any other website, rootCapture uses ‘cookies\'. These cookies are used to store information including visitors\' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users\' experience by customizing our web page content based on visitors\' browser type and/or other information.<br><br><h4>Disclaimers</h4>The site is provided on an “as-is” and “as available” basis, and company and our suppliers expressly disclaim any and all warranties and conditions of any kind, whether express, implied, or statutory, including all warranties or conditions of merchantability, fitness for a particular purpose, title, quiet enjoyment, accuracy, or non-infringement. We and our suppliers make not guarantee that the site will meet your requirements, will be available on an uninterrupted, timely, secure, or error-free basis, or will be accurate, reliable, free of viruses or other harmful code, complete, legal, or safe. If applicable law requires any warranties with respect to the site, all such warranties are limited in duration to ninety (90) days from the date of first use.<br><br>Some jurisdictions do not allow the exclusion of implied warranties, so the above exclusion may not apply to you. Some jurisdictions do not allow limitations on how long an implied warranty lasts, so the above limitation may not apply to you.<br><br><b>Limitation on Liability</b><br>To the maximum extent permitted by law, in no event shall company or our suppliers be liable to you or any third-party for any lost profits, lost data, costs of procurement of substitute products, or any indirect, consequential, exemplary, incidental, special or punitive damages arising from or relating to these terms or your use of, or incapability to use the site even if company has been advised of the possibility of such damages. Access to and use of the site is at your own discretion and risk, and you will be solely responsible for any damage to your device or computer system, or loss of data resulting therefrom.<br><br>To the maximum extent permitted by law, notwithstanding anything to the contrary contained herein, our liability to you for any damages arising from or related to this agreement, will at all times be limited to a maximum of fifty U.S. dollars (u.s. $50). The existence of more than one claim will not enlarge this limit. You agree that our suppliers will have no liability of any kind arising from or relating to this agreement.<br><br>Some jurisdictions do not allow the limitation or exclusion of liability for incidental or consequential damages, so the above limitation or exclusion may not apply to you.<br><br><b>Term and Termination.</b> Subject to this Section, these Terms will remain in full force and effect while you use the Site. We may suspend or terminate your rights to use the Site at any time for any reason at our sole discretion, including for any use of the Site in violation of these Terms. Upon termination of your rights under these Terms, your Account and right to access and use the Site will terminate immediately. You understand that any termination of your Account may involve deletion of your User Content associated with your Account from our live databases. Company will not have any liability whatsoever to you for any termination of your rights under these Terms. Even after your rights under these Terms are terminated, the following provisions of these Terms will remain in effect: Sections 2 through 2.5, Section 3 and Sections 4 through 10.<br><br><h4>Copyright Policy.</h4>Company respects the intellectual property of others and asks that users of our Site do the same. In connection with our Site, we have adopted and implemented a policy respecting copyright law that provides for the removal of any infringing materials and for the termination of users of our online Site who are repeated infringers of intellectual property rights, including copyrights. If you believe that one of our users is, through the use of our Site, unlawfully infringing the copyright(s) in a work, and wish to have the allegedly infringing material removed, the following information in the form of a written notification (pursuant to 17 U.S.C. § 512(c)) must be provided to our designated Copyright Agent:<p></p><ul><li>your physical or electronic signature;</li><li>identification of the copyrighted work(s) that you claim to have been infringed;</li><li>identification of the material on our services that you claim is infringing and that you request us to remove;</li><li>sufficient information to permit us to locate such material;</li><li>your address, telephone number, and e-mail address;</li><li>a statement that you have a good faith belief that use of the objectionable material is not authorized by the copyright owner, its agent, or under the law; and</li><li>a statement that the information in the notification is accurate, and under penalty of perjury, that you are either the owner of the copyright that has allegedly been infringed or that you are authorized to act on behalf of the copyright owner.</li><li>Please note that, pursuant to 17 U.S.C. § 512(f), any misrepresentation of material fact in a written notification automatically subjects the complaining party to liability for any damages, costs and attorney\'s fees incurred by us in connection with the written notification and allegation of copyright infringement.</li></ul><p></p><h4>General</h4>These Terms are subject to occasional revision, and if we make any substantial changes, we may notify you by sending you an e-mail to the last e-mail address you provided to us and/or by prominently posting notice of the changes on our Site. You are responsible for providing us with your most current e-mail address. In the event that the last e-mail address that you have provided us is not valid our dispatch of the e-mail containing such notice will nonetheless constitute effective notice of the changes described in the notice. Any changes to these Terms will be effective upon the earliest of thirty (30) calendar days following our dispatch of an e-mail notice to you or thirty (30) calendar days following our posting of notice of the changes on our Site. These changes will be effective immediately for new users of our Site. Continued use of our Site following notice of such changes shall indicate your acknowledgement of such changes and agreement to be bound by the terms and conditions of such changes. Dispute Resolution. Please read this Arbitration Agreement carefully. It is part of your contract with Company and affects your rights. It contains procedures for MANDATORY BINDING ARBITRATION AND A CLASS ACTION WAIVER.<br><br><b>Applicability of Arbitration Agreement.</b> All claims and disputes in connection with the Terms or the use of any product or service provided by the Company that cannot be resolved informally or in small claims court shall be resolved by binding arbitration on an individual basis under the terms of this Arbitration Agreement. Unless otherwise agreed to, all arbitration proceedings shall be held in English. This Arbitration Agreement applies to you and the Company, and to any subsidiaries, affiliates, agents, employees, predecessors in interest, successors, and assigns, as well as all authorized or unauthorized users or beneficiaries of services or goods provided under the Terms.<br><br><b>Notice Requirement and Informal Dispute Resolution.</b> Before either party may seek arbitration, the party must first send to the other party a written Notice of Dispute describing the nature and basis of the claim or dispute, and the requested relief. A Notice to the Company should be sent to: YOUR COMPANY ADDRESS. After the Notice is received, you and the Company may attempt to resolve the claim or dispute informally. If you and the Company do not resolve the claim or dispute within thirty (30) days after the Notice is received, either party may begin an arbitration proceeding. The amount of any settlement offer made by any party may not be disclosed to the arbitrator until after the arbitrator has determined the amount of the award to which either party is entitled.<br><br><b>Arbitration Rules.</b> Arbitration shall be initiated through the American Arbitration Association, an established alternative dispute resolution provider that offers arbitration as set forth in this section. If AAA is not available to arbitrate, the parties shall agree to select an alternative ADR Provider. The rules of the ADR Provider shall govern all aspects of the arbitration except to the extent such rules are in conflict with the Terms. The AAA Consumer Arbitration Rules governing the arbitration are available online at adr.org or by calling the AAA at 1-800-778-7879. The arbitration shall be conducted by a single, neutral arbitrator. Any claims or disputes where the total amount of the award sought is less than Ten Thousand U.S. Dollars (US $10,000.00) may be resolved through binding non-appearance-based arbitration, at the option of the party seeking relief. For claims or disputes where the total amount of the award sought is Ten Thousand U.S. Dollars (US $10,000.00) or more, the right to a hearing will be determined by the Arbitration Rules. Any hearing will be held in a location within 100 miles of your residence, unless you reside outside of the United States, and unless the parties agree otherwise. If you reside outside of the U.S., the arbitrator shall give the parties reasonable notice of the date, time and place of any oral hearings. Any judgment on the award rendered by the arbitrator may be entered in any court of competent jurisdiction. If the arbitrator grants you an award that is greater than the last settlement offer that the Company made to you prior to the initiation of arbitration, the Company will pay you the greater of the award or $2,500.00. Each party shall bear its own costs and disbursements arising out of the arbitration and shall pay an equal share of the fees and costs of the ADR Provider.<br><br><b>Additional Rules for Non-Appearance Based Arbitration. </b>If non-appearance based arbitration is elected, the arbitration shall be conducted by telephone, online and/or based solely on written submissions; the specific manner shall be chosen by the party initiating the arbitration. The arbitration shall not involve any personal appearance by the parties or witnesses unless otherwise agreed by the parties.<br><br><b>Time Limits.</b> If you or the Company pursues arbitration, the arbitration action must be initiated and/or demanded within the statute of limitations and within any deadline imposed under the AAA Rules for the pertinent claim.<br><br><b>Authority of Arbitrator.</b> If arbitration is initiated, the arbitrator will decide the rights and liabilities of you and the Company, and the dispute will not be consolidated with any other matters or joined with any other cases or parties. The arbitrator shall have the authority to grant motions dispositive of all or part of any claim. The arbitrator shall have the authority to award monetary damages, and to grant any non-monetary remedy or relief available to an individual under applicable law, the AAA Rules, and the Terms. The arbitrator shall issue a written award and statement of decision describing the essential findings and conclusions on which the award is based. The arbitrator has the same authority to award relief on an individual basis that a judge in a court of law would have. The award of the arbitrator is final and binding upon you and the Company.<br><br><b>Waiver of Jury Trial.</b> THE PARTIES HEREBY WAIVE THEIR CONSTITUTIONAL AND STATUTORY RIGHTS TO GO TO COURT AND HAVE A TRIAL IN FRONT OF A JUDGE OR A JURY, instead electing that all claims and disputes shall be resolved by arbitration under this Arbitration Agreement. Arbitration procedures are typically more limited, more efficient and less expensive than rules applicable in a court and are subject to very limited review by a court. In the event any litigation should arise between you and the Company in any state or federal court in a suit to vacate or enforce an arbitration award or otherwise, YOU AND THE COMPANY WAIVE ALL RIGHTS TO A JURY TRIAL, instead electing that the dispute be resolved by a judge.<br><br><b>Waiver of Class or Consolidated Actions.</b> All claims and disputes within the scope of this arbitration agreement must be arbitrated or litigated on an individual basis and not on a class basis, and claims of more than one customer or user cannot be arbitrated or litigated jointly or consolidated with those of any other customer or user.<br><br><b>Confidentiality.</b> All aspects of the arbitration proceeding shall be strictly confidential. The parties agree to maintain confidentiality unless otherwise required by law. This paragraph shall not prevent a party from submitting to a court of law any information necessary to enforce this Agreement, to enforce an arbitration award, or to seek injunctive or equitable relief.<br><br><b>Severability.</b> If any part or parts of this Arbitration Agreement are found under the law to be invalid or unenforceable by a court of competent jurisdiction, then such specific part or parts shall be of no force and effect and shall be severed and the remainder of the Agreement shall continue in full force and effect.<br><br><b>Right to Waive.</b> Any or all of the rights and limitations set forth in this Arbitration Agreement may be waived by the party against whom the claim is asserted. Such waiver shall not waive or affect any other portion of this Arbitration Agreement.<br><br><b>Survival of Agreement.</b> This Arbitration Agreement will survive the termination of your relationship with Company.<br><br><b>Small Claims Court.</b> Nonetheless the foregoing, either you or the Company may bring an individual action in small claims court.<br><br><b>Emergency Equitable Relief.</b> Anyhow the foregoing, either party may seek emergency equitable relief before a state or federal court in order to maintain the status quo pending arbitration. A request for interim measures shall not be deemed a waiver of any other rights or obligations under this Arbitration Agreement.<br><br><b>Claims Not Subject to Arbitration.</b> Notwithstanding the foregoing, claims of defamation, violation of the Computer Fraud and Abuse Act, and infringement or misappropriation of the other party\'s patent, copyright, trademark or trade secrets shall not be subject to this Arbitration Agreement.<br><br>In any circumstances where the foregoing Arbitration Agreement permits the parties to litigate in court, the parties hereby agree to submit to the personal jurisdiction of the courts located within Netherlands County, California, for such purposes.<br><br>The Site may be subject to U.S. export control laws and may be subject to export or import regulations in other countries. You agree not to export, re-export, or transfer, directly or indirectly, any U.S. technical data acquired from Company, or any products utilizing such data, in violation of the United States export laws or regulations.<br><br>Company is located at the address in Section 10.8. If you are a California resident, you may report complaints to the Complaint Assistance Unit of the Division of Consumer Product of the California Department of Consumer Affairs by contacting them in writing at 400 R Street, Sacramento, CA 95814, or by telephone at (800) 952-5210.<br><br><b>Electronic Communications.</b> The communications between you and Company use electronic means, whether you use the Site or send us emails, or whether Company posts notices on the Site or communicates with you via email. For contractual purposes, you (a) consent to receive communications from Company in an electronic form; and (b) agree that all terms and conditions, agreements, notices, disclosures, and other communications that Company provides to you electronically satisfy any legal obligation that such communications would satisfy if it were be in a hard copy writing.<br><br><b>Entire Terms.</b> These Terms constitute the entire agreement between you and us regarding the use of the Site. Our failure to exercise or enforce any right or provision of these Terms shall not operate as a waiver of such right or provision. The section titles in these Terms are for convenience only and have no legal or contractual effect. The word “including” means “including without limitation”. If any provision of these Terms is held to be invalid or unenforceable, the other provisions of these Terms will be unimpaired and the invalid or unenforceable provision will be deemed modified so that it is valid and enforceable to the maximum extent permitted by law. Your relationship to Company is that of an independent contractor, and neither party is an agent or partner of the other. These Terms, and your rights and obligations herein, may not be assigned, subcontracted, delegated, or otherwise transferred by you without Company\'s prior written consent, and any attempted assignment, subcontract, delegation, or transfer in violation of the foregoing will be null and void. Company may freely assign these Terms. The terms and conditions set forth in these Terms shall be binding upon assignees.<br><br><b>Copyright/Trademark Information.</b> Copyright ©. All rights reserved. All trademarks, logos and service marks displayed on the Site are our property or the property of other third-parties. You are not permitted to use these Marks without our prior written consent or the consent of such third party which may own the Marks.<br><br><h4>Contact Information</h4><b>Email:</b> contact@rootcapture.com','This is rootCaptures Terms of Use policy.','terms of use, terms, policy',1664597685,1611744608),(2,'<p>At rootCapture, accessible at https://rootcapture.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by rootCapture and how we use it.<br><br>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.<br><br>This privacy policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in rootcapture.com. This policy is not applicable to any information collected offline or via channels other than this website.<br><br><b>Consent</b><br>By using our website, you hereby consent to our Privacy Policy and agree to its terms.<br><br><b>Information we collect</b><br>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.<br><br>If you contact us directly, we may receive additional information about you such as your name, email address, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.<br><br>When you register for an Account, we may ask for your contact information, including items such as name, and email address.<br><br><b>How we use your information</b><br>We use the information we collect in various ways, including to:</p><ul><li>Provide, operate, and maintain our website</li><li>Improve, personalize, and expand our website</li><li>Understand and analyze how you use our website</li><li>Develop new products, services, features, and functionality</li><li>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes</li><li>Send you emails</li><li>Find and prevent fraud</li></ul><p><b>Log Files<br></b>rootCapture follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services\' analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users\' movement on the website, and gathering demographic information.<br><br><b>Cookies and Web Beacons</b><br>Like any other website, rootCapture uses ‘cookies\'. These cookies are used to store information including visitors\' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users\' experience by customizing our web page content based on visitors\' browser type and/or other information.<br><br><b>Advertising Partners Privacy Policies</b><br>You may consult this list to find the Privacy Policy for each of the advertising partners of rootCapture.<br><br>Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on rootCapture, which are sent directly to users\' browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.<br><br>Note that rootCapture has no access to or control over these cookies that are used by third-party advertisers.<br><br><b>Third-Party Privacy Policies</b><br>rootCapture\'s Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options.<br><br>You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers\' respective websites.<br><br><b>CCPA Privacy Policy (Do Not Sell My Personal Information)</b><br>Under the CCPA, among other rights, California consumers have the right to:</p><ul><li>Request that a business that collects a consumer\'s personal data disclose the categories and specific pieces of personal data that a business has collected about consumers.</li><li>Request that a business delete any personal data about the consumer that a business has collected.</li><li>Request that a business that sells a consumer\'s personal data, not sell the consumer\'s personal data.</li><li>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.</li></ul><p><b>GDPR Privacy Policy (Data Protection Rights)</b><br>We would like to make sure you are fully aware of all of your data protection rights. Every user is entitled to the following:</p><ul><li>The right to access – You have the right to request copies of your personal data. We may charge you a small fee for this service.</li><li>The right to rectification – You have the right to request that we correct any information you believe is inaccurate. You also have the right to request that we complete the information you believe is incomplete.</li><li>The right to erasure – You have the right to request that we erase your personal data, under certain conditions.</li><li>The right to restrict processing – You have the right to request that we restrict the processing of your personal data, under certain conditions.</li><li>The right to object to processing – You have the right to object to our processing of your personal data, under certain conditions.</li><li>The right to data portability – You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.</li><li>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.</li></ul><p><b>Children\'s Information</b><br>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.<br><br>rootCapture does not knowingly collect any Personal Identifiable Information from children under the age of 18. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>','rootCapture\'s privacy policy.','privacy policy, visitor\'s privacy, privacy',1664597622,1611744759);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `access_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Canned Replies','canned_replies'),(2,'Tickets','tickets'),(3,'All Tickets','all_tickets'),(4,'Departments','departments'),(5,'Knowledge Base','knowledge_base'),(6,'FAQs','faqs'),(7,'Announcements','announcements'),(8,'Backup','backup'),(9,'Email Templates','email_templates'),(10,'Pages','pages'),(11,'Impersonate','impersonate'),(12,'Users','users'),(13,'Roles & Permissions','roles_and_permissions'),(14,'Settings','settings'),(15,'Chats','chats'),(16,'All Chats','all_chats'),(17,'Reports','reports'),(18,'Custom Fields','custom_fields');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `users` int(10) unsigned NOT NULL,
  `opened_tickets` int(10) unsigned NOT NULL,
  `closed_tickets` int(10) unsigned NOT NULL,
  `solved_tickets` int(10) unsigned NOT NULL,
  `total_tickets` int(10) unsigned NOT NULL,
  `active_chats` int(10) unsigned NOT NULL,
  `ended_chats` int(10) unsigned NOT NULL,
  `total_chats` int(10) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `generated_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `access_key` varchar(50) NOT NULL,
  `is_built_in` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','super_admin',1),(2,'Agent','agent',1),(3,'User','user',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_permissions`
--

DROP TABLE IF EXISTS `roles_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` tinyint(3) unsigned NOT NULL,
  `permission_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_permissions`
--

LOCK TABLES `roles_permissions` WRITE;
/*!40000 ALTER TABLE `roles_permissions` DISABLE KEYS */;
INSERT INTO `roles_permissions` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,2,1),(16,2,2),(17,1,15),(18,1,16),(19,2,15),(20,1,17),(21,1,18);
/*!40000 ALTER TABLE `roles_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `access_key` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_key` (`access_key`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'auto_close_tickets','1'),(2,'create_ticket_page_message','Please note that due to COVID-19, our response time can be up to 2 business days.'),(3,'e_encryption',''),(4,'e_host',''),(5,'e_password',''),(6,'e_port',''),(7,'e_protocol','mail'),(8,'e_sender','support@rootcapture.com'),(9,'e_sender_name','rootCapture Support'),(10,'e_username',''),(11,'fb_app_id',''),(12,'fb_app_secret',''),(13,'fb_enable_login','0'),(14,'gl_client_key',''),(15,'gl_enable','0'),(16,'gl_secret_key',''),(17,'google_analytics_id',''),(18,'gr_enable','0'),(19,'gr_public_key',''),(20,'gr_secret_key',''),(21,'ipinfo_token',''),(22,'maintenance_mode','0'),(23,'mm_allowed_ips',''),(24,'mm_message','We\'re very sorry for the inconvenience, the site is currently undergoing scheduled maintenance.'),(25,'show_tp_message','1'),(26,'site_about','Welcome to rootCapture\'s Enterprise Support System, here you can find critical guides and if you are an enterprise customer, seek enterprise support or assistance from our team.'),(27,'site_color','1'),(28,'site_description','rootCapture\'s Enterprise Support System.'),(29,'site_favicon','c85be6bf45e114201b33bd1f49f8a919.png'),(30,'site_keywords','rootCapture, Support, System, rootCapture Enterprise Support System, Enterprise, rootCapture System, rootCapture Enterprise'),(31,'site_logo','c85be6bf45e114201b33bd1f49f8a919.png'),(32,'site_name','rootCapture'),(33,'site_show_cookie_popup','1'),(34,'site_tagline','rootCapture Support'),(35,'site_theme','default'),(36,'site_timezone','America/Phoenix'),(37,'sp_allow_ticket_reopen','0'),(38,'sp_email_notifications','1'),(39,'sp_verification_before_submit','0'),(40,'tw_consumer_key',''),(41,'tw_consumer_secret',''),(42,'tw_enable_login','0'),(43,'u_allow_username_change','1'),(44,'u_can_remove_them','0'),(45,'u_enable_registration','1'),(46,'u_lockout_unlock_time','1'),(47,'u_max_avator_size','500x500'),(48,'u_notify_pass_changed','1'),(49,'u_password_requirement','low'),(50,'u_req_ev_onchange','1'),(51,'u_reset_password','1'),(52,'u_temporary_lockout','medium'),(53,'sp_live_chatting','0'),(54,'sp_guest_ticketing','0'),(55,'i_pc_string','7bd62c75-32e4-4fda-b427-b6c7a7aef305'),(56,'i_pc_status','0'),(57,'i_at','1662673788');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(90) NOT NULL,
  `message` text NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `attachment_name` varchar(255) NOT NULL,
  `priority` varchar(10) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `department_id` tinyint(3) unsigned NOT NULL,
  `security_key` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `is_verified` tinyint(3) unsigned DEFAULT NULL,
  `email_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `last_email_attempt` int(10) unsigned DEFAULT NULL,
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_read_assigned` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `last_agent_replied_at` int(10) unsigned DEFAULT NULL,
  `reopened_awaiting` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `last_reply_area` tinyint(3) unsigned DEFAULT NULL,
  `sub_status` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `closed_by` int(10) unsigned DEFAULT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_month_year` varchar(7) NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,'Test','Test please do test me okay','','','low',2,NULL,1,'','',NULL,0,NULL,0,1,NULL,0,2,1,1,NULL,1699425520,'11-2023',1699425491),(2,'Test','TestASASASASASASS','','','medium',2,NULL,1,'','',NULL,0,NULL,0,1,NULL,0,NULL,1,1,NULL,NULL,'11-2023',1699425577),(3,'CRITICAL CRITICAL','CRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICALCRITICAL CRITICAL','','','high',2,NULL,1,'','',NULL,0,NULL,0,1,NULL,0,NULL,1,0,2,1699425764,'11-2023',1699425603);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_custom_fields`
--

DROP TABLE IF EXISTS `tickets_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `custom_field_id` tinyint(3) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_custom_fields`
--

LOCK TABLES `tickets_custom_fields` WRITE;
/*!40000 ALTER TABLE `tickets_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_departments`
--

DROP TABLE IF EXISTS `tickets_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_departments` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `team` text NOT NULL,
  `visibility` tinyint(3) unsigned NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_departments`
--

LOCK TABLES `tickets_departments` WRITE;
/*!40000 ALTER TABLE `tickets_departments` DISABLE KEYS */;
INSERT INTO `tickets_departments` VALUES (1,'General Inquiries','{\"users\":[1]}',1,NULL,1611213421);
/*!40000 ALTER TABLE `tickets_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_history`
--

DROP TABLE IF EXISTS `tickets_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_key` varchar(255) NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_history`
--

LOCK TABLES `tickets_history` WRITE;
/*!40000 ALTER TABLE `tickets_history` DISABLE KEYS */;
INSERT INTO `tickets_history` VALUES (1,'av_ticket_created_user',1,NULL,1699425491),(2,'av_ticket_solved_user',1,NULL,1699425511),(3,'av_ticket_replied_user',1,NULL,1699425520),(4,'av_ticket_created_user',2,NULL,1699425577),(5,'av_ticket_created_user',3,NULL,1699425603),(6,'av_ticket_closed_user',3,NULL,1699425764);
/*!40000 ALTER TABLE `tickets_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_replies`
--

DROP TABLE IF EXISTS `tickets_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `message` text NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `attachment_name` varchar(255) NOT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `replied_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_replies`
--

LOCK TABLES `tickets_replies` WRITE;
/*!40000 ALTER TABLE `tickets_replies` DISABLE KEYS */;
INSERT INTO `tickets_replies` VALUES (1,1,2,'asasas','','',NULL,1699425520);
/*!40000 ALTER TABLE `tickets_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `pending_email_address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL DEFAULT 'default.png',
  `date_format` varchar(10) NOT NULL DEFAULT 'd/m/Y',
  `time_format` varchar(10) NOT NULL DEFAULT 'H:i:s',
  `timezone` varchar(32) NOT NULL,
  `language` varchar(255) NOT NULL,
  `role` tinyint(3) unsigned NOT NULL,
  `is_online` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `online_time` int(10) unsigned DEFAULT NULL,
  `online_date` varchar(10) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `is_verified` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `send_email_notifications` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `announcements_last_read_at` int(10) unsigned DEFAULT NULL,
  `last_activity` int(10) unsigned DEFAULT NULL,
  `last_login` int(10) unsigned DEFAULT NULL,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `registration_source` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `oauth_identifier` varchar(255) NOT NULL,
  `registered_month_year` varchar(7) NOT NULL,
  `registered_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_address` (`email_address`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super','Admin','superadmin','support@rootcapture.com','','$2a$10$tJMCUTHyqVeF9BQ6osClTewXoaYMuX0jF.Q81UMfnCwHUru.lcELe','default.png','d/m/Y','H:i:s','','',1,1,1665115162,'2022-10-06',1,1,1,NULL,1665115244,1665113711,NULL,1,'','9-2022',1662673788),(2,'Super','Admin','suuser','demo@rootcapture.com','maxafter@gmail.com','$2y$10$YktFCVR3dWu2C0yKps34I.6eUCUSppxYGH7ZomBis3B0wRyAkcxde','default.png','d/m/Y','H:i:s','','',1,1,1699508577,'2023-11-08',1,1,1,NULL,1699508765,1699508577,1698990621,1,'','9-2022',1662673788);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_invites`
--

DROP TABLE IF EXISTS `users_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_invites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_address` varchar(255) NOT NULL,
  `invitation_code` varchar(32) NOT NULL,
  `expires_in` tinyint(3) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `bypass_registration` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `updated_at` int(10) unsigned DEFAULT NULL,
  `invited_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_invites`
--

LOCK TABLES `users_invites` WRITE;
/*!40000 ALTER TABLE `users_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_sent_emails`
--

DROP TABLE IF EXISTS `users_sent_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_sent_emails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `sent_to` int(10) unsigned NOT NULL,
  `sent_by` int(10) unsigned NOT NULL,
  `sent_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_sent_emails`
--

LOCK TABLES `users_sent_emails` WRITE;
/*!40000 ALTER TABLE `users_sent_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_sent_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_sessions`
--

DROP TABLE IF EXISTS `users_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `platform` varchar(255) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `interface` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `last_activity` int(10) unsigned DEFAULT NULL,
  `last_location` varchar(255) NOT NULL,
  `logged_in_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_sessions`
--

LOCK TABLES `users_sessions` WRITE;
/*!40000 ALTER TABLE `users_sessions` DISABLE KEYS */;
INSERT INTO `users_sessions` VALUES (4,1,'b7560f60441b7b90c36aebc745509d5e68ecc766ff4f2fb303ec4e79ab3cdb66ad7eab53631aa1172c253','70.175.24.196','Windows 10','Chrome',1,1662690748,'admin/settings/general',1662689559),(5,1,'89eae39b1a66a16feae7956f5824aa3311e7d0b68b053fbf1916645b8c46b8a440668ef6631b4d521a3af','72.200.103.144','Windows 10','Chrome',1,1662733675,'actions/admin/settings/test_email_settings',1662733650),(8,1,'655c2d0b540be6828d490debf7a37c385860bcab7299ca6ffec9eb117184c3a8b612e93963295a1b8fc15','72.200.103.144','Windows 10','Chrome',1,1663654524,'',1663654427),(9,1,'774db55f277853d1e99d795a912b3516ade878dc6953a2db80c6b5e9b0e48d56b824dea1633753289281b','184.180.186.178','Windows 10','Chrome',1,1664570170,'admin/pages',1664570152),(10,1,'62952c8e8b168dfe087a8549cde6c4581266d0a46544dcc36c30806665ab514bff3734ab6337bbdd34e4e','72.200.103.144','Windows 10','Chrome',1,1664597685,'admin/pages',1664596957),(12,1,'246a35cf75f93474523c969b1d486e22fd74933420712f33af320f6ce3b0370b2d8137fd633f4a51831c1','184.180.186.178','Windows 10','Chrome',1,1665100761,'faqs',1665092177),(13,1,'7f508de6a097854845cc638220a0093453324d34a2132337c99e873f93ed79bf4a1f028b633f9e6fa45e1','72.200.103.144','Windows 10','Chrome',1,1665115244,'actions/admin/support/edit_faq',1665113711),(14,2,'5aa2985e9a470b9c70946fd386892abcfbab9d860fc14d994a1bbe229b22b44c8da64cfb6544893fd5e93','174.172.110.201','Windows 10','Chrome',1,1698990715,'',1698990399),(17,2,'eb2e349d6168b703d140e802d1017b8ad4d47c193e99516121fa7c0eda2b757c6e9fc64f6549fd88a759f','154.192.48.85','Windows 10','Firefox',1,1699348845,'user/account/profile_settings',1699347848),(19,2,'5d121feb3e1a83f4765a81c0a8f8812040aa00195d17fa00ce63f9b93b62904eba928bd0654c71612515f','154.192.47.65','Windows 10','Firefox',1,1699508765,'user/support/tickets/all',1699508577);
/*!40000 ALTER TABLE `users_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rootCaptKB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-17 18:53:43
