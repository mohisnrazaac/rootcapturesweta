-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: rootCapCre
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `antlets`
--

DROP TABLE IF EXISTS `antlets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antlets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src_dname` varchar(150) NOT NULL,
  `compression` varchar(150) NOT NULL,
  `dst_dname` varchar(150) NOT NULL,
  `snapshot_name` varchar(150) NOT NULL,
  `antlet_num` int(11) NOT NULL,
  `zpool_name` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antlets`
--

LOCK TABLES `antlets` WRITE;
/*!40000 ALTER TABLE `antlets` DISABLE KEYS */;
INSERT INTO `antlets` VALUES (1,'Backbox','inherit','BackboxAnk','BackboxAnk',25,'antlets',2,1,'2023-12-01 23:42:06','2023-12-06 22:52:52'),(2,'Backbox','inherit','BackboxSweta','BackboxSweta',26,'antlets',2,1,'2023-12-02 21:15:06','2023-12-18 23:25:55');
/*!40000 ALTER TABLE `antlets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_management`
--

DROP TABLE IF EXISTS `api_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_management` (
  `api_id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) DEFAULT NULL,
  `api_name` varchar(255) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `api_members` varchar(255) NOT NULL,
  `api_function` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `timestamp` int(25) NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`api_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_management`
--

LOCK TABLES `api_management` WRITE;
/*!40000 ALTER TABLE `api_management` DISABLE KEYS */;
INSERT INTO `api_management` VALUES (5,1,'Add New Grade','ILzycB9mSGcqjpp','5,8,12','Add The Grade(s)',0,1674796996,'2023-01-12'),(6,1,'Edit Grade','6REdFqHrUBiECsV','5,8,12','Edit The Grade(s)',0,1674796893,'2023-01-12'),(10,1,'Delete The Grade','2CoX03lJwdIZbVr','5,8,12','Delete The Grade(s)',0,1674798707,'2023-01-27'),(11,1,'Get Grading Rubric','KBjBWCLocI2HEnd','5,8,12','Get Grading Rubric Criterion',0,1674799729,'2023-01-27'),(12,1,'Delete Grading Rubric','LLfRIFFOfygsMpZ','5,8,12','Delete Grading Rubric Criterion',0,1674802320,'2023-01-27'),(13,1,'Add Grading Rubric','U6LNdEkibnwmzl9','5,8,12','Add Grading Rubric Criterion',0,1686756948,'2023-01-27'),(14,1,'Edit Grading Rubric','1glBIkuN3w4hqfU','5,8,12','Edit Grading Rubric Criterion',0,1674807436,'2023-01-27'),(17,3,'Get The Grade','tOSEbiIRaZdPwIE','16','Get The Grade(s)',0,1686758993,'2023-06-14');
/*!40000 ALTER TABLE `api_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `system_name` varchar(50) NOT NULL,
  `system_ip` varchar(50) NOT NULL,
  `operating_system` varchar(50) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  `asset_group` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
INSERT INTO `asset` VALUES (2,3,'basic programming','102.101.30.20','windows',3,'https://www.unicorntechmedia.com',1),(3,6,'Red System','192.168.0.23','linux',3,'abc.com',3),(4,9,'My System','101.101.101.000','windows',3,'https://www.instagram.com/p/CdQ8fZHMoE9/',5),(7,1,'windows feature','102.101.30.20','windows',4,'https://www.unicorntechmedia.com',8),(8,1,'test system','102.101.30.20','android',11,'https://www.unicorntechmedia.comss',10);
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_group`
--

DROP TABLE IF EXISTS `asset_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) NOT NULL,
  `operating_system` varchar(50) NOT NULL,
  `team` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_group`
--

LOCK TABLES `asset_group` WRITE;
/*!40000 ALTER TABLE `asset_group` DISABLE KEYS */;
INSERT INTO `asset_group` VALUES (1,3,'Windows core','windows',3),(3,6,'Red Group','linux',3),(5,9,'Test group','windows',3),(8,1,'Learn Linux','linux',4),(9,10,'Windows XP','windows',13),(10,1,'test groups','linux',11);
/*!40000 ALTER TABLE `asset_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bluepho`
--

DROP TABLE IF EXISTS `bluepho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluepho` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluepho`
--

LOCK TABLES `bluepho` WRITE;
/*!40000 ALTER TABLE `bluepho` DISABLE KEYS */;
INSERT INTO `bluepho` VALUES (3,'test bluepho','102.12.13.14',5,4,'');
/*!40000 ALTER TABLE `bluepho` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blueservers`
--

DROP TABLE IF EXISTS `blueservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blueservers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blueservers`
--

LOCK TABLES `blueservers` WRITE;
/*!40000 ALTER TABLE `blueservers` DISABLE KEYS */;
INSERT INTO `blueservers` VALUES (1,'test blue','104.15.23.78',1,4,'hjbfhsbfhb');
/*!40000 ALTER TABLE `blueservers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bluevuln`
--

DROP TABLE IF EXISTS `bluevuln`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluevuln` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluevuln`
--

LOCK TABLES `bluevuln` WRITE;
/*!40000 ALTER TABLE `bluevuln` DISABLE KEYS */;
INSERT INTO `bluevuln` VALUES (2,'test bluevuln','102.103.10.12',4,4,'');
/*!40000 ALTER TABLE `bluevuln` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `college_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_check` (`enterprise_id`,`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,1,'Categ',1,1,'2023-08-12 01:18:25','2023-08-12 01:18:25');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `chatid` int(11) NOT NULL AUTO_INCREMENT,
  `sender_userid` int(11) NOT NULL,
  `reciever_userid` int(11) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `message` text NOT NULL,
  `timestamp` int(25) NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL,
  `delete` int(1) NOT NULL DEFAULT 0,
  `forward` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`chatid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (1,2,8,0,'Hi John',1689011838,0,0,1),(2,2,8,0,'John ?',1689012819,0,0,1),(3,2,8,0,'HI john',1689094967,0,0,1),(4,2,8,0,'Hi john',1689096458,0,0,1),(5,2,8,0,'Hi john this time it should be work man.',1689096471,0,0,1),(6,2,8,0,'Hello john this should be work',1689096744,0,0,1),(7,2,8,0,'Hi john date is 13 jully',1689271964,0,0,1),(8,8,2,0,'oh yeah baby',1689271993,0,0,1),(9,2,8,0,'Hey tody',1689272281,0,0,1),(10,8,2,0,'hi',1689272415,0,0,1),(11,8,2,0,'hi',1689272437,0,0,1),(12,8,2,0,'hellp',1689272479,0,0,1),(13,2,8,0,'hi',1689442591,0,0,1),(14,2,8,0,'hi',1689442785,0,0,1),(15,2,8,0,'hi',1689443135,0,0,1),(16,8,2,0,'hey',1689443533,0,0,1),(17,8,2,0,'15 july',1689443703,0,0,1),(18,8,2,0,'hi',1689443811,0,0,1),(19,8,2,0,'hi',1689443854,0,0,1),(20,8,2,0,'hi',1689444323,0,0,1),(21,2,8,0,'hi',1689444465,0,0,1),(22,8,2,0,'hi',1689444479,0,0,1),(23,2,8,0,'hello iit delhi',1689444579,0,0,1),(24,2,8,0,'Hi IIT',1689444694,0,0,1),(25,2,8,0,'HEY IIT',1689444732,0,0,1),(26,8,2,0,'hi john',1689444869,0,0,1),(27,8,2,0,'hey',1689445010,0,0,1),(28,8,2,0,'hello john',1689445128,0,0,1),(29,2,8,0,'hi iit',1689445161,0,0,1),(30,8,2,0,'hello john',1689445176,0,0,1),(31,2,8,0,'hi',1689445502,0,0,1),(32,8,2,0,'hi',1689445518,0,0,1),(33,8,2,0,'hi',1689445521,0,0,1),(34,2,8,0,'hi iit',1689445976,0,0,1),(35,2,8,0,'hh',1689445992,0,0,1),(36,2,8,0,'hi',1689446153,0,0,1),(37,8,2,0,'hiii',1689446163,0,0,1),(38,8,2,0,'hi',1689446166,0,0,1),(39,2,8,0,'hey iit',1689446538,0,0,1),(40,2,8,0,'hi',1689446548,0,0,1),(41,2,8,0,'hi',1689446562,0,0,1),(42,8,2,0,'hi',1689446649,0,0,1),(43,8,2,0,'hi iit',1689703523,0,0,1),(44,8,2,0,'hi iit',1689703539,0,0,1),(45,2,8,0,'hola',1689703609,0,0,1),(46,8,0,0,'hi 0',1689703634,0,0,1),(47,8,2,0,'hi',1689703675,0,0,1),(48,2,0,0,'$insertChats = $odb -> prepare(\"INSERT INTO `chat_group_msg` (`group_id`, `sender_id`, `msg`) VALUES(:group_id, :sender_id, :chat_message)\");             $insertChats -> execute(array(\':group_id\' => $group_id, \':sender_id\' => $user_id, \':chat_message\' => $chat_message));',1691548230,0,0,1),(49,2,0,0,'$insertChats = $odb -> prepare(\"INSERT INTO `chat_group_msg` (`group_id`, `sender_id`, `msg`) VALUES(:group_id, :sender_id, :chat_message)\");             $insertChats -> execute(array(\':group_id\' => $group_id, \':sender_id\' => $user_id, \':chat_message\' => $chat_message));',1691548231,0,0,1),(50,2,8,0,'hello',1691549119,0,0,1),(51,2,8,0,'----------------------------------------------',1691598283,0,0,1),(52,2,8,0,'8 Aug',1691598323,0,0,1),(53,8,2,0,'yeah',1691598353,0,0,1);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_channel`
--

DROP TABLE IF EXISTS `chat_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_one` int(11) NOT NULL,
  `user_two` int(11) NOT NULL,
  `channel_name` varchar(30) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_channel`
--

LOCK TABLES `chat_channel` WRITE;
/*!40000 ALTER TABLE `chat_channel` DISABLE KEYS */;
INSERT INTO `chat_channel` VALUES (1,2,8,'private-chat28',1,'2023-07-08 19:59:20'),(2,2,3,'private-chat23',1,'2023-07-09 12:42:35'),(3,8,0,'private-chat80',1,'2023-07-19 15:53:46'),(4,2,0,'private-chat20',1,'2023-08-11 18:44:37');
/*!40000 ALTER TABLE `chat_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_contacts`
--

DROP TABLE IF EXISTS `chat_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_contacts` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_contacts`
--

LOCK TABLES `chat_contacts` WRITE;
/*!40000 ALTER TABLE `chat_contacts` DISABLE KEYS */;
INSERT INTO `chat_contacts` VALUES (1,2,8,0,'2023-07-08 15:21:00'),(2,8,2,0,'2023-07-09 09:52:06'),(3,8,2,0,'2023-07-09 09:52:27'),(4,8,2,0,'2023-07-09 09:53:23');
/*!40000 ALTER TABLE `chat_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_delete`
--

DROP TABLE IF EXISTS `chat_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_delete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `delete_on` bigint(25) NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_delete`
--

LOCK TABLES `chat_delete` WRITE;
/*!40000 ALTER TABLE `chat_delete` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_group`
--

DROP TABLE IF EXISTS `chat_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) NOT NULL,
  `group_members` text NOT NULL,
  `channel_name` varchar(200) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_group`
--

LOCK TABLES `chat_group` WRITE;
/*!40000 ALTER TABLE `chat_group` DISABLE KEYS */;
INSERT INTO `chat_group` VALUES (1,'Panda','2','Panda-20230718225056',8,'2023-07-18 17:20:56');
/*!40000 ALTER TABLE `chat_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_group_msg`
--

DROP TABLE IF EXISTS `chat_group_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_group_msg` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_group_msg`
--

LOCK TABLES `chat_group_msg` WRITE;
/*!40000 ALTER TABLE `chat_group_msg` DISABLE KEYS */;
INSERT INTO `chat_group_msg` VALUES (1,1,8,'hi panda','2023-08-09 01:54:04'),(2,1,2,'from','2023-08-09 02:21:46'),(3,1,2,'$insertChats = $odb -> prepare(\"INSERT INTO `chat_group_msg` (`group_id`, `sender_id`, `msg`) VALUES(:group_id, :sender_id, :chat_message)\");             $insertChats -> execute(array(\':group_id\' => $group_id, \':sender_id\' => $user_id, \':chat_message\' => $chat_message));','2023-08-09 02:30:39'),(4,1,8,'what is this ?','2023-08-09 02:40:26'),(5,1,2,'what is this','2023-08-09 02:43:57'),(6,1,2,'_________________________________________','2023-08-09 16:28:14'),(7,1,2,'8 Aug','2023-08-09 16:53:50'),(8,1,2,'8 Aug 2023','2023-08-09 17:07:56'),(9,1,2,'9 aug','2023-08-09 17:10:22'),(10,1,2,'may be','2023-08-09 17:11:15'),(11,1,8,'sweta','2023-08-09 17:28:10'),(12,1,2,'today is 10 aug','2023-08-11 18:39:25');
/*!40000 ALTER TABLE `chat_group_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_login_details`
--

DROP TABLE IF EXISTS `chat_login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_login_details` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_typing` enum('no','yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_login_details`
--

LOCK TABLES `chat_login_details` WRITE;
/*!40000 ALTER TABLE `chat_login_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_login_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_mute`
--

DROP TABLE IF EXISTS `chat_mute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_mute` (
  `mute_id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `mute_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_mute`
--

LOCK TABLES `chat_mute` WRITE;
/*!40000 ALTER TABLE `chat_mute` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_mute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `college`
--

DROP TABLE IF EXISTS `college`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `college` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `access_token` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 : active,0 : inactive, 2 : delete',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `college`
--

LOCK TABLES `college` WRITE;
/*!40000 ALTER TABLE `college` DISABLE KEYS */;
INSERT INTO `college` VALUES (1,'IIT DELHI','WnTd5Ds4hzbxrfqJLA7Z',1,'2023-04-11 23:33:07','2023-04-11 23:33:07'),(2,'SCOTTSDALE UNIVERSITY','ScpZAdG40Ko1neJUEQIF',1,'2023-04-11 23:33:07','2023-04-11 23:33:07'),(3,'IIT Hyderabad','zUPRXxnbemJCuhaVQA8r',1,'2023-04-14 11:23:09','2023-04-14 11:23:09'),(4,'Scottsman University','ueUAvr4IE3h5Ha7Fi0MY',1,'2023-04-16 12:56:39','2023-04-16 12:56:39'),(5,'test123','vkARuOrxS7l0wV2HeY8z',1,'2023-04-17 09:25:01','2023-04-17 09:25:01'),(6,'IISE','Clbm7v3OtzZIyBq5P9LH',1,'2023-05-24 22:47:00','2023-05-24 22:47:00'),(7,'niet_delhi','qmS1bBif4o8HO5gPNEFh',1,'2023-05-28 15:12:16','2023-05-28 15:12:16'),(8,'IU','LmIkKNt3A2rFsuGioWEg',2,'2023-06-07 13:07:54','2023-06-07 13:07:54'),(9,'test College','viUa2c3O76FGewqJSMQC',1,'2023-06-08 16:45:15','2023-06-08 16:45:15'),(10,'DemoCollege','bmOI3qn8HwdDhrQ9aYVi',1,'2023-06-09 14:15:12','2023-06-09 14:15:12'),(11,'NIT JAMSHEDPUR','rQRWKL6Hw8p3YnoFIk2x',1,'2023-06-18 00:08:47','2023-06-18 00:08:47'),(14,'ddu_lucknow@mailinator.com','vA16C5a8QW3zlr9m7MBs ',1,'2024-05-31 08:45:31','2024-05-31 08:45:31');
/*!40000 ALTER TABLE `college` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` varchar(25) NOT NULL,
  `college_id` int(11) NOT NULL,
  `course_title` varchar(200) NOT NULL,
  `course_category_id` int(11) NOT NULL,
  `course_level` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'120230907161749',1,'Transaction',1,2,NULL,'<p>ACID property</p>',1,2,'2023-09-07 16:17:49','2023-09-07 16:17:49'),(4,'1',1,'sql',1,1,1,'<p>Structure query language</p>',1,2,'2023-09-17 13:07:20','2023-09-17 13:07:20');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_category`
--

DROP TABLE IF EXISTS `course_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` varchar(25) NOT NULL,
  `name` varchar(100) NOT NULL,
  `college_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_category`
--

LOCK TABLES `course_category` WRITE;
/*!40000 ALTER TABLE `course_category` DISABLE KEYS */;
INSERT INTO `course_category` VALUES (1,'1','Databasess',1,1,'2023-08-08 08:57:12','2023-08-08 08:57:12'),(2,'2','NODE',1,1,'2023-08-08 09:54:54','2023-08-08 09:54:54');
/*!40000 ALTER TABLE `course_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_chapter`
--

DROP TABLE IF EXISTS `course_chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_chapter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` varchar(25) NOT NULL,
  `section_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_chapter`
--

LOCK TABLES `course_chapter` WRITE;
/*!40000 ALTER TABLE `course_chapter` DISABLE KEYS */;
INSERT INTO `course_chapter` VALUES (1,'120230911232521',1,'Chapter 1','<p>Chapter 1</p>',1,2,'2023-09-11 23:25:21','2023-09-11 23:25:21'),(2,'120230913224229',2,'Chapter 1','<p>Hello This is Chapter 1</p>',1,2,'2023-09-13 22:42:29','2023-09-13 22:42:29'),(3,'1',5,'simple select','<p>select * from user</p>',1,2,'2023-09-17 13:07:20','2023-09-17 13:07:20'),(4,'2',5,'select specific','<p>select name,mobile,email from users;</p>',1,2,'2023-09-17 13:07:20','2023-09-17 13:07:20'),(5,'4',6,'simple update','<p>update table users name = \'sweta\'</p>',1,2,'2023-09-17 13:07:20','2023-09-17 13:07:20');
/*!40000 ALTER TABLE `course_chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_section`
--

DROP TABLE IF EXISTS `course_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` varchar(25) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_section`
--

LOCK TABLES `course_section` WRITE;
/*!40000 ALTER TABLE `course_section` DISABLE KEYS */;
INSERT INTO `course_section` VALUES (1,'120230908225321',1,'Transaction I','Transaction Properties I',2,'2023-09-08 22:53:21','2023-09-08 22:53:21'),(2,'120230908230222',1,'Section 2','RDBMS',2,'2023-09-08 23:02:22','2023-09-08 23:02:22'),(5,'1',4,'select','select statement',2,'2023-09-17 13:07:20','2023-09-17 13:07:20'),(6,'2',4,'update','update statement',2,'2023-09-17 13:07:20','2023-09-17 13:07:20');
/*!40000 ALTER TABLE `course_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventman`
--

DROP TABLE IF EXISTS `eventman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventman` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventman`
--

LOCK TABLES `eventman` WRITE;
/*!40000 ALTER TABLE `eventman` DISABLE KEYS */;
/*!40000 ALTER TABLE `eventman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_value` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade`
--

LOCK TABLES `grade` WRITE;
/*!40000 ALTER TABLE `grade` DISABLE KEYS */;
INSERT INTO `grade` VALUES (1,'A+','A+'),(2,'A','A'),(3,'A-','A-'),(4,'B+','B+'),(5,'B','B'),(6,'B-','B-'),(7,'C+','C+'),(8,'C','C'),(9,'C-','C-'),(10,'D+','D+'),(11,'D-','D-'),(12,'D','D'),(13,'F+','F+'),(14,'F-','F-'),(15,'F','F'),(17,'k+','k+');
/*!40000 ALTER TABLE `grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grading_rubric_criteria`
--

DROP TABLE IF EXISTS `grading_rubric_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grading_rubric_criteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `redteam_grade` varchar(10) DEFAULT NULL,
  `blueteam_grade` varchar(10) DEFAULT NULL,
  `purpleteam_grade` varchar(10) DEFAULT NULL,
  `assigned_user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grading_rubric_criteria`
--

LOCK TABLES `grading_rubric_criteria` WRITE;
/*!40000 ALTER TABLE `grading_rubric_criteria` DISABLE KEYS */;
INSERT INTO `grading_rubric_criteria` VALUES (4,3,'PDSS','Test Conducted for PDSS','CS','BS',NULL,'1'),(11,1,'Excellent','Clear, concise, and well-defined','A','A','A','1');
/*!40000 ALTER TABLE `grading_rubric_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grading_rubric_criteria_user`
--

DROP TABLE IF EXISTS `grading_rubric_criteria_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grading_rubric_criteria_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grading_rubric_criteria_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `grade` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grading_rubric_criteria_user`
--

LOCK TABLES `grading_rubric_criteria_user` WRITE;
/*!40000 ALTER TABLE `grading_rubric_criteria_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `grading_rubric_criteria_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base`
--

DROP TABLE IF EXISTS `knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` varchar(25) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `college_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_check` (`enterprise_id`,`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base`
--

LOCK TABLES `knowledge_base` WRITE;
/*!40000 ALTER TABLE `knowledge_base` DISABLE KEYS */;
INSERT INTO `knowledge_base` VALUES (17,'1',1,1,1,1,'Sub cat content 1',1,NULL,'2023-08-12 01:18:25','2023-08-12 01:18:25'),(18,'3',1,1,1,1,'<p><font color=\"#000000\"><span style=\"background-color: rgb(255, 255, 0);\">Version 1&nbsp;</span></font></p>',1,NULL,'2023-08-12 01:18:25','2023-08-12 01:18:25'),(23,'4',1,2,1,1,'<p><font color=\"#000000\"><span style=\"background-color: rgb(255, 255, 0);\">NEW KNOWLEDGE&nbsp;</span></font></p>',1,NULL,'2023-08-12 01:41:11','2023-08-12 01:41:11'),(24,'120230815171742',1,2,NULL,1,'<p>My knowledgebase 123</p>',1,2,'2023-08-15 17:17:42','2023-08-15 17:17:42'),(25,'120230815173249',1,2,NULL,1,'<h1><strong>My Content </strong></h1>',1,2,'2023-08-15 17:32:49','2023-08-15 17:32:49');
/*!40000 ALTER TABLE `knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginip`
--

DROP TABLE IF EXISTS `loginip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginip` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `logged` varchar(15) NOT NULL,
  `date` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=441 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginip`
--

LOCK TABLES `loginip` WRITE;
/*!40000 ALTER TABLE `loginip` DISABLE KEYS */;
INSERT INTO `loginip` VALUES (1,59,'iit_delhi','103.87.59.49',1681288126,0),(2,59,'iit_delhi','103.87.59.49',1681297493,0),(4,1,'AdminDemo','24.251.69.73',1681308849,0),(5,1,'AdminDemo','24.251.69.73',1681319557,0),(6,3,'TonyR','24.251.69.73',1681394501,0),(12,4,'iit_hyderabad','103.87.59.87',1681569068,1),(15,4,'iit_hyderabad','103.87.59.87',1681641357,1),(16,6,'Demonstration','174.172.110.201',1681664222,0),(18,4,'iit_hyderabad','103.87.59.87',1681671087,1),(20,7,'truss','24.251.69.73',1681748736,0),(41,4,'iit_hyderabad','103.87.59.129',1682569945,1),(46,4,'iit_hyderabad','103.87.59.129',1682771108,1),(92,9,'iise','103.87.59.226',1684950326,0),(94,11,'niet_delhi','103.87.59.66',1685266984,0),(114,13,'jtaylor7827','104.15.184.187',1686157746,0),(119,14,'tstclg','185.107.56.165',1686291736,1),(120,14,'tstclg','185.107.56.165',1686291788,1),(123,14,'tstclg','150.107.241.158',1686373425,0),(124,14,'tstclg','223.226.215.24',1686373750,0),(125,14,'tstclg','150.107.241.158',1686383596,0),(132,4,'iit_hyderabad','103.87.59.110',1686674246,1),(138,4,'iit_hyderabad','103.87.59.113',1686758440,1),(139,0,'','103.87.59.113',1686768100,0),(140,0,'','103.87.59.139',1686850612,0),(142,27,'xlri','103.87.59.165',1687027147,0),(144,4,'iit_hyderabad','103.87.59.130',1687192818,1),(147,4,'iit_hyderabad','103.87.59.132',1687282856,1),(152,14,'tstclg','150.107.241.244',1687414190,0),(155,14,'tstclg','103.251.19.196',1687446323,0),(163,4,'iit_hyderabad','103.87.59.6',1687800038,1),(170,2,'iit_delhi','103.87.59.31',1688193959,1),(171,2,'iit_delhi','103.87.59.31',1688194789,1),(172,2,'iit_delhi','103.87.59.31',1688205054,1),(173,2,'iit_delhi','103.87.59.214',1688230234,1),(175,2,'iit_delhi','103.87.59.34',1688404656,1),(176,2,'iit_delhi','122.161.53.166',1688492864,1),(177,2,'iit_delhi','122.161.53.166',1688549554,1),(178,2,'iit_delhi','122.161.53.166',1688563078,1),(179,2,'iit_delhi','122.161.53.166',1688569927,1),(180,2,'iit_delhi','103.87.59.79',1688578219,1),(181,2,'iit_delhi','103.87.59.79',1688580043,1),(182,2,'iit_delhi','103.87.59.79',1688580093,1),(183,2,'iit_delhi','103.87.59.79',1688667305,1),(184,8,'john','103.87.59.79',1688667474,1),(185,2,'iit_delhi','103.87.59.58',1688749854,1),(186,2,'iit_delhi','103.87.59.67',1688797179,1),(187,2,'iit_delhi','103.87.59.186',1688826960,1),(189,2,'iit_delhi','103.87.59.4',1688846334,1),(191,8,'john','157.37.141.248',1688895815,1),(192,2,'iit_delhi','103.87.59.75',1688906468,1),(193,8,'john','103.87.59.75',1688906491,1),(195,2,'iit_delhi','103.87.59.133',1689007790,1),(196,8,'john','103.87.59.133',1689007816,1),(197,2,'iit_delhi','103.87.59.133',1689094834,1),(198,8,'john','103.87.59.133',1689094847,1),(199,2,'iit_delhi','103.87.59.133',1689095562,1),(200,8,'john','103.87.59.133',1689095608,1),(201,2,'iit_delhi','103.87.59.140',1689268038,1),(202,8,'john','103.87.59.140',1689269701,1),(203,2,'iit_delhi','103.87.59.140',1689271890,1),(204,8,'john','103.87.59.140',1689271912,1),(205,8,'john','103.87.59.140',1689272382,1),(206,2,'iit_delhi','103.87.59.95',1689442511,1),(207,2,'iit_delhi','103.87.59.95',1689443031,1),(208,8,'john','103.87.59.95',1689443093,1),(209,8,'john','103.87.59.65',1689695822,1),(210,2,'iit_delhi','103.87.59.65',1689703466,1),(212,8,'john','103.87.59.84',1689782006,1),(213,2,'iit_delhi','103.87.59.190',1690734423,1),(216,2,'iit_delhi','103.87.59.27',1691169747,1),(218,2,'iit_delhi','122.161.53.45',1691479616,1),(219,2,'iit_delhi','14.97.213.91',1691500786,1),(220,2,'iit_delhi','103.87.59.27',1691544972,1),(221,8,'john','103.87.59.27',1691545992,1),(222,2,'iit_delhi','103.87.59.171',1691597937,1),(223,8,'john','103.87.59.171',1691597977,0),(224,2,'iit_delhi','103.87.59.58',1691777541,0),(225,2,'iit_delhi','103.87.59.58',1691778060,0),(226,8,'john','103.87.59.58',1691778853,0),(227,8,'john','103.87.59.58',1691779023,0),(228,2,'iit_delhi','103.87.59.58',1691841967,0),(229,2,'iit_delhi','103.87.59.58',1691852184,0),(230,2,'iit_delhi','103.87.59.133',1692095540,0),(231,2,'iit_delhi','103.87.59.204',1692205417,0),(232,2,'iit_delhi','103.87.59.204',1692378705,0),(235,2,'iit_delhi','103.87.59.38',1692958323,0),(236,2,'iit_delhi','103.109.217.188',1693147943,0),(242,2,'iit_delhi','103.109.217.188',1693392625,0),(243,2,'iit_delhi','106.214.94.39',1693475112,0),(245,2,'iit_delhi','103.87.59.7',1693849633,0),(246,2,'iit_delhi','103.87.59.7',1693936115,0),(247,2,'iit_delhi','103.87.59.66',1694077198,0),(248,2,'iit_delhi','103.87.59.66',1694095544,0),(249,2,'iit_delhi','103.87.59.8',1694186419,0),(250,2,'iit_delhi','103.87.59.134',1694340370,0),(252,2,'iit_delhi','103.87.59.134',1694362646,0),(255,2,'iit_delhi','103.87.59.134',1694453205,0),(257,2,'iit_delhi','103.87.59.150',1694497806,0),(260,2,'iit_delhi','103.87.59.8',1694576403,0),(261,2,'iit_delhi','103.87.59.8',1694623463,0),(262,2,'iit_delhi','103.87.59.96',1694707916,0),(263,26,'ankPan','103.87.59.96',1694710754,0),(267,2,'iit_delhi','103.87.59.50',1694804300,0),(268,2,'iit_delhi','103.87.59.35',1694845642,0),(269,2,'iit_delhi','103.87.59.35',1694845704,0),(270,2,'iit_delhi','103.87.59.35',1694846055,0),(271,2,'iit_delhi','103.87.59.35',1694846096,0),(272,2,'iit_delhi','103.87.59.35',1694846146,0),(273,2,'iit_delhi','103.87.59.35',1694846232,0),(274,2,'iit_delhi','103.87.59.35',1694846403,0),(275,2,'iit_delhi','103.87.59.35',1694846848,0),(276,26,'ankPan','103.87.59.35',1694846852,0),(278,2,'iit_delhi','103.87.59.171',1694931538,0),(281,2,'iit_delhi','103.87.59.243',1695138921,0),(282,2,'iit_delhi','122.161.51.97',1695187011,0),(284,2,'iit_delhi','103.87.59.117',1695228668,0),(297,29,'RedTeamTest','174.238.229.174',1695587878,0),(300,2,'iit_delhi','103.87.59.112',1695924615,0),(306,2,'iit_delhi','103.87.59.91',1696469055,0),(309,2,'iit_delhi','103.87.59.91',1696524739,0),(310,2,'iit_delhi','103.87.59.91',1696617811,0),(315,2,'iit_delhi','103.87.59.91',1696903021,0),(317,2,'iit_delhi','103.87.59.44',1696960352,0),(321,2,'iit_delhi','103.87.59.81',1697558454,0),(326,2,'iit_delhi','103.109.217.222',1699781177,0),(327,2,'iit_delhi','103.109.217.222',1699781455,0),(330,15,'AdminDemo','174.172.110.201',1700108522,0),(331,15,'AdminDemo','154.192.45.89',1700285438,0),(332,2,'iit_delhi','103.87.59.231',1701191409,0),(333,2,'iit_delhi','103.87.59.235',1701445561,0),(334,2,'iit_delhi','103.87.59.129',1701450853,0),(335,2,'iit_delhi','103.87.59.129',1701531863,0),(336,15,'AdminDemo','174.205.224.217',1701585012,0),(337,2,'iit_delhi','103.87.59.129',1701655594,0),(338,2,'iit_delhi','103.87.59.129',1701795054,0),(339,2,'iit_delhi','103.87.59.129',1701868150,0),(340,2,'iit_delhi','103.87.59.129',1701881860,0),(341,2,'iit_delhi','103.87.59.129',1701884181,0),(342,2,'iit_delhi','103.87.59.110',1702483377,0),(343,2,'iit_delhi','103.87.59.197',1702920960,0),(344,2,'iit_delhi','103.87.59.228',1708107545,0),(345,2,'iit_delhi','103.87.59.254',1708709469,0),(346,2,'iit_delhi','103.87.59.254',1708747175,0),(347,2,'iit_delhi','103.87.59.254',1708878003,0),(348,2,'iit_delhi','49.205.174.158',1709037312,0),(349,2,'iit_delhi','103.109.217.222',1709441297,0),(350,2,'iit_delhi','103.109.217.222',1709447042,0),(351,2,'iit_delhi','103.87.59.124',1710584672,0),(352,2,'iit_delhi','103.87.59.124',1710589132,0),(353,2,'iit_delhi','103.87.59.124',1710604194,0),(354,2,'iit_delhi','103.3.204.131',1710606897,0),(355,2,'iit_delhi','103.87.59.124',1710615765,0),(356,2,'iit_delhi','103.3.204.131',1710690397,0),(357,2,'iit_delhi','103.87.59.115',1713276603,0),(358,2,'iit_delhi','103.87.59.111',1713450963,0),(359,2,'iit_delhi','103.87.59.85',1713894307,0),(360,2,'iit_delhi','103.87.59.68',1714248410,0),(361,2,'iit_delhi','103.87.59.68',1714248586,0),(362,2,'iit_delhi','103.87.59.229',1714321855,0),(363,2,'iit_delhi','157.37.189.253',1714662626,0),(364,2,'iit_delhi','103.87.59.122',1714899583,0),(365,2,'iit_delhi','103.87.59.122',1714915000,0),(366,2,'iit_delhi','103.87.59.122',1714918087,0),(367,2,'iit_delhi','103.87.59.159',1715101318,0),(368,2,'iit_delhi','14.97.213.91',1715236010,0),(369,40,'suji','103.87.59.116',1715779503,0),(370,2,'iit_delhi','27.58.152.134',1715924069,0),(371,2,'iit_delhi','27.58.152.134',1715929736,0),(372,2,'iit_delhi','103.87.59.116',1715956236,0),(373,2,'iit_delhi','122.172.140.217',1716096459,0),(374,2,'iit_delhi','103.87.59.110',1716109208,0),(375,2,'iit_delhi','103.87.59.110',1716117570,0),(376,2,'iit_delhi','103.87.59.143, ',1716432170,0),(377,2,'iit_delhi','103.87.59.143, ',1716432252,0),(378,45,'ddu_lucknow','103.87.59.70, 1',1717170490,0),(379,2,'iit_delhi','103.87.59.36, 1',1717599974,0),(380,2,'iit_delhi','103.87.59.36, 1',1717685087,0),(381,41,'john','2600:1700:70e0:',1717719223,0),(382,15,'AdminDemo','2600:1011:b167:',1717820904,0),(383,15,'AdminDemo','70.162.109.98, ',1717821025,0),(384,15,'AdminDemo','2600:8800:8804:',1717878113,0),(385,15,'AdminDemo','2600:8800:8804:',1717897107,0),(386,2,'iit_delhi','103.87.59.164, ',1717918211,0),(387,15,'AdminDemo','70.162.109.98, ',1717957519,0),(388,2,'iit_delhi','103.87.59.164, ',1718029626,0),(389,2,'iit_delhi','103.87.59.164, ',1718117770,0),(390,2,'iit_delhi','103.87.59.164, ',1718201571,0),(391,2,'iit_delhi','103.87.59.84, 1',1718357784,0),(392,15,'AdminDemo','24.251.69.73, 1',1718546806,0),(393,2,'iit_delhi','103.87.59.172, ',1718637279,0),(394,2,'iit_delhi','103.87.59.172, ',1718649745,0),(395,2,'iit_delhi','103.87.59.182, ',1718907734,0),(396,2,'iit_delhi','103.211.18.149,',1718983920,0),(397,2,'iit_delhi','103.211.18.183,',1719071252,0),(398,2,'iit_delhi','103.211.18.183,',1719129303,0),(399,15,'AdminDemo','70.162.109.98, ',1719149868,0),(400,2,'iit_delhi','103.211.18.183,',1719166143,0),(401,2,'iit_delhi','103.211.18.183,',1719242321,0),(402,15,'AdminDemo','70.162.109.98, ',1719269200,0),(403,15,'AdminDemo','2600:1700:70e0:',1719269669,0),(404,15,'AdminDemo','119.155.29.115,',1719293850,0),(405,2,'iit_delhi','103.211.18.233,',1719326702,0),(406,2,'iit_delhi','103.211.18.199,',1719411702,0),(407,15,'AdminDemo','2600:1700:70e0:',1719419346,0),(408,2,'iit_delhi','103.211.18.229,',1719505011,0),(409,2,'iit_delhi','103.211.18.229,',1719510775,0),(410,2,'iit_delhi','103.211.18.235,',1719588439,0),(411,2,'iit_delhi','103.211.18.235,',1719851914,0),(412,2,'iit_delhi','103.211.18.235,',1719937320,0),(413,2,'iit_delhi','103.211.53.89, ',1720026394,0),(414,2,'iit_delhi','103.211.53.170,',1720664755,0),(415,2,'iit_delhi','103.211.53.170,',1720709989,0),(416,2,'iit_delhi','103.115.206.140',1720714037,0),(417,2,'iit_delhi','103.211.53.170,',1720715868,0),(418,2,'iit_delhi','103.115.206.140',1720717912,0),(419,15,'AdminDemo','70.162.109.98, ',1720779095,0),(420,2,'iit_delhi','103.211.53.170,',1720801169,0),(421,15,'AdminDemo','2600:8800:8804:',1720927118,0),(422,2,'iit_delhi','103.211.53.149,',1721234367,0),(423,2,'iit_delhi','103.211.53.149,',1721297346,0),(424,2,'iit_delhi','103.211.53.32, ',1721668892,0),(425,2,'iit_delhi','103.211.53.32, ',1721748939,0),(426,2,'iit_delhi','103.211.53.160,',1721922811,0),(427,15,'AdminDemo','70.162.109.98, ',1721977873,0),(428,2,'iit_delhi','103.211.53.33, ',1722006799,0),(429,2,'iit_delhi','103.211.53.195,',1722077297,0),(430,2,'iit_delhi','103.211.53.195,',1722086333,0),(431,2,'iit_delhi','103.211.53.195,',1722097755,0),(432,2,'iit_delhi','103.211.53.105,',1722182198,0),(433,2,'iit_delhi','103.211.53.107,',1722190938,0),(434,15,'AdminDemo','70.162.109.98, ',1722221326,0),(435,2,'iit_delhi','103.211.53.107,',1722262996,0),(436,2,'iit_delhi','103.211.53.107,',1722273261,0),(437,15,'AdminDemo','2600:1700:70e0:',1722906271,0),(438,2,'iit_delhi','103.211.53.236,',1723139899,0),(439,15,'AdminDemo','70.162.109.98, ',1723511441,0),(440,15,'AdminDemo','2600:1700:70e0:',1723661125,0);
/*!40000 ALTER TABLE `loginip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logserv`
--

DROP TABLE IF EXISTS `logserv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logserv` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logserv`
--

LOCK TABLES `logserv` WRITE;
/*!40000 ALTER TABLE `logserv` DISABLE KEYS */;
INSERT INTO `logserv` VALUES (2,'test logserv','105.104.15.14',7,5,'');
/*!40000 ALTER TABLE `logserv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(50) NOT NULL,
  `detail` longblob NOT NULL,
  `created_by` varchar(60) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (55,4,3,'IIT HYDERABAD is introducing new platform to lear ','<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.</p>','4','2023-04-15 20:14:14'),(56,9,6,'COLLEGE OPEN','<p>COLLEGE WILL BE OPEN ON 1st June 2023.</p>','9','2023-05-24 23:17:40'),(58,2,1,'IIT delhi is introducing new platform to learn hac','<p>Ethical Hacking&nbsp;is compromising computer systems for assessing security and acting in good faith by informing the vulnerable party. Ethical hacking is a key skill for many job roles related to securing the online assets of an organization. The professionals working on these job roles maintain the organization’s computers, servers, and other components of its infrastructure in working conditions preventing unauthorized access through non-physical channels.&nbsp;</p>','2','2024-06-11 08:05:44');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `option_key` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pre_registration`
--

DROP TABLE IF EXISTS `pre_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pre_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `otp` varchar(10) NOT NULL,
  `is_used` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pre_registration`
--

LOCK TABLES `pre_registration` WRITE;
/*!40000 ALTER TABLE `pre_registration` DISABLE KEYS */;
INSERT INTO `pre_registration` VALUES (1,NULL,'suji@mailinator.com','382879',1,'2024-05-15 05:40:41',NULL),(2,NULL,'admin@rootcapture.com','851487',0,'2024-05-29 15:27:01',NULL),(3,NULL,'ddu@mailinator.com','399610',1,'2024-05-29 15:29:34',NULL),(4,'121212121',NULL,'336273',0,'2024-05-29 15:30:02',NULL),(5,NULL,'ddu_lucknow@mailinator.com','520098',1,'2024-05-30 15:45:22',NULL);
/*!40000 ALTER TABLE `pre_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purpleservers`
--

DROP TABLE IF EXISTS `purpleservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purpleservers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purpleservers`
--

LOCK TABLES `purpleservers` WRITE;
/*!40000 ALTER TABLE `purpleservers` DISABLE KEYS */;
INSERT INTO `purpleservers` VALUES (1,'test purple','102.56.35.19',3,5,'cxfvfvfdv');
/*!40000 ALTER TABLE `purpleservers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_submission`
--

DROP TABLE IF EXISTS `quiz_submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_submission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `quize_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `choose_option` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_correct` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_submission`
--

LOCK TABLES `quiz_submission` WRITE;
/*!40000 ALTER TABLE `quiz_submission` DISABLE KEYS */;
INSERT INTO `quiz_submission` VALUES (3,1,5,2,12,1,1,'2023-06-08 23:52:38','2023-06-08 23:52:38'),(4,1,6,3,12,1,1,'2023-06-08 23:52:38','2023-06-08 23:52:38'),(5,2,9,3,12,0,2,'2023-06-08 23:56:31','2023-06-08 23:56:31'),(6,2,10,2,12,1,2,'2023-06-08 23:56:31','2023-06-08 23:56:31');
/*!40000 ALTER TABLE `quiz_submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_submit_video`
--

DROP TABLE IF EXISTS `quiz_submit_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_submit_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quize_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `video_link` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_submit_video`
--

LOCK TABLES `quiz_submit_video` WRITE;
/*!40000 ALTER TABLE `quiz_submit_video` DISABLE KEYS */;
INSERT INTO `quiz_submit_video` VALUES (1,1,12,'quiz/20230608230533screen_recording.webm','2023-06-08 23:52:38'),(2,2,12,'quiz/20230608230533screen_recording.webm','2023-06-08 23:56:31');
/*!40000 ALTER TABLE `quiz_submit_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quize`
--

DROP TABLE IF EXISTS `quize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `is_mandatory` varchar(5) DEFAULT NULL,
  `team_user` varchar(10) DEFAULT NULL,
  `assign_team` int(11) DEFAULT NULL,
  `assign_users` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quize`
--

LOCK TABLES `quize` WRITE;
/*!40000 ALTER TABLE `quize` DISABLE KEYS */;
INSERT INTO `quize` VALUES (1,'QUIZE 1','yes','team',4,'12',1,2,1,'2023-05-21 07:37:12','2023-05-21 07:39:57'),(2,'QUIZE 2','no','users',0,'8,12',2,2,1,'2023-05-21 07:38:03','2023-05-21 07:50:21');
/*!40000 ALTER TABLE `quize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quize_question`
--

DROP TABLE IF EXISTS `quize_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quize_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quize_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `option1` text DEFAULT NULL,
  `option2` text DEFAULT NULL,
  `option3` text DEFAULT NULL,
  `option4` text DEFAULT NULL,
  `correct_answer` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quize_question`
--

LOCK TABLES `quize_question` WRITE;
/*!40000 ALTER TABLE `quize_question` DISABLE KEYS */;
INSERT INTO `quize_question` VALUES (5,1,'Question 1','Q1O1','Q1O2',NULL,NULL,2,'2023-05-21 07:39:57','2023-05-21 14:09:57'),(6,1,'QUESTION 2','OPT1','OPT2','OPT3','OPT4',3,'2023-05-21 07:39:57','2023-05-21 14:09:57'),(9,2,'Question 1','OPT1','OPT2','OPT3','OPT4',4,'2023-05-21 07:50:21','2023-05-21 14:20:21'),(10,2,'QUESTION 2','Q2O1','Q2O2',NULL,NULL,2,'2023-05-21 07:50:21','2023-05-21 14:20:21');
/*!40000 ALTER TABLE `quize_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recent_activities`
--

DROP TABLE IF EXISTS `recent_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recent_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL,
  `label` varchar(50) DEFAULT NULL,
  `activities` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recent_activities`
--

LOCK TABLES `recent_activities` WRITE;
/*!40000 ALTER TABLE `recent_activities` DISABLE KEYS */;
INSERT INTO `recent_activities` VALUES (1,1,2,'reset_login_logs',' Reset the Platform\'s Login Logs.','2023-06-20 23:41:35'),(2,1,2,'reset_login_logs',' Reset the Platform\'s Login Logs.','2023-06-20 23:41:58'),(3,10,15,'registration_mode',' enabled Platform Registration.','2023-06-22 01:28:35'),(4,10,15,'registration_mode',' disabled Platform Registration.','2023-06-22 01:28:37'),(5,10,15,'registration_mode',' enabled Platform Registration.','2023-06-22 01:28:38'),(6,10,15,'registration_mode',' disabled Platform Registration.','2023-06-22 01:28:42'),(7,10,15,'registration_mode',' enabled Platform Registration.','2023-06-22 01:28:49'),(8,10,15,'registration_mode',' disabled Platform Registration.','2023-06-22 01:30:50'),(9,10,15,'registration_mode',' enabled Platform Registration.','2023-06-22 01:32:30'),(10,10,15,'registration_mode',' disabled Platform Registration.','2023-06-22 01:32:36'),(11,10,15,'registration_mode',' enabled Platform Registration.','2023-06-22 01:32:36'),(12,10,15,'registration_mode',' disabled Platform Registration.','2023-06-22 01:34:09'),(13,1,2,'maintainence_mode',' enabled the Maintenance Mode.','2023-06-27 23:44:06'),(14,1,2,'maintainence_mode',' disabled the Maintenance Mode.','2023-06-27 23:44:08'),(15,1,2,'reset_login_logs',' Reset the Platform\'s Login Logs.','2023-06-29 23:35:55'),(16,10,15,'registration_mode',' enabled Platform Registration.','2023-08-01 00:11:59'),(17,10,15,'registration_mode',' disabled Platform Registration.','2023-08-01 00:12:08'),(18,1,2,'maintainence_mode',' enabled the Maintenance Mode.','2023-08-27 20:45:11'),(19,1,2,'maintainence_mode',' disabled the Maintenance Mode.','2023-08-27 20:45:14'),(20,10,15,'add_user',' Created a New User on the Platform','2023-08-29 12:55:10'),(21,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:04:02'),(22,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:19:12'),(23,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:19:38'),(24,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:25:17'),(25,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:25:39'),(26,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:27:13'),(27,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:32:12'),(28,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:32:28'),(29,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:52:32'),(30,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 22:59:26'),(31,1,2,'edit_user',' Modified the user ankPan on the platform','2023-09-14 23:08:08'),(32,1,2,'edit_team',' Modified the team (Green Team1) on the platform.','2023-09-19 21:26:43'),(33,1,2,'edit_team',' Modified the team (Green Team) on the platform.','2023-09-19 21:26:52'),(34,1,2,'add_team',' Created a New Team (Team X) on the Platform.','2023-09-19 21:42:22'),(35,1,2,'add_team',' Created a New Team (Team Y) on the Platform.','2023-09-19 21:54:59'),(36,10,15,'add_user',' Created a New User on the Platform','2023-09-24 13:37:29'),(37,10,15,'delete_user',' Deleted the user RedTeamTest on the platform.','2023-09-29 10:43:44'),(38,10,15,'add_sytem_group',' created new System Group (SDSDSDSD) on the platform.','2023-10-11 23:26:29'),(39,10,15,'add_sytem',' created new System (FGFGFG) on the platform.','2023-10-11 23:26:54'),(40,10,15,'add_team',' Created a New Team (Shoaib Khan) on the Platform.','2023-10-12 14:25:52'),(41,10,15,'add_team',' Created a New Team (gdf) on the Platform.','2023-10-12 14:51:48'),(42,10,15,'maintainence_mode',' enabled the Maintenance Mode.','2023-11-15 09:07:11'),(43,10,15,'maintainence_mode',' disabled the Maintenance Mode.','2023-11-15 09:07:13'),(44,10,15,'maintainence_mode',' enabled the Maintenance Mode.','2023-11-15 11:07:40'),(45,10,15,'registration_mode',' enabled Platform Registration.','2023-11-15 11:07:41'),(46,10,15,'red_team_ctf_mode',' enabled the Red Team Capture The Flag Competition.','2023-11-15 11:07:52'),(47,10,15,'registration_mode',' disabled Platform Registration.','2023-11-15 11:07:55'),(48,10,15,'registration_mode',' enabled Platform Registration.','2023-11-15 11:07:56'),(49,10,15,'maintainence_mode',' disabled the Maintenance Mode.','2023-11-15 11:08:01'),(50,10,15,'registration_mode',' disabled Platform Registration.','2023-11-15 11:08:02'),(51,10,15,'maintainence_mode',' enabled the Maintenance Mode.','2023-11-15 11:08:10'),(52,10,15,'maintainence_mode',' disabled the Maintenance Mode.','2023-11-15 11:33:22'),(53,10,15,'maintainence_mode',' enabled the Maintenance Mode.','2023-11-15 11:33:23'),(54,10,15,'registration_mode',' enabled Platform Registration.','2023-11-15 11:51:10'),(55,10,15,'reset_login_logs',' Reset the Platform\'s Login Logs.','2023-11-15 11:52:08'),(56,10,15,'registration_mode',' disabled Platform Registration.','2023-11-15 11:52:31'),(57,10,15,'maintainence_mode',' disabled the Maintenance Mode.','2023-11-15 11:52:31'),(58,10,15,'red_team_ctf_mode',' disabled the Red Team Capture The Flag Competition.','2023-11-15 11:52:33'),(59,1,2,'registration_mode',' disabled Platform Registration.','2024-05-17 11:34:19'),(60,1,2,'registration_mode',' enabled Platform Registration.','2024-05-17 11:34:20'),(61,1,2,'reset_all_team_user_list',' The Cyber Range Has Been Reset To Factory Defaults!.','2024-05-17 11:36:55'),(62,1,2,'reset_all_team_assets',' Reset the Platform\'s User Logs.','2024-05-17 11:37:18'),(63,1,2,'reset_all_team_assets',' Reset the Platform\'s User Logs.','2024-05-17 11:38:56'),(64,1,2,'add_sytem_group',' created new System Group (Learn Linux) on the platform.','2024-06-12 08:01:50'),(65,1,2,'add_sytem',' created new System (windows feature) on the platform.','2024-06-17 08:52:36'),(66,1,2,'edit_team',' Modified the team (Team XZ) on the platform.','2024-06-23 02:26:42'),(67,1,2,'edit_team',' Modified the team (Team X) on the platform.','2024-06-23 02:26:55'),(68,1,2,'add_team',' Created a New Team (dddd) on the Platform.','2024-06-24 08:31:57'),(69,1,2,'add_team',' Created a New Team (fvbn) on the Platform.','2024-06-24 08:53:36'),(70,10,15,'add_sytem_group',' created new System Group (Windows XP) on the platform.','2024-06-24 15:47:22'),(71,10,15,'maintainence_mode',' enabled the Maintenance Mode.','2024-06-24 16:33:25'),(72,10,15,'registration_mode',' enabled Platform Registration.','2024-06-24 16:33:27'),(73,1,2,'add_team',' Created a New Team (fvbnm,) on the Platform.','2024-06-25 07:51:47'),(74,1,2,'add_team',' Created a New Team (vb n) on the Platform.','2024-06-25 08:08:19'),(75,1,2,'add_team',' Created a New Team (erer) on the Platform.','2024-06-25 09:07:03'),(76,1,2,'edit_team',' Modified the team (dddder) on the platform.','2024-06-26 07:31:46'),(77,1,2,'add_sytem_group',' created new System Group (test group) on the platform.','2024-06-27 09:29:45'),(78,1,2,'edit_sytem_group',' modified System Group (test groups) on the platform.','2024-06-27 11:19:36'),(79,1,2,'add_sytem',' created new System (test system) on the platform.','2024-07-02 11:08:34'),(80,1,2,'edit_sytem',' modified System (test system) on the platform.','2024-07-03 11:09:19'),(81,10,15,'delete_sytem_group',' deleted the System Group (SDSDSDSD) on the platform.','2024-07-12 03:12:22'),(82,10,15,'registration_mode',' disabled Platform Registration.','2024-07-26 00:11:25'),(83,10,15,'registration_mode',' enabled Platform Registration.','2024-07-26 00:11:26'),(84,10,15,'red_team_ctf_mode',' enabled the Red Team Capture The Flag Competition.','2024-07-26 00:11:33'),(85,10,15,'red_team_ctf_mode',' disabled the Red Team Capture The Flag Competition.','2024-07-26 00:11:33');
/*!40000 ALTER TABLE `recent_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redservers`
--

DROP TABLE IF EXISTS `redservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redservers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ip` text NOT NULL,
  `os` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redservers`
--

LOCK TABLES `redservers` WRITE;
/*!40000 ALTER TABLE `redservers` DISABLE KEYS */;
INSERT INTO `redservers` VALUES (1,'test red server','105.106.12.23',2,3,'');
/*!40000 ALTER TABLE `redservers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rubric`
--

DROP TABLE IF EXISTS `rubric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rubric` (
  `criteria` text NOT NULL,
  `description` text NOT NULL,
  `grade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rubric`
--

LOCK TABLES `rubric` WRITE;
/*!40000 ALTER TABLE `rubric` DISABLE KEYS */;
/*!40000 ALTER TABLE `rubric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0 COMMENT 'If 0 than it is for super admin',
  `label` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `college_id` (`college_id`,`label`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,0,'is_maintanence_mode',0),(2,1,'is_registration_mode',1),(3,1,'is_red_team_ctf_active',1),(4,6,'is_red_team_ctf_active',0),(5,9,'is_registration_mode',1),(6,9,'is_red_team_ctf_active',1),(7,3,'is_red_team_ctf_active',1),(8,1,'is_maintanence_mode',0),(9,10,'is_registration_mode',1),(10,10,'is_maintanence_mode',1),(11,10,'is_red_team_ctf_active',0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_category`
--

DROP TABLE IF EXISTS `sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enterprise_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `college_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_check` (`enterprise_id`,`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_category`
--

LOCK TABLES `sub_category` WRITE;
/*!40000 ALTER TABLE `sub_category` DISABLE KEYS */;
INSERT INTO `sub_category` VALUES (1,1,'Sub Cat 1',1,1,1,'2023-08-12 01:18:25','2023-08-12 01:18:25'),(6,2,'Sub Cat 2',1,1,1,'2023-08-12 01:59:12','2023-08-12 01:59:12');
/*!40000 ALTER TABLE `sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_status`
--

DROP TABLE IF EXISTS `team_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `team_code` varchar(100) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_status`
--

LOCK TABLES `team_status` WRITE;
/*!40000 ALTER TABLE `team_status` DISABLE KEYS */;
INSERT INTO `team_status` VALUES (1,3,1,'lTBufghPnsCit1ZNAkM0',0),(2,4,1,'YcJUidTSRxKonuImFlPW',1),(3,5,1,'hL0VWIfPRCGQrKO4mq2n',1),(4,3,2,NULL,1),(5,4,2,NULL,1),(6,5,2,NULL,1),(7,3,3,NULL,1),(8,4,3,NULL,1),(9,5,3,NULL,1),(10,6,1,'7sfPSNO6ixWQEMlYjpnr',1),(11,7,3,NULL,1),(12,1,1,NULL,1),(13,2,1,NULL,1),(14,1,2,NULL,1),(15,2,2,NULL,1),(16,1,3,NULL,1),(17,2,3,NULL,1),(18,1,4,NULL,1),(19,2,4,NULL,1),(20,3,4,NULL,1),(21,4,4,NULL,1),(22,5,4,NULL,1),(23,1,5,NULL,1),(24,2,5,NULL,1),(25,3,5,NULL,1),(26,4,5,NULL,1),(27,5,5,NULL,1),(28,9,2,'WPoJhK7OX0YvkBeZldaF',1),(29,1,6,NULL,1),(30,2,6,NULL,1),(31,3,6,NULL,1),(32,4,6,NULL,1),(33,5,6,NULL,1),(34,1,7,NULL,1),(35,2,7,NULL,1),(36,3,7,NULL,1),(37,4,7,NULL,1),(38,5,7,NULL,1),(39,1,8,NULL,1),(40,2,8,NULL,1),(41,3,8,NULL,1),(42,4,8,NULL,1),(43,5,8,NULL,1),(44,1,9,NULL,1),(45,2,9,NULL,1),(46,3,9,'mlBe9TAiGsudp4bgMNYn',1),(47,4,9,'XSmcvH6TqCs5uJkf9Rwz',1),(48,5,9,'vKLztAa85cX6DiBH3sER',1),(49,10,1,'3kE80QwRoCcBHADzJjP6',0),(50,1,10,NULL,1),(51,2,10,NULL,1),(52,3,10,'XwOUVI3ajkHmCK5bNo2v',1),(53,4,10,'KXNh6xH4ok73lGycfOLw',1),(54,5,10,'tzBI6RKbgwYArvuaq8TW',1),(55,1,11,NULL,1),(56,2,11,NULL,1),(57,3,11,NULL,1),(58,4,11,NULL,1),(59,5,11,NULL,1),(60,11,1,'k075Qcx6lqn9WjCHdtES',1),(61,12,1,'sqXVfUvJNhFtc8ZC6LMz',1),(62,13,10,'CJZFl0kjXIMriyOxAScn',1),(63,14,10,'1mLwIGoPKAzfYxJBUqln',1),(64,15,1,'MPV4p5UoQR7DAqzfEIil',0),(65,1,12,NULL,1),(66,2,12,NULL,1),(67,3,12,NULL,1),(68,4,12,NULL,1),(69,5,12,NULL,1),(70,1,13,NULL,1),(71,2,13,NULL,1),(72,3,13,NULL,1),(73,4,13,NULL,1),(74,5,13,NULL,1),(75,1,14,NULL,1),(76,2,14,NULL,1),(77,3,14,NULL,1),(78,4,14,NULL,1),(79,5,14,NULL,1),(80,16,1,'gBkLr6S5sHYPNGOnxliM',1),(81,17,1,'i3VTFnI4HEhOZKMapJ68',1),(82,18,1,'RaorNOpThKntjUwuVbSe',1),(83,19,1,'bJwqL5QfictoVMA3n7gY',1),(84,20,1,'bRINv4WT3so1udPwflZx',1);
/*!40000 ALTER TABLE `team_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_code` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `team_type` int(11) NOT NULL DEFAULT 3 COMMENT '1:Super Admin | 2:Admin or assistant|3:team',
  `name` varchar(100) NOT NULL,
  `color_code` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,NULL,0,1,'Admin','#e1d005','2023-01-03 06:48:23','2023-01-03 06:48:23'),(2,NULL,0,2,'Administrative Assistant','#FF8033','2023-01-03 06:48:23','2023-01-03 06:48:23'),(3,NULL,0,3,'Red Team','#e7515a','2023-01-02 11:51:30','2023-01-02 11:51:30'),(4,NULL,0,3,'Blue Team','#2196f3','2023-01-03 12:00:19','2023-01-03 12:00:19'),(5,NULL,0,3,'Purple Team','#A833FF','2023-01-03 12:00:44','2023-01-03 09:57:39'),(6,NULL,2,3,'Green Team','#14e121','2023-04-15 22:01:08','2023-09-19 21:26:52'),(7,NULL,4,3,'Orange Team','#ed720c','2023-04-15 22:02:38','2023-04-15 23:36:38'),(8,NULL,0,3,'Grey','#454040','2023-05-12 10:36:53','2023-05-12 10:36:53'),(9,NULL,0,3,'grey','#524c4c','2023-05-12 10:38:38','2023-05-12 10:38:38'),(10,NULL,0,3,'Test Team','#12bdd3','2023-06-08 18:12:04','2023-06-08 18:12:04'),(11,'k075Qcx6lqn9WjCHdtES',2,3,'Team X','#3f0303','2023-09-19 21:42:22','2024-06-23 02:26:55'),(12,'sqXVfUvJNhFtc8ZC6LMz',2,3,'Team Y','#d5df49','2023-09-19 21:54:59','2023-09-19 21:54:59'),(13,'CJZFl0kjXIMriyOxAScn',15,3,'Shoaib Khan','#28aa53','2023-10-12 14:25:52','2023-10-12 14:25:52'),(14,'70C6UwPbklfATi8QWLm3',15,3,'gdf','#000000','2023-10-12 14:51:48','2023-10-12 14:51:48'),(15,'MPV4p5UoQR7DAqzfEIil',0,3,'Team Z','#b5abab','2024-05-06 14:29:43','2024-05-06 14:29:43'),(16,'gBkLr6S5sHYPNGOnxliM',2,3,'dddder','#000000','2024-06-24 08:31:57','2024-06-26 07:31:46'),(17,'i3VTFnI4HEhOZKMapJ68',2,3,'fvbn','#000000','2024-06-24 08:53:36','2024-06-24 08:53:36'),(18,'RaorNOpThKntjUwuVbSe',2,3,'fvbnm,','#000000','2024-06-25 07:51:47','2024-06-25 07:51:47'),(19,'bJwqL5QfictoVMA3n7gY',2,3,'vb n','#000000','2024-06-25 08:08:19','2024-06-25 08:08:19'),(20,'bRINv4WT3so1udPwflZx',2,3,'erer','#000000','2024-06-25 09:07:03','2024-06-25 09:07:03');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketResponses`
--

DROP TABLE IF EXISTS `ticketResponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketResponses` (
  `responseID` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `ticketID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `response` varchar(4096) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`responseID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketResponses`
--

LOCK TABLES `ticketResponses` WRITE;
/*!40000 ALTER TABLE `ticketResponses` DISABLE KEYS */;
INSERT INTO `ticketResponses` VALUES (1,0,1,41,'<p>I want to change my current password.</p>',1672384849),(2,0,1,41,' Hey there have u recieved my issues.',1672386737),(3,0,1,19,' Go to profile section under my account there u can change your password.',1672388223),(4,0,1,41,' Yes its done.\r\nThanks',1672389564),(5,0,2,40,'<p>Checking assign user functionality for multiple user</p>',1672649397),(6,0,3,41,'<p>Checking assign user functionality for multiple user</p>',1672649397),(12,0,2,19,'<p>Or you could <strong>use this</strong> as an <u>opportunity</u> to use those functions</p>',1673929126),(13,0,2,19,'<p>Or you could <strong>use this</strong> as an <u>opportunity</u> to use those functions</p>',1673929475),(19,0,10,51,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',1674180440),(20,0,11,40,'<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.&nbsp;</p>',1674185904),(21,0,11,51,'<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias</p>',1674185985),(22,0,11,19,'<p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will,&nbsp;</p>',1674186169),(23,0,11,19,'<p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will,&nbsp;</p>',1674186270),(24,0,11,19,'<p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will,&nbsp;</p>',1674186275),(25,0,11,51,'<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias</p>',1674189114),(26,0,12,57,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',1674618429),(31,10,15,15,'<p>TEST</p>',1695015943),(32,10,15,15,'<p>AAAA</p>',1695016301);
/*!40000 ALTER TABLE `ticketResponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `ticketID` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `userID` int(11) NOT NULL,
  `ticketTitle` varchar(255) NOT NULL,
  `assign_to` varchar(255) DEFAULT NULL,
  `timeCreated` int(11) NOT NULL,
  `ticketStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`ticketID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,0,41,'Change password','',1672384849,0),(2,0,40,'Unit Testing','',1672649397,0),(3,0,41,'Unit Testing','',1672649397,1),(10,0,51,'The standard Lorem Ipsum passage, used since the 1500s','40,43',1674180440,2),(11,0,40,'1914 translation by H. Rackham','40,41,43',1674185904,1),(12,0,57,'The standard Lorem Ipsum passage, used since the 1500s','40,41,43,44',1674618429,1),(15,10,15,'TestTicket',NULL,1695015943,1);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_session`
--

DROP TABLE IF EXISTS `user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `active_session` datetime NOT NULL,
  `ip_address` varchar(30) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lng` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_session`
--

LOCK TABLES `user_session` WRITE;
/*!40000 ALTER TABLE `user_session` DISABLE KEYS */;
INSERT INTO `user_session` VALUES (1,0,19,'2023-04-11 14:59:52','103.87.59.49',NULL,NULL),(2,0,31,'2022-12-23 07:25:57',NULL,NULL,NULL),(3,0,38,'2022-12-29 09:29:10',NULL,NULL,NULL),(4,0,41,'2023-01-31 11:38:49','103.87.59.147',NULL,NULL),(5,0,43,'2023-01-24 02:16:37','103.87.59.45',NULL,NULL),(6,0,44,'2023-01-24 03:33:11','103.87.59.45',NULL,NULL),(8,0,45,'2023-01-30 12:27:23','49.14.110.102',NULL,NULL),(9,0,46,'2023-01-14 03:10:03','174.172.110.201',NULL,NULL),(10,0,51,'2023-01-23 23:29:00','112.196.163.196',NULL,NULL),(11,0,40,'2023-01-20 00:52:07','112.196.163.11',NULL,NULL),(12,0,57,'2023-02-07 08:57:33','112.196.163.176',NULL,NULL),(13,0,59,'2023-04-12 17:37:18','103.87.59.49',NULL,NULL),(14,0,2,'2023-04-24 18:49:01','103.87.59.232',NULL,NULL),(15,0,1,'2023-04-12 10:16:04','24.251.69.73',NULL,NULL),(16,0,3,'2023-04-13 07:02:23','24.251.69.73',NULL,NULL),(17,0,4,'2023-04-17 00:52:50','103.87.59.87',NULL,NULL),(18,0,6,'2023-04-17 04:54:26','174.172.110.201',NULL,NULL),(19,0,7,'2023-04-17 09:26:17','24.251.69.73',NULL,NULL),(20,0,8,'2023-04-19 23:34:30','103.87.59.232',NULL,NULL),(21,1,2,'2024-08-08 10:58:29','103.211.53.236, 172.68.57.139',NULL,NULL),(22,7,11,'2023-05-29 23:20:05','103.87.59.165',NULL,NULL),(23,1,8,'2023-08-12 00:07:32','103.87.59.58',NULL,NULL),(24,3,4,'2023-06-26 22:50:46','103.87.59.6',NULL,NULL),(25,6,9,'2023-05-24 23:25:25','103.87.59.226',NULL,NULL),(27,1,12,'2023-06-14 00:14:56','103.87.59.213',NULL,NULL),(28,8,13,'2023-06-07 13:50:15','104.15.184.187',NULL,NULL),(29,9,14,'2023-06-22 20:39:56','103.251.19.196',NULL,NULL),(30,10,15,'2024-08-14 11:45:55','2600:1700:70e0:af60:4898:e2f2:',NULL,NULL),(31,1,26,'2023-09-16 15:47:13','103.87.59.171',NULL,NULL),(32,11,27,'2023-06-18 00:27:17','103.87.59.165',NULL,NULL),(33,7,11,'2023-05-28 15:30:16','111.87.59.21',NULL,NULL),(34,10,29,'2023-09-24 14:57:31','174.238.229.174',NULL,NULL),(35,1,40,'2024-05-15 18:55:26','103.87.59.116',NULL,NULL),(36,14,45,'2024-05-31 08:53:20','103.87.59.70, 172.68.150.4',NULL,NULL),(37,1,41,'2024-06-06 21:11:09','2600:1700:70e0:af60:64f3:5254:',NULL,NULL);
/*!40000 ALTER TABLE `user_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `rank` int(11) NOT NULL DEFAULT 0,
  `previous_rank` tinyint(4) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `college_id` int(11) NOT NULL DEFAULT 0,
  `phone` varchar(20) DEFAULT NULL,
  `membership` int(11) NOT NULL,
  `expire` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 as not banned|1 as banned | 2 as deleted',
  `key` varchar(255) DEFAULT NULL,
  `used` int(11) NOT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `forgot_otp` varchar(10) DEFAULT NULL,
  `otp_verification_preference` tinyint(4) DEFAULT NULL COMMENT '1 : Mobile , 2 : Email',
  `banned_msg` text DEFAULT NULL,
  `grading_criteria` int(11) DEFAULT NULL,
  `restrict_chat` int(1) NOT NULL DEFAULT 0,
  `available_status` int(1) NOT NULL DEFAULT 0,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `last_login` datetime NOT NULL DEFAULT current_timestamp(),
  `is_logout` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_key_id` (`key`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'iit_delhi','7c222fb2927d828af22f592134e8932480637c0d','iit_delhi@mailinator.com',1,0,0,1,'9616666919',0,0,0,'df2312507ae63e70750c519de42cf5ee27ca630e',0,'927139','171213',2,NULL,0,0,0,'2023-04-11 23:33:07','0000-00-00 00:00:00','no'),(3,'TonyR','b61763a80dcedf0970f962d511adea3118f70e22','coo@rootcapture.com',1,0,0,2,'17602917484',0,0,0,NULL,0,'678369',NULL,1,NULL,0,0,0,'2023-04-12 10:13:32','0000-00-00 00:00:00','yes'),(4,'iit_hyderabad','31c6d64a87b26fb16dc9d119b9386e4fb5cc1d94','iit_hyderabad@mailinator.com',1,0,0,3,'1234567832',0,0,0,NULL,0,'619501',NULL,2,NULL,0,0,0,'2023-04-14 11:23:09','0000-00-00 00:00:00','no'),(6,'Demonstration','487d7cf6cc349e9c8884b89e417564b2ff4e553e','rickydavids908@gmail.com',1,0,0,4,'8127188589',0,0,0,NULL,0,'413892',NULL,2,NULL,0,0,0,'2023-04-16 12:56:39','0000-00-00 00:00:00','no'),(7,'truss','cbfdac6008f9cab4083784cbd1874f76618d2a97','shotime555@gmail.com',1,0,0,5,'7602917484',0,0,0,'cda1e16b2c5c6503595c1e5bc765eb812b226b2e',0,'125723','765480',2,NULL,0,0,0,'2023-04-17 09:25:01','0000-00-00 00:00:00','yes'),(9,'iise','31c6d64a87b26fb16dc9d119b9386e4fb5cc1d94','iiselko@yopmail.com',1,0,0,6,'9140832767',0,0,0,NULL,0,'469401',NULL,2,NULL,0,0,0,'2023-05-24 22:47:00','0000-00-00 00:00:00','no'),(11,'niet_delhi','a29c57c6894dee6e8251510d58c07078ee3f49bf','niet_delhi@mailinator.com',1,0,0,7,NULL,0,0,0,NULL,0,'907094',NULL,2,NULL,0,0,0,'2023-05-28 15:12:16','0000-00-00 00:00:00','yes'),(13,'jtaylor7827','de928b9b62b0f410d1ef337160999b00a7f025fe','jtaylor7827@yahoo.com',1,0,0,8,'13175061395',0,0,2,NULL,0,'590347',NULL,1,NULL,0,0,0,'2023-06-07 13:07:54','0000-00-00 00:00:00','no'),(14,'tstclg','2e479e810cd3dda57b270d73c9c382b002fba43e','projectlastyerit@gmail.com',1,0,0,9,'123456789',0,0,0,NULL,0,'432853',NULL,2,NULL,0,0,0,'2023-06-08 16:45:15','0000-00-00 00:00:00','yes'),(15,'AdminDemo','a3fe6cb47cf760e232a076b5190b652aa7d63ecd','admin56@rootcapture.com',1,0,0,10,'18127188589',0,0,0,'fc5021df4a357e5a1288acd89de88d34b2ac220b',0,'855188',NULL,1,NULL,0,0,0,'2023-06-09 14:15:12','0000-00-00 00:00:00','no'),(16,'Sweta','31c6d64a87b26fb16dc9d119b9386e4fb5cc1d94','sweta@yopmail.com',3,0,4,3,'9616666918',0,0,0,NULL,0,NULL,NULL,2,NULL,0,0,0,'2023-06-14 21:38:24','2023-06-14 16:08:24',NULL),(27,'xlri','31c6d64a87b26fb16dc9d119b9386e4fb5cc1d94','xlri@yopmail.com',1,0,0,11,'9120129129',0,0,0,NULL,0,'595141',NULL,2,NULL,0,0,0,'2023-06-18 00:08:47','0000-00-00 00:00:00','no'),(41,'john','a3fe6cb47cf760e232a076b5190b652aa7d63ecd','john@mailinator.com',3,0,0,1,'1212121212',0,0,0,NULL,0,'985165',NULL,2,NULL,0,0,0,'2024-05-18 08:00:23','0000-00-00 00:00:00','no'),(42,'ddu_gkp','7c222fb2927d828af22f592134e8932480637c0d','ddu@mailinator.com',15,0,0,1,NULL,0,0,2,NULL,0,'536968',NULL,2,NULL,0,0,0,'2024-05-30 08:38:56','2024-05-30 15:38:56',NULL),(45,'ddu_lucknow','7c222fb2927d828af22f592134e8932480637c0d','ddu_lucknow@mailinator.com',1,0,0,14,NULL,0,0,0,NULL,0,'513613',NULL,2,NULL,0,0,0,'2024-05-31 08:45:31','0000-00-00 00:00:00','no');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_meta`
--

DROP TABLE IF EXISTS `users_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_meta` (
  `meta_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` text NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_meta`
--

LOCK TABLES `users_meta` WRITE;
/*!40000 ALTER TABLE `users_meta` DISABLE KEYS */;
INSERT INTO `users_meta` VALUES (1,10,'assistant_permissions','dashboard,announcement,team,user'),(2,16,'assistant_permissions','none'),(3,2,'lastseen_time','1701655724'),(4,8,'lastseen_time','1691779106'),(5,28,'assistant_permissions','none'),(6,26,'assistant_permissions','dashboard,announcement,system_group,api,rubric,quiz,knowledgebase,course_system'),(7,29,'assistant_permissions','none'),(8,30,'assistant_permissions','none'),(9,41,'assistant_permissions','none');
/*!40000 ALTER TABLE `users_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rootCapCre'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-17 18:53:21
