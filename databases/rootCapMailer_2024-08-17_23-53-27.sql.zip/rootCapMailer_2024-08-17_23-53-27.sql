-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: rootCapMailer
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(160) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `subject_type` varchar(160) DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(160) DEFAULT NULL,
  `properties` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`),
  KEY `subject` (`subject_id`,`subject_type`),
  KEY `causer` (`causer_id`,`causer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','User has been Created',1,'Gainhq\\Installer\\App\\Models\\Core\\User',NULL,NULL,'{\"attributes\":{\"first_name\":\"rootCapture\'s Enterprise\",\"last_name\":\"Administrator\",\"email\":\"admin@rootcapture.com\"}}','2023-01-27 04:58:20','2023-01-27 04:58:20'),(2,'default','Notification setting has been Created',1,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:20','2023-01-27 04:58:20'),(3,'default','created',1,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(4,'default','Notification setting has been Created',2,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(5,'default','created',2,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(6,'default','Notification setting has been Created',3,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(7,'default','created',3,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(8,'default','Notification setting has been Created',4,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(9,'default','created',4,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(10,'default','Notification setting has been Created',5,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(11,'default','created',5,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(12,'default','Notification setting has been Created',6,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(13,'default','created',6,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(14,'default','Notification setting has been Created',7,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(15,'default','created',7,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(16,'default','Role has been Created',2,'App\\Models\\Core\\Auth\\Role',NULL,NULL,'{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":null,\"type.name\":\"Brand\",\"brand.name\":\"Default Brand\"}}','2023-01-27 04:58:21','2023-01-27 04:58:21'),(17,'default','Notification setting has been Created',8,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(18,'default','created',8,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(19,'default','Notification setting has been Created',9,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(20,'default','created',9,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(21,'default','Notification setting has been Created',10,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(22,'default','created',10,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(23,'default','Notification setting has been Created',11,'App\\Models\\Core\\Setting\\NotificationSetting',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(24,'default','created',11,'App\\Models\\Core\\Setting\\NotificationAudience',NULL,NULL,'[]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(25,'default','Notification Template has been Created',1,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(26,'default','Notification Template has been Created',2,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(27,'default','Notification Template has been Created',3,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(28,'default','Notification Template has been Created',4,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(29,'default','Notification Template has been Created',5,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(30,'default','Notification Template has been Created',6,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(31,'default','Notification Template has been Created',7,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(32,'default','Notification Template has been Created',8,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(33,'default','Notification Template has been Created',9,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(34,'default','Notification Template has been Created',10,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(35,'default','Notification Template has been Created',11,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:22','2023-01-27 04:58:22'),(36,'default','Notification Template has been Created',12,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(37,'default','Notification Template has been Created',13,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(38,'default','Notification Template has been Created',14,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(39,'default','Notification Template has been Created',15,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(40,'default','Notification Template has been Created',16,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(41,'default','Notification Template has been Created',17,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(42,'default','Notification Template has been Created',18,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(43,'default','Notification Template has been Created',19,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(44,'default','Notification Template has been Created',20,'App\\Models\\Core\\Notification\\NotificationTemplate',NULL,NULL,'[]','2023-01-27 04:58:23','2023-01-27 04:58:23'),(45,'default','Setting has been Created',15,'App\\Models\\Core\\Setting\\Setting',NULL,NULL,'{\"attributes\":{\"name\":\"track_open_in_campaigns\",\"context\":\"brand_default_privacy\"}}','2023-01-27 04:58:23','2023-01-27 04:58:23'),(46,'default','Setting has been Created',16,'App\\Models\\Core\\Setting\\Setting',NULL,NULL,'{\"attributes\":{\"name\":\"track_clicks_in_your_campaigns\",\"context\":\"brand_default_privacy\"}}','2023-01-27 04:58:23','2023-01-27 04:58:23'),(47,'default','Setting has been Created',17,'App\\Models\\Core\\Setting\\Setting',NULL,NULL,'{\"attributes\":{\"name\":\"track_location_in_your_campaigns\",\"context\":\"brand_default_privacy\"}}','2023-01-27 04:58:23','2023-01-27 04:58:23'),(48,'default','Brand Group has been Created',1,'App\\Models\\Core\\App\\Brand\\BrandGroup',NULL,NULL,'{\"attributes\":{\"name\":\"General\"}}','2023-01-27 04:58:23','2023-01-27 04:58:23'),(49,'default','Role has been Created',3,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Content Administrator\",\"is_admin\":false,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"App\",\"brand.name\":null}}','2023-01-31 02:47:08','2023-01-31 02:47:08'),(50,'default','Setting has been Created',18,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"from_name\",\"context\":\"default_mail_email_name\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(51,'default','Setting has been Created',19,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"from_email\",\"context\":\"default_mail_email_name\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(52,'default','Setting has been Created',20,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"provider\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(53,'default','Setting has been Created',21,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_daily_quota\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(54,'default','Setting has been Created',22,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_hourly_quota\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(55,'default','Setting has been Created',23,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_monthly_quota\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(56,'default','Setting has been Created',24,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_encryption\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(57,'default','Setting has been Created',25,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_password\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(58,'default','Setting has been Created',26,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_host\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(59,'default','Setting has been Created',27,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_port\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(60,'default','Setting has been Created',28,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"smtp_user_name\",\"context\":\"smtp\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(61,'default','Setting has been Created',29,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"default_mail\",\"context\":\"mail\"}}','2023-01-31 07:29:18','2023-01-31 07:29:18'),(62,'default','Setting has been updated',18,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:56','2023-01-31 07:33:56'),(63,'default','Setting has been updated',19,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:56','2023-01-31 07:33:56'),(64,'default','Setting has been updated',20,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:56','2023-01-31 07:33:56'),(65,'default','Setting has been updated',25,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:56','2023-01-31 07:33:56'),(66,'default','Setting has been updated',26,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:56','2023-01-31 07:33:56'),(67,'default','Setting has been updated',27,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(68,'default','Setting has been updated',24,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(69,'default','Setting has been updated',22,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(70,'default','Setting has been updated',21,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(71,'default','Setting has been updated',23,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(72,'default','Setting has been updated',28,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-01-31 07:33:57','2023-01-31 07:33:57'),(73,'default','User has been Created',2,'App\\Models\\Core\\Auth\\User',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"first_name\":null,\"last_name\":null,\"email\":\"cms@mailinator.com\"}}','2023-01-31 07:35:23','2023-01-31 07:35:23'),(74,'default','An user has been invited to join',NULL,NULL,1,'App\\Models\\Core\\Auth\\User','{\"old\":[],\"attributes\":{\"email\":\"cms@mailinator.com\",\"status_id\":13,\"invitation_token\":\"Y21zQG1haWxpbmF0b3IuY29tLWludml0YXRpb24tZnJvbS11cw==\",\"created_by\":1,\"updated_at\":\"2023-01-31T07:35:23.000000Z\",\"created_at\":\"2023-01-31T07:35:23.000000Z\",\"id\":2,\"full_name\":null,\"roles\":[]}}','2023-01-31 07:35:23','2023-01-31 07:35:23'),(75,'default','User has been Deleted',2,'App\\Models\\Core\\Auth\\User',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"first_name\":null,\"last_name\":null,\"email\":\"cms@mailinator.com\"}}','2023-01-31 07:38:20','2023-01-31 07:38:20'),(76,'default','User has been Created',3,'App\\Models\\Core\\Auth\\User',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"first_name\":null,\"last_name\":null,\"email\":\"cms@mailinator.com\"}}','2023-01-31 07:39:06','2023-01-31 07:39:06'),(77,'default','An user has been invited to join',NULL,NULL,1,'App\\Models\\Core\\Auth\\User','{\"old\":[],\"attributes\":{\"email\":\"cms@mailinator.com\",\"status_id\":13,\"invitation_token\":\"Y21zQG1haWxpbmF0b3IuY29tLWludml0YXRpb24tZnJvbS11cw==\",\"created_by\":1,\"updated_at\":\"2023-01-31T07:39:06.000000Z\",\"created_at\":\"2023-01-31T07:39:06.000000Z\",\"id\":3,\"full_name\":null,\"roles\":[]}}','2023-01-31 07:39:07','2023-01-31 07:39:07'),(78,'default','User has been updated',3,'App\\Models\\Core\\Auth\\User',NULL,NULL,'{\"attributes\":{\"first_name\":\"cms\",\"last_name\":\"rootcapture\",\"email\":\"cms@mailinator.com\"},\"old\":{\"first_name\":null,\"last_name\":null,\"email\":\"cms@mailinator.com\"}}','2023-01-31 08:34:46','2023-01-31 08:34:46'),(79,'default','User confirmed his joining',NULL,NULL,NULL,NULL,'{\"old\":[],\"attributes\":{\"id\":3,\"first_name\":\"cms\",\"last_name\":\"rootcapture\",\"email\":\"cms@mailinator.com\",\"last_login_at\":null,\"created_by\":1,\"status_id\":11,\"invitation_token\":\"Y21zQG1haWxpbmF0b3IuY29tLWludml0YXRpb24tZnJvbS11cw==\",\"created_at\":\"2023-01-31T07:39:06.000000Z\",\"updated_at\":\"2023-01-31T08:34:46.000000Z\",\"deleted_at\":null,\"full_name\":\"cms rootcapture\",\"status\":{\"id\":13,\"name\":\"status_invited\",\"class\":\"purple\",\"type\":\"user\",\"created_at\":null,\"updated_at\":null,\"translated_name\":\"Invited\"}}}','2023-01-31 08:34:46','2023-01-31 08:34:46'),(80,'default','Notification Template has been updated',14,'App\\Models\\Core\\Notification\\NotificationTemplate',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-02 05:26:07','2023-02-02 05:26:07'),(81,'default','Setting has been updated',2,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-02-03 03:30:54','2023-02-03 03:30:54'),(82,'default','Brand Group has been updated',1,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcements\"},\"old\":{\"name\":\"General\"}}','2023-02-06 23:54:08','2023-02-06 23:54:08'),(83,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcements\"},\"old\":{\"name\":\"Default Brand\"}}','2023-02-06 23:54:53','2023-02-06 23:54:53'),(84,'default','Brand has been Created',2,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcements\"}}','2023-02-06 23:55:12','2023-02-06 23:55:12'),(85,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-02-06 23:55:12','2023-02-06 23:55:12'),(86,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-02-06 23:55:12','2023-02-06 23:55:12'),(87,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-02-06 23:55:12','2023-02-06 23:55:12'),(88,'default','Role has been Created',4,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"Announcements\"}}','2023-02-06 23:55:12','2023-02-06 23:55:12'),(89,'default','Notification setting has been Created',12,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(90,'default','created',12,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(91,'default','Notification setting has been Created',13,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(92,'default','created',13,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(93,'default','Notification setting has been Created',14,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(94,'default','created',14,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(95,'default','Notification setting has been Created',15,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(96,'default','created',15,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(97,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-02-06 23:55:24','2023-02-06 23:55:24'),(98,'default','User has been updated',3,'App\\Models\\Core\\Auth\\User',NULL,NULL,'{\"attributes\":{\"first_name\":\"cms\",\"last_name\":\"rootcapture\",\"email\":\"cms@mailinator.com\"},\"old\":{\"first_name\":\"cms\",\"last_name\":\"rootcapture\",\"email\":\"cms@mailinator.com\"}}','2023-02-14 04:58:23','2023-02-14 04:58:23'),(99,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-09 06:21:07','2023-03-09 06:21:07'),(100,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-09 06:21:50','2023-03-09 06:21:50'),(101,'default','Brand has been updated',2,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-09 06:23:01','2023-03-09 06:23:01'),(102,'default','Brand Group has been Deleted',1,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcements\"}}','2023-03-09 06:24:10','2023-03-09 06:24:10'),(103,'default','Brand Group has been Created',2,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcements\"}}','2023-03-09 06:24:23','2023-03-09 06:24:23'),(104,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-09 06:27:37','2023-03-09 06:27:37'),(105,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-09 06:27:44','2023-03-09 06:27:44'),(106,'default','Brand has been Created',3,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test\"}}','2023-03-10 02:43:58','2023-03-10 02:43:58'),(107,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-10 02:43:58','2023-03-10 02:43:58'),(108,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-10 02:43:58','2023-03-10 02:43:58'),(109,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-10 02:43:58','2023-03-10 02:43:58'),(110,'default','Role has been Created',5,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"test\"}}','2023-03-10 02:43:58','2023-03-10 02:43:58'),(111,'default','Notification setting has been Created',16,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(112,'default','created',16,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(113,'default','Notification setting has been Created',17,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(114,'default','created',17,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(115,'default','Notification setting has been Created',18,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(116,'default','created',18,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(117,'default','Notification setting has been Created',19,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:59','2023-03-10 02:43:59'),(118,'default','created',19,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-10 02:43:59','2023-03-10 02:43:59'),(119,'default','Brand has been Created',4,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test brand\"}}','2023-03-16 05:58:47','2023-03-16 05:58:47'),(120,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-16 05:58:47','2023-03-16 05:58:47'),(121,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-16 05:58:47','2023-03-16 05:58:47'),(122,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-16 05:58:48','2023-03-16 05:58:48'),(123,'default','Role has been Created',6,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"test brand\"}}','2023-03-16 05:58:48','2023-03-16 05:58:48'),(124,'default','Notification setting has been Created',20,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(125,'default','created',20,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(126,'default','Notification setting has been Created',21,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(127,'default','created',21,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(128,'default','Notification setting has been Created',22,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(129,'default','created',22,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(130,'default','Notification setting has been Created',23,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(131,'default','created',23,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(132,'default','Brand has been updated',3,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test new\"},\"old\":{\"name\":\"test\"}}','2023-03-16 08:41:40','2023-03-16 08:41:40'),(133,'default','Brand has been updated',3,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test\"},\"old\":{\"name\":\"test new\"}}','2023-03-16 08:58:03','2023-03-16 08:58:03'),(134,'default','Brand has been updated',3,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-17 03:32:47','2023-03-17 03:32:47'),(135,'default','Brand has been updated',3,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-17 03:40:26','2023-03-17 03:40:26'),(136,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-17 03:40:44','2023-03-17 03:40:44'),(137,'default','Brand has been updated',1,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-03-17 03:50:19','2023-03-17 03:50:19'),(138,'default','Brand has been Created',5,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Hyundai\"}}','2023-05-27 10:10:36','2023-05-27 10:10:36'),(139,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:10:36','2023-05-27 10:10:36'),(140,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:10:36','2023-05-27 10:10:36'),(141,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:10:36','2023-05-27 10:10:36'),(142,'default','Role has been Created',7,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"Hyundai\"}}','2023-05-27 10:10:37','2023-05-27 10:10:37'),(143,'default','Notification setting has been Created',24,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(144,'default','created',24,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(145,'default','Notification setting has been Created',25,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(146,'default','created',25,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(147,'default','Notification setting has been Created',26,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(148,'default','created',26,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(149,'default','Notification setting has been Created',27,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(150,'default','created',27,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(151,'default','Brand has been Created',6,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Hyundai\"}}','2023-05-27 10:11:42','2023-05-27 10:11:42'),(152,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:11:42','2023-05-27 10:11:42'),(153,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:11:42','2023-05-27 10:11:42'),(154,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:11:42','2023-05-27 10:11:42'),(155,'default','Role has been Created',8,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"Hyundai\"}}','2023-05-27 10:11:43','2023-05-27 10:11:43'),(156,'default','Notification setting has been Created',28,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(157,'default','created',28,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(158,'default','Notification setting has been Created',29,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(159,'default','created',29,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(160,'default','Notification setting has been Created',30,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(161,'default','created',30,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(162,'default','Notification setting has been Created',31,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(163,'default','created',31,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(164,'default','Brand has been Created',7,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"AmazonFiBrand\"}}','2023-05-27 10:12:36','2023-05-27 10:12:36'),(165,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:12:36','2023-05-27 10:12:36'),(166,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:12:36','2023-05-27 10:12:36'),(167,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-27 10:12:36','2023-05-27 10:12:36'),(168,'default','Role has been Created',9,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"AmazonFiBrand\"}}','2023-05-27 10:12:36','2023-05-27 10:12:36'),(169,'default','Notification setting has been Created',32,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(170,'default','created',32,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(171,'default','Notification setting has been Created',33,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(172,'default','created',33,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(173,'default','Notification setting has been Created',34,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(174,'default','created',34,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(175,'default','Notification setting has been Created',35,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(176,'default','created',35,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(177,'default','Brand Group has been Created',3,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"DIgitalMarketing\"}}','2023-05-27 10:14:55','2023-05-27 10:14:55'),(178,'default','Brand Group has been Created',4,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Educations\"}}','2023-05-27 10:15:18','2023-05-27 10:15:18'),(179,'default','Brand Group has been Created',5,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Political\"}}','2023-05-27 10:15:36','2023-05-27 10:15:36'),(180,'default','Brand Group has been updated',3,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"DigitalMarketing\"},\"old\":{\"name\":\"DIgitalMarketing\"}}','2023-05-27 10:15:48','2023-05-27 10:15:48'),(181,'default','Brand Group has been Created',6,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Announcement Test 1\"}}','2023-05-27 10:16:20','2023-05-27 10:16:20'),(182,'default','Role has been Created',10,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"MyTestRole\",\"is_admin\":false,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"App\",\"brand.name\":null}}','2023-05-27 10:44:54','2023-05-27 10:44:54'),(183,'default','User has been Created',4,'App\\Models\\Core\\Auth\\User',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"first_name\":null,\"last_name\":null,\"email\":\"dulgajvips@gmail.com\"}}','2023-05-27 10:45:53','2023-05-27 10:45:53'),(184,'default','An user has been invited to join',NULL,NULL,1,'App\\Models\\Core\\Auth\\User','{\"old\":[],\"attributes\":{\"email\":\"dulgajvips@gmail.com\",\"status_id\":13,\"invitation_token\":\"ZHVsZ2Fqdmlwc0BnbWFpbC5jb20taW52aXRhdGlvbi1mcm9tLXVz\",\"created_by\":1,\"updated_at\":\"2023-05-27T17:45:53.000000Z\",\"created_at\":\"2023-05-27T17:45:53.000000Z\",\"id\":4,\"full_name\":null,\"roles\":[]}}','2023-05-27 10:45:54','2023-05-27 10:45:54'),(185,'default','Brand has been updated',7,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-28 09:55:01','2023-05-28 09:55:01'),(186,'default','Brand has been updated',7,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-05-28 09:55:14','2023-05-28 09:55:14'),(187,'default','Brand has been Created',8,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test brand\"}}','2023-06-08 00:18:55','2023-06-08 00:18:55'),(188,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:18:55','2023-06-08 00:18:55'),(189,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:18:55','2023-06-08 00:18:55'),(190,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:18:55','2023-06-08 00:18:55'),(191,'default','Role has been Created',11,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"test brand\"}}','2023-06-08 00:18:55','2023-06-08 00:18:55'),(192,'default','Notification setting has been Created',36,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(193,'default','created',36,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(194,'default','Notification setting has been Created',37,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(195,'default','created',37,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(196,'default','Notification setting has been Created',38,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(197,'default','created',38,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(198,'default','Notification setting has been Created',39,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(199,'default','created',39,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(200,'default','Brand has been Created',9,'App\\Models\\Core\\App\\Brand\\Brand',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test brand\"}}','2023-06-08 00:19:10','2023-06-08 00:19:10'),(201,'default','Setting has been updated',15,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:19:10','2023-06-08 00:19:10'),(202,'default','Setting has been updated',16,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:19:10','2023-06-08 00:19:10'),(203,'default','Setting has been updated',17,'App\\Models\\Core\\Setting\\Setting',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":[],\"old\":[]}','2023-06-08 00:19:10','2023-06-08 00:19:10'),(204,'default','Role has been Created',12,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Brand admin\",\"is_admin\":true,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"Brand\",\"brand.name\":\"test brand\"}}','2023-06-08 00:19:10','2023-06-08 00:19:10'),(205,'default','Notification setting has been Created',40,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(206,'default','created',40,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(207,'default','Notification setting has been Created',41,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(208,'default','created',41,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(209,'default','Notification setting has been Created',42,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(210,'default','created',42,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(211,'default','Notification setting has been Created',43,'App\\Models\\Core\\Setting\\NotificationSetting',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(212,'default','created',43,'App\\Models\\Core\\Setting\\NotificationAudience',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(213,'default','Brand Group has been Created',7,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"test\"}}','2023-06-08 00:20:11','2023-06-08 00:20:11'),(214,'default','User has been Created',5,'App\\Models\\Core\\Auth\\User',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"first_name\":null,\"last_name\":null,\"email\":\"test@gmail.com\"}}','2023-06-08 00:30:49','2023-06-08 00:30:49'),(215,'default','An user has been invited to join',NULL,NULL,1,'App\\Models\\Core\\Auth\\User','{\"old\":[],\"attributes\":{\"email\":\"test@gmail.com\",\"status_id\":13,\"invitation_token\":\"dGVzdEBnbWFpbC5jb20taW52aXRhdGlvbi1mcm9tLXVz\",\"created_by\":1,\"updated_at\":\"2023-06-08T07:30:49.000000Z\",\"created_at\":\"2023-06-08T07:30:49.000000Z\",\"id\":5,\"full_name\":null,\"roles\":[]}}','2023-06-08 00:30:49','2023-06-08 00:30:49'),(216,'default','Role has been Created',13,'App\\Models\\Core\\Auth\\Role',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"Test role\",\"is_admin\":false,\"createdBy.name\":\"rootCapture\'s Enterprise Administrator\",\"type.name\":\"App\",\"brand.name\":null}}','2023-06-08 00:31:02','2023-06-08 00:31:02'),(217,'default','Custom Field has been Created',1,'App\\Models\\Core\\Builder\\Form\\CustomField',1,'App\\Models\\Core\\Auth\\User','[]','2023-06-08 02:05:52','2023-06-08 02:05:52'),(218,'default','Template has been Created',1,'App\\Models\\Template\\Template',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"subject\":\"teest\",\"brand.name\":null,\"createdBy.full_name\":\"rootCapture\'s Enterprise Administrator\",\"updatedBy.full_name\":null}}','2023-06-08 02:45:50','2023-06-08 02:45:50'),(219,'default','Brand Group has been Created',8,'App\\Models\\Core\\App\\Brand\\BrandGroup',1,'App\\Models\\Core\\Auth\\User','{\"attributes\":{\"name\":\"BMC\"}}','2023-06-18 03:32:35','2023-06-18 03:32:35');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `key` varchar(120) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_key_unique` (`key`),
  KEY `api_keys_brand_id_foreign` (`brand_id`),
  KEY `api_keys_user_id_foreign` (`user_id`),
  KEY `api_keys_updated_by_foreign` (`updated_by`),
  CONSTRAINT `api_keys_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `api_keys_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `api_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES (1,1,1,1,'7ab287a10087e148f216da5700bccb6694ac4e9aee34216cfd6430a0e32a506e','2023-02-06 23:57:19','2023-02-06 23:57:19');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_replies`
--

DROP TABLE IF EXISTS `blog_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `reply` text NOT NULL,
  `replied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_replies`
--

LOCK TABLES `blog_replies` WRITE;
/*!40000 ALTER TABLE `blog_replies` DISABLE KEYS */;
INSERT INTO `blog_replies` VALUES (1,1,'sweta','sweta@mailinator.com','Blog first reply','2023-02-21 06:03:06');
/*!40000 ALTER TABLE `blog_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `author` text NOT NULL,
  `services` text NOT NULL,
  `tags` text NOT NULL,
  `comment` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1 as allow : 0 as disallow',
  `created_by` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 AS INACTIVE:1 AS ACTIVE',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand_groups`
--

DROP TABLE IF EXISTS `brand_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_groups_created_by_foreign` (`created_by`),
  CONSTRAINT `brand_groups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand_groups`
--

LOCK TABLES `brand_groups` WRITE;
/*!40000 ALTER TABLE `brand_groups` DISABLE KEYS */;
INSERT INTO `brand_groups` VALUES (2,'Announcements',1,'2023-03-09 06:24:23','2023-03-09 06:24:23'),(3,'DigitalMarketing',1,'2023-05-27 10:14:55','2023-05-27 10:15:48'),(4,'Educations',1,'2023-05-27 10:15:18','2023-05-27 10:15:18'),(5,'Political',1,'2023-05-27 10:15:36','2023-05-27 10:15:36'),(6,'Announcement Test 1',1,'2023-05-27 10:16:20','2023-05-27 10:16:20'),(7,'test',1,'2023-06-08 00:20:11','2023-06-08 00:20:11'),(8,'BMC',1,'2023-06-18 03:32:35','2023-06-18 03:32:35');
/*!40000 ALTER TABLE `brand_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand_user`
--

DROP TABLE IF EXISTS `brand_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand_user` (
  `brand_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `assigned_by` bigint(20) unsigned DEFAULT NULL,
  KEY `brand_user_brand_id_foreign` (`brand_id`),
  KEY `brand_user_user_id_foreign` (`user_id`),
  CONSTRAINT `brand_user_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brand_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand_user`
--

LOCK TABLES `brand_user` WRITE;
/*!40000 ALTER TABLE `brand_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `brand_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `short_name` varchar(160) NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `status_id` bigint(20) unsigned DEFAULT NULL,
  `brand_group_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_short_name_unique` (`short_name`),
  KEY `brands_brand_group_id_foreign` (`brand_group_id`),
  KEY `brands_created_by_foreign` (`created_by`),
  KEY `brands_status_id_foreign` (`status_id`),
  CONSTRAINT `brands_brand_group_id_foreign` FOREIGN KEY (`brand_group_id`) REFERENCES `brand_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `brands_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `brands_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'Announcements','announce',1,17,2,'2023-01-27 04:58:21','2023-03-17 03:50:19'),(3,'test','ttt',1,17,2,'2023-03-10 02:43:58','2023-03-17 03:40:26'),(5,'Hyundai','HYN',1,NULL,2,'2023-05-27 10:10:36','2023-05-27 10:10:36'),(6,'Hyundai','HYND',1,NULL,2,'2023-05-27 10:11:42','2023-05-27 10:11:42'),(7,'AmazonFiBrand','AFB',1,17,2,'2023-05-27 10:12:36','2023-05-28 09:55:14'),(8,'test brand','tstb',1,NULL,2,'2023-06-08 00:18:55','2023-06-08 00:18:55'),(9,'test brand','tstb1',1,NULL,2,'2023-06-08 00:19:10','2023-06-08 00:19:10');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(120) NOT NULL,
  `value` text NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_activities`
--

DROP TABLE IF EXISTS `campaign_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) unsigned NOT NULL,
  `processed_at` datetime NOT NULL,
  `status_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaign_activities_campaign_id_foreign` (`campaign_id`),
  KEY `campaign_activities_status_id_foreign` (`status_id`),
  CONSTRAINT `campaign_activities_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`),
  CONSTRAINT `campaign_activities_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_activities`
--

LOCK TABLES `campaign_activities` WRITE;
/*!40000 ALTER TABLE `campaign_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_audiences`
--

DROP TABLE IF EXISTS `campaign_audiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_audiences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) unsigned NOT NULL,
  `audience_type` enum('list','subscriber') NOT NULL COMMENT 'list/subscriber',
  `audiences` text NOT NULL COMMENT 'Array of subscribers id',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaign_audiences_campaign_id_foreign` (`campaign_id`),
  CONSTRAINT `campaign_audiences_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_audiences`
--

LOCK TABLES `campaign_audiences` WRITE;
/*!40000 ALTER TABLE `campaign_audiences` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_audiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_content` longtext DEFAULT NULL,
  `time_period` varchar(255) DEFAULT NULL,
  `start_at` date DEFAULT NULL,
  `end_at` date DEFAULT NULL,
  `campaign_start_time` time DEFAULT NULL,
  `current_status` varchar(255) NOT NULL DEFAULT 'active',
  `status_id` bigint(20) unsigned NOT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaigns_status_id_foreign` (`status_id`),
  KEY `campaigns_brand_id_foreign` (`brand_id`),
  KEY `campaigns_created_by_foreign` (`created_by`),
  CONSTRAINT `campaigns_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `campaigns_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `campaigns_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Categ',1,'2023-07-10 10:15:13','2023-07-10 10:15:13'),(2,'Cat 2',1,'2023-08-05 12:00:19','2023-08-05 12:00:19');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `college`
--

DROP TABLE IF EXISTS `college`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `college` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `access_code` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `license` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 1 COMMENT '1 AS ACTIVE : 0 AS INACTIVE|2 AS DELETED',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `college`
--

LOCK TABLES `college` WRITE;
/*!40000 ALTER TABLE `college` DISABLE KEYS */;
INSERT INTO `college` VALUES (1,'iit delhi','WnTd5Ds4hzbxrfqJLA7Z',1,1,0,1,'2023-04-06 06:09:16','2023-04-06 06:09:16'),(2,'SCOTTSDALE UNIVERSITY','ScpZAdG40Ko1neJUEQIF',1,NULL,0,1,'2023-04-13 18:35:47','2023-04-13 18:35:47'),(3,'iit_hyderabad','zUPRXxnbemJCuhaVQA8r',1,NULL,0,1,'2023-04-14 05:50:11','2023-04-14 05:50:11'),(4,'Test','ueUAvr4IE3h5Ha7Fi0MY',1,NULL,0,1,'2023-04-16 16:53:53','2023-04-16 16:53:53'),(5,'test123','vkARuOrxS7l0wV2HeY8z',1,NULL,0,1,'2023-04-17 16:23:16','2023-04-17 16:23:16'),(6,'TestingTenant','scQl1I2OezGTw05ZRDj6',1,NULL,0,1,'2023-05-04 05:52:18','2023-05-04 05:52:18'),(7,'iit_lucknow','3WzR1tbdHSgLUQAGqPXE',1,NULL,0,1,'2023-05-18 16:26:01','2023-05-18 16:26:01'),(8,'IISE','Clbm7v3OtzZIyBq5P9LH',1,1,0,1,'2023-05-24 10:15:28','2023-05-24 10:15:28'),(9,'Vips','d59bvoOKainQ2rzxWes7',1,NULL,0,1,'2023-05-27 10:05:14','2023-05-27 10:05:14'),(10,'Jims','I6ejVyE0rDLWza5HbCf3',1,NULL,0,1,'2023-05-27 10:05:31','2023-05-27 10:05:31'),(11,'IIIT Delhi','qmS1bBif4o8HO5gPNEFh',1,NULL,0,1,'2023-05-27 10:05:46','2023-05-27 10:05:46'),(12,'Purdue Cybertap','KjNup2TnbRt4ZBfxMW3d',1,NULL,0,1,'2023-06-07 06:57:26','2023-06-07 06:57:26'),(13,'Purdue CyberTAP','3gpN92m5lerYjRnwtP74',1,NULL,0,1,'2023-06-07 06:58:34','2023-06-07 06:58:34'),(14,'ScottsdaleCollege','edScUhwiX1yAT9zY4q3g',1,NULL,0,1,'2023-06-07 09:56:42','2023-06-07 09:56:42'),(15,'IU','LmIkKNt3A2rFsuGioWEg',1,NULL,0,2,'2023-06-07 10:03:17','2023-06-07 10:03:17'),(16,'Project','viUa2c3O76FGewqJSMQC',1,NULL,0,1,'2023-06-07 23:35:51','2023-06-07 23:35:51'),(17,'Project','mciEBSpALtIs5T6a0XNW',1,NULL,0,1,'2023-06-08 04:13:53','2023-06-08 04:13:53'),(18,'DemoTenant','bmOI3qn8HwdDhrQ9aYVi',1,1,2,1,'2023-06-09 11:12:59','2023-06-09 11:12:59'),(19,'Niet_jamshedpur','NnaID4RjWSJbGw32ZgOF',1,NULL,0,1,'2023-06-17 11:35:42','2023-06-17 11:35:42'),(20,'Niet_jamshedpur','rQRWKL6Hw8p3YnoFIk2x',1,NULL,0,1,'2023-06-17 11:36:04','2023-06-17 11:36:04'),(21,'Mumbai Indians','FjevwK4pcEDVYHoTMba8',1,NULL,0,1,'2023-08-08 12:14:39','2023-08-08 12:14:39'),(24,'iise_lucknow','CPjdtwJci0GquZlRs5e1',1,NULL,1,1,'2023-10-04 10:11:16','2023-10-04 10:11:16');
/*!40000 ALTER TABLE `college` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_title` varchar(200) NOT NULL,
  `course_category_id` int(11) NOT NULL,
  `course_level` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'sql',1,1,1,'<p>Structure query language</p>',1,'2023-09-16 23:58:04','2023-09-17 01:05:00');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_category`
--

DROP TABLE IF EXISTS `course_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_category`
--

LOCK TABLES `course_category` WRITE;
/*!40000 ALTER TABLE `course_category` DISABLE KEYS */;
INSERT INTO `course_category` VALUES (1,'Databasess',1,'2023-08-08 08:57:12','2023-08-08 08:57:12'),(2,'NODE',1,'2023-08-08 09:54:54','2023-08-08 09:54:54');
/*!40000 ALTER TABLE `course_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_section`
--

DROP TABLE IF EXISTS `course_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `section` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_section`
--

LOCK TABLES `course_section` WRITE;
/*!40000 ALTER TABLE `course_section` DISABLE KEYS */;
INSERT INTO `course_section` VALUES (1,1,'select','select statement','2023-09-17 06:58:39','2023-09-17 06:58:39'),(2,1,'update','update statement','2023-09-17 07:01:03','2023-09-17 07:01:03');
/*!40000 ALTER TABLE `course_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_section_chapter`
--

DROP TABLE IF EXISTS `course_section_chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_section_chapter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_section_chapter`
--

LOCK TABLES `course_section_chapter` WRITE;
/*!40000 ALTER TABLE `course_section_chapter` DISABLE KEYS */;
INSERT INTO `course_section_chapter` VALUES (1,1,'simple select','<p>select * from user</p>','2023-09-17 06:59:51','2023-09-17 06:59:51'),(2,1,'select specific','<p>select name,mobile,email from users;</p>','2023-09-17 07:00:33','2023-09-17 07:00:33'),(4,2,'simple update','<p>update table users name = \'sweta\'</p>','2023-09-17 07:07:28','2023-09-17 07:07:28');
/*!40000 ALTER TABLE `course_section_chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_sub_category`
--

DROP TABLE IF EXISTS `course_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_sub_category`
--

LOCK TABLES `course_sub_category` WRITE;
/*!40000 ALTER TABLE `course_sub_category` DISABLE KEYS */;
INSERT INTO `course_sub_category` VALUES (1,'DML',1,1,'2023-08-08 09:45:38','2023-08-08 09:52:10'),(2,'Basic',2,1,'2023-08-08 09:55:22','2023-08-08 09:55:22');
/*!40000 ALTER TABLE `course_sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_types`
--

DROP TABLE IF EXISTS `custom_field_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_types`
--

LOCK TABLES `custom_field_types` WRITE;
/*!40000 ALTER TABLE `custom_field_types` DISABLE KEYS */;
INSERT INTO `custom_field_types` VALUES (1,'text',NULL,NULL),(2,'textarea',NULL,NULL),(3,'radio',NULL,NULL),(4,'select',NULL,NULL),(5,'date',NULL,NULL),(6,'number',NULL,NULL);
/*!40000 ALTER TABLE `custom_field_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_values`
--

DROP TABLE IF EXISTS `custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `contextable_type` varchar(255) NOT NULL,
  `contextable_id` varchar(255) NOT NULL,
  `custom_field_id` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_field_values_custom_field_id_foreign` (`custom_field_id`),
  KEY `custom_field_values_updated_by_foreign` (`updated_by`),
  CONSTRAINT `custom_field_values_custom_field_id_foreign` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`),
  CONSTRAINT `custom_field_values_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_values`
--

LOCK TABLES `custom_field_values` WRITE;
/*!40000 ALTER TABLE `custom_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `custom_field_type_id` bigint(20) unsigned NOT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `context` varchar(255) NOT NULL,
  `meta` text DEFAULT NULL,
  `in_list` tinyint(1) NOT NULL DEFAULT 0,
  `is_for_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_fields_custom_field_type_id_foreign` (`custom_field_type_id`),
  KEY `custom_fields_created_by_foreign` (`created_by`),
  KEY `custom_fields_brand_id_foreign` (`brand_id`),
  CONSTRAINT `custom_fields_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `custom_fields_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `custom_fields_custom_field_type_id_foreign` FOREIGN KEY (`custom_field_type_id`) REFERENCES `custom_field_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (1,3,NULL,1,'efwvf','subscriber','wefvw',1,0,'2023-06-08 02:05:52','2023-06-08 02:05:52');
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_logs`
--

DROP TABLE IF EXISTS `email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_id` varchar(150) DEFAULT NULL,
  `subscriber_id` bigint(20) unsigned NOT NULL,
  `campaign_id` bigint(20) unsigned NOT NULL,
  `email_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `email_content` longtext DEFAULT NULL,
  `open_count` int(11) NOT NULL DEFAULT 0,
  `click_count` int(11) NOT NULL DEFAULT 0,
  `delivery_server` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status_id` bigint(20) unsigned DEFAULT NULL,
  `is_marked_as_spam` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tracker_id` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_logs_tracker_id_unique` (`tracker_id`),
  KEY `email_logs_subscriber_id_foreign` (`subscriber_id`),
  KEY `email_logs_campaign_id_foreign` (`campaign_id`),
  KEY `email_logs_status_id_foreign` (`status_id`),
  CONSTRAINT `email_logs_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`),
  CONSTRAINT `email_logs_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`),
  CONSTRAINT `email_logs_subscriber_id_foreign` FOREIGN KEY (`subscriber_id`) REFERENCES `subscribers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_logs`
--

LOCK TABLES `email_logs` WRITE;
/*!40000 ALTER TABLE `email_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `fileable_type` varchar(160) NOT NULL,
  `fileable_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fileable_index` (`fileable_type`,`fileable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gain`
--

DROP TABLE IF EXISTS `gain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gain` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gain`
--

LOCK TABLES `gain` WRITE;
/*!40000 ALTER TABLE `gain` DISABLE KEYS */;
/*!40000 ALTER TABLE `gain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(160) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base`
--

DROP TABLE IF EXISTS `knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base`
--

LOCK TABLES `knowledge_base` WRITE;
/*!40000 ALTER TABLE `knowledge_base` DISABLE KEYS */;
INSERT INTO `knowledge_base` VALUES (1,1,1,1,'Sub cat content 1',1,'2023-07-11 11:13:27','2023-07-30 10:03:08'),(2,2,4,2,'<p><font color=\"#000000\"><span style=\"background-color: rgb(255, 255, 0);\">hi</span><span style=\"background-color: rgb(156, 198, 239);\">&nbsp;hii&nbsp; &nbsp; Hello 111</span></font></p>',1,'2023-08-05 03:00:36','2023-08-16 10:01:53'),(3,1,2,1,'<p><font color=\"#000000\"><span style=\"background-color: rgb(255, 255, 0);\">Version 1&nbsp;</span></font></p>',1,'2023-08-06 09:12:22','2023-08-06 09:12:22'),(4,1,2,1,'<p><font color=\"#000000\"><span style=\"background-color: rgb(255, 255, 0);\">NEW KNOWLEDGE&nbsp;</span></font></p>',1,'2023-08-06 09:12:22','2023-08-06 09:12:22');
/*!40000 ALTER TABLE `knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license`
--

DROP TABLE IF EXISTS `license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `license` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license_number` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license`
--

LOCK TABLES `license` WRITE;
/*!40000 ALTER TABLE `license` DISABLE KEYS */;
INSERT INTO `license` VALUES (1,'LIC0001',1,'2023-09-26 18:35:30'),(2,'LIC0002',1,'2023-10-04 10:25:36');
/*!40000 ALTER TABLE `license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_segment`
--

DROP TABLE IF EXISTS `list_segment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_segment` (
  `list_id` bigint(20) unsigned NOT NULL,
  `segment_id` bigint(20) unsigned NOT NULL,
  KEY `list_segment_list_id_foreign` (`list_id`),
  KEY `list_segment_segment_id_foreign` (`segment_id`),
  CONSTRAINT `list_segment_list_id_foreign` FOREIGN KEY (`list_id`) REFERENCES `lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `list_segment_segment_id_foreign` FOREIGN KEY (`segment_id`) REFERENCES `segments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_segment`
--

LOCK TABLES `list_segment` WRITE;
/*!40000 ALTER TABLE `list_segment` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_segment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_subscriber`
--

DROP TABLE IF EXISTS `list_subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_subscriber` (
  `list_id` bigint(20) unsigned NOT NULL,
  `subscriber_id` bigint(20) unsigned NOT NULL,
  KEY `list_subscriber_list_id_foreign` (`list_id`),
  KEY `list_subscriber_subscriber_id_foreign` (`subscriber_id`),
  CONSTRAINT `list_subscriber_list_id_foreign` FOREIGN KEY (`list_id`) REFERENCES `lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `list_subscriber_subscriber_id_foreign` FOREIGN KEY (`subscriber_id`) REFERENCES `subscribers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_subscriber`
--

LOCK TABLES `list_subscriber` WRITE;
/*!40000 ALTER TABLE `list_subscriber` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_subscriber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('imported','dynamic') NOT NULL,
  `status_id` bigint(20) unsigned DEFAULT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lists_status_id_foreign` (`status_id`),
  KEY `lists_brand_id_foreign` (`brand_id`),
  KEY `lists_created_by_foreign` (`created_by`),
  CONSTRAINT `lists_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lists_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `lists_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lists`
--

LOCK TABLES `lists` WRITE;
/*!40000 ALTER TABLE `lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logic_names`
--

DROP TABLE IF EXISTS `logic_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logic_names` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logic_names`
--

LOCK TABLES `logic_names` WRITE;
/*!40000 ALTER TABLE `logic_names` DISABLE KEYS */;
INSERT INTO `logic_names` VALUES (1,'created_at','date',NULL,NULL),(2,'last_updated','date',NULL,NULL),(3,'first_name','text',NULL,NULL),(4,'last_name','text',NULL,NULL);
/*!40000 ALTER TABLE `logic_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logic_operators`
--

DROP TABLE IF EXISTS `logic_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logic_operators` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logic_operators`
--

LOCK TABLES `logic_operators` WRITE;
/*!40000 ALTER TABLE `logic_operators` DISABLE KEYS */;
INSERT INTO `logic_operators` VALUES (1,'on','date',NULL,NULL),(2,'before','date',NULL,NULL),(3,'after','date',NULL,NULL),(4,'on or before','date',NULL,NULL),(5,'on or after','date',NULL,NULL),(6,'between','date_range',NULL,NULL),(7,'is','text',NULL,NULL),(8,'is not','text',NULL,NULL),(9,'contains','text',NULL,NULL),(10,'does not contain','text',NULL,NULL),(11,'starts with','text',NULL,NULL),(12,'ends with','text',NULL,NULL),(13,'does not start with','text',NULL,NULL),(14,'does not end with','text',NULL,NULL);
/*!40000 ALTER TABLE `logic_operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logic_relation`
--

DROP TABLE IF EXISTS `logic_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logic_relation` (
  `name_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned NOT NULL,
  KEY `logic_relation_name_id_foreign` (`name_id`),
  KEY `logic_relation_operator_id_foreign` (`operator_id`),
  CONSTRAINT `logic_relation_name_id_foreign` FOREIGN KEY (`name_id`) REFERENCES `logic_names` (`id`) ON DELETE CASCADE,
  CONSTRAINT `logic_relation_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `logic_operators` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logic_relation`
--

LOCK TABLES `logic_relation` WRITE;
/*!40000 ALTER TABLE `logic_relation` DISABLE KEYS */;
INSERT INTO `logic_relation` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(3,7),(3,8),(3,9),(3,10),(3,11),(3,12),(3,13),(3,14),(4,7),(4,8),(4,9),(4,10),(4,11),(4,12),(4,13),(4,14);
/*!40000 ALTER TABLE `logic_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2013_02_09_0000_create_types_table',1),(2,'2013_02_10_072424_create_statuses_table',1),(3,'2014_10_12_000000_create_users_table',1),(4,'2014_10_12_100000_create_password_resets_table',1),(5,'2015_02_07_072734_create_brand_groups_table',1),(6,'2015_02_10_072734_create_brands_table',1),(7,'2017_09_03_144628_create_permission_tables',1),(8,'2017_09_04_064802_create_role_user_table',1),(9,'2017_09_26_140332_create_cache_table',1),(10,'2017_09_26_140528_create_sessions_table',1),(11,'2017_09_26_140609_create_jobs_table',1),(12,'2018_04_08_033256_create_password_histories_table',1),(13,'2019_08_19_000000_create_failed_jobs_table',1),(14,'2020_02_10_071640_create_settings_table',1),(15,'2020_02_11_083419_create_custom_field_types_table',1),(16,'2020_02_11_083437_create_custom_fields_table',1),(17,'2020_02_11_083711_create_custom_field_values_table',1),(18,'2020_02_12_123449_create_notification_events_table',1),(19,'2020_02_12_123727_create_notification_settings_table',1),(20,'2020_02_12_124416_create_notification_channels_table',1),(21,'2020_02_12_124533_create_notification_audiences_table',1),(22,'2020_02_17_061739_create_brand_user_table',1),(23,'2020_02_18_141948_create_notifications_table',1),(24,'2020_02_19_092540_create_activity_log_table',1),(25,'2020_02_26_112625_create_files_table',1),(26,'2020_03_10_124422_create_notification_templates_table',1),(27,'2020_03_10_124437_create_notification_event_template_table',1),(28,'2020_03_15_100027_create_templates_table',1),(29,'2020_03_22_110337_create_segments_table',1),(30,'2020_03_22_113714_create_logic_names_table',1),(31,'2020_03_22_113738_create_logic_operators_table',1),(32,'2020_03_22_114815_create_logic_relation_table',1),(33,'2020_03_22_115810_create_lists_table',1),(34,'2020_03_22_120129_create_list_segment_table',1),(35,'2020_03_22_121538_create_campaigns_table',1),(36,'2020_03_22_122446_create_campaign_audiences_table',1),(37,'2020_03_22_124258_create_subscribers_table',1),(38,'2020_03_22_124744_create_list_subscriber_table',1),(39,'2020_03_22_125135_create_email_logs_table',1),(40,'2020_05_03_091140_create_profile_table',1),(41,'2020_05_11_050824_create_campaign_process_table',1),(42,'2020_05_20_074235_create_sns_subscriptions_table',1),(43,'2020_07_02_141217_create_gain_table',1),(44,'2020_08_06_080504_create_api_keys_table',1),(45,'2021_02_02_124143_add_tracker_id_in_email_logs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_audiences`
--

DROP TABLE IF EXISTS `notification_audiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_audiences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notification_setting_id` bigint(20) unsigned NOT NULL,
  `audience_type` varchar(255) NOT NULL,
  `audiences` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_audiences_notification_setting_id_foreign` (`notification_setting_id`),
  CONSTRAINT `notification_audiences_notification_setting_id_foreign` FOREIGN KEY (`notification_setting_id`) REFERENCES `notification_settings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_audiences`
--

LOCK TABLES `notification_audiences` WRITE;
/*!40000 ALTER TABLE `notification_audiences` DISABLE KEYS */;
INSERT INTO `notification_audiences` VALUES (1,1,'roles','[1]','2023-01-27 04:58:20','2023-01-27 04:58:20'),(2,2,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(3,3,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(4,4,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(5,5,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(6,6,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(7,7,'roles','[1]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(8,8,'roles','[2]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(9,9,'roles','[2]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(10,10,'roles','[2]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(11,11,'roles','[2]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(12,12,'roles','[4]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(13,13,'roles','[4]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(14,14,'roles','[4]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(15,15,'roles','[4]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(16,16,'roles','[5]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(17,17,'roles','[5]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(18,18,'roles','[5]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(19,19,'roles','[5]','2023-03-10 02:43:59','2023-03-10 02:43:59'),(20,20,'roles','[6]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(21,21,'roles','[6]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(22,22,'roles','[6]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(23,23,'roles','[6]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(24,24,'roles','[7]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(25,25,'roles','[7]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(26,26,'roles','[7]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(27,27,'roles','[7]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(28,28,'roles','[8]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(29,29,'roles','[8]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(30,30,'roles','[8]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(31,31,'roles','[8]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(32,32,'roles','[9]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(33,33,'roles','[9]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(34,34,'roles','[9]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(35,35,'roles','[9]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(36,36,'roles','[11]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(37,37,'roles','[11]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(38,38,'roles','[11]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(39,39,'roles','[11]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(40,40,'roles','[12]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(41,41,'roles','[12]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(42,42,'roles','[12]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(43,43,'roles','[12]','2023-06-08 00:19:10','2023-06-08 00:19:10');
/*!40000 ALTER TABLE `notification_audiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_channels`
--

DROP TABLE IF EXISTS `notification_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_channels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_channels`
--

LOCK TABLES `notification_channels` WRITE;
/*!40000 ALTER TABLE `notification_channels` DISABLE KEYS */;
INSERT INTO `notification_channels` VALUES (1,'database',NULL,NULL),(2,'mail',NULL,NULL);
/*!40000 ALTER TABLE `notification_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_event_template`
--

DROP TABLE IF EXISTS `notification_event_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_event_template` (
  `notification_event_id` bigint(20) unsigned NOT NULL,
  `notification_template_id` bigint(20) unsigned NOT NULL,
  KEY `notification_event_template_notification_event_id_foreign` (`notification_event_id`),
  KEY `notification_event_template_notification_template_id_foreign` (`notification_template_id`),
  CONSTRAINT `notification_event_template_notification_event_id_foreign` FOREIGN KEY (`notification_event_id`) REFERENCES `notification_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notification_event_template_notification_template_id_foreign` FOREIGN KEY (`notification_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_event_template`
--

LOCK TABLES `notification_event_template` WRITE;
/*!40000 ALTER TABLE `notification_event_template` DISABLE KEYS */;
INSERT INTO `notification_event_template` VALUES (1,1),(2,2),(3,4),(3,3),(4,6),(4,5),(5,8),(5,7),(6,10),(6,9),(7,12),(7,11),(8,14),(8,13),(9,16),(9,15),(10,18),(10,17),(11,20),(11,19);
/*!40000 ALTER TABLE `notification_event_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_events`
--

DROP TABLE IF EXISTS `notification_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_events_type_id_foreign` (`type_id`),
  CONSTRAINT `notification_events_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_events`
--

LOCK TABLES `notification_events` WRITE;
/*!40000 ALTER TABLE `notification_events` DISABLE KEYS */;
INSERT INTO `notification_events` VALUES (1,'user_invitation',1,NULL,NULL),(2,'password_reset',1,NULL,NULL),(3,'user_joined',1,NULL,NULL),(4,'brand_created',1,NULL,NULL),(5,'brand_updated',1,NULL,NULL),(6,'brand_activated',1,NULL,NULL),(7,'brand_deactivated',1,NULL,NULL),(8,'campaign_created',2,NULL,NULL),(9,'campaign_updated',2,NULL,NULL),(10,'campaign_confirmed',2,NULL,NULL),(11,'campaign_archived',2,NULL,NULL);
/*!40000 ALTER TABLE `notification_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notification_event_id` bigint(20) unsigned NOT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `notify_by` varchar(255) NOT NULL COMMENT 'List of notification channels.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_settings_notification_event_id_foreign` (`notification_event_id`),
  KEY `notification_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `notification_settings_notification_event_id_foreign` FOREIGN KEY (`notification_event_id`) REFERENCES `notification_events` (`id`),
  CONSTRAINT `notification_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
INSERT INTO `notification_settings` VALUES (1,1,NULL,NULL,'[\"database\"]','2023-01-27 04:58:20','2023-01-27 04:58:20'),(2,2,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(3,3,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(4,4,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(5,5,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(6,6,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(7,7,NULL,NULL,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(8,8,NULL,1,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(9,9,NULL,1,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(10,10,NULL,1,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(11,11,NULL,1,'[\"database\"]','2023-01-27 04:58:21','2023-01-27 04:58:21'),(12,8,NULL,2,'[\"database\"]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(13,9,NULL,2,'[\"database\"]','2023-02-06 23:55:12','2023-02-06 23:55:12'),(14,10,NULL,2,'[\"database\"]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(15,11,NULL,2,'[\"database\"]','2023-02-06 23:55:13','2023-02-06 23:55:13'),(16,8,NULL,3,'[\"database\"]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(17,9,NULL,3,'[\"database\"]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(18,10,NULL,3,'[\"database\"]','2023-03-10 02:43:58','2023-03-10 02:43:58'),(19,11,NULL,3,'[\"database\"]','2023-03-10 02:43:59','2023-03-10 02:43:59'),(20,8,NULL,4,'[\"database\"]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(21,9,NULL,4,'[\"database\"]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(22,10,NULL,4,'[\"database\"]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(23,11,NULL,4,'[\"database\"]','2023-03-16 05:58:48','2023-03-16 05:58:48'),(24,8,NULL,5,'[\"database\"]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(25,9,NULL,5,'[\"database\"]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(26,10,NULL,5,'[\"database\"]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(27,11,NULL,5,'[\"database\"]','2023-05-27 10:10:37','2023-05-27 10:10:37'),(28,8,NULL,6,'[\"database\"]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(29,9,NULL,6,'[\"database\"]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(30,10,NULL,6,'[\"database\"]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(31,11,NULL,6,'[\"database\"]','2023-05-27 10:11:43','2023-05-27 10:11:43'),(32,8,NULL,7,'[\"database\"]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(33,9,NULL,7,'[\"database\"]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(34,10,NULL,7,'[\"database\"]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(35,11,NULL,7,'[\"database\"]','2023-05-27 10:12:36','2023-05-27 10:12:36'),(36,8,NULL,8,'[\"database\"]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(37,9,NULL,8,'[\"database\"]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(38,10,NULL,8,'[\"database\"]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(39,11,NULL,8,'[\"database\"]','2023-06-08 00:18:55','2023-06-08 00:18:55'),(40,8,NULL,9,'[\"database\"]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(41,9,NULL,9,'[\"database\"]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(42,10,NULL,9,'[\"database\"]','2023-06-08 00:19:10','2023-06-08 00:19:10'),(43,11,NULL,9,'[\"database\"]','2023-06-08 00:19:10','2023-06-08 00:19:10');
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject` text DEFAULT NULL,
  `default_content` longtext DEFAULT NULL,
  `custom_content` longtext DEFAULT NULL,
  `type` enum('sms','mail','database') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` VALUES (1,'User invitation form {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>Hope this mail finds you well and healthy. We are informing you that you\'ve been invited to our application by {action_by}. It\'ll be a great opportunity to work with you.</p><br>\n<p><a href=\"{invitation_url}\" target=\"_blank\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\">Accept Invitation</a></p><br>\n\n<p></p><p>Thanks &amp; Regards,\n</p><p>{app_name}</p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(2,'Password reset link provided by {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>Your request for reset password has been approved from {app_name}. Press the button below to reset the password.</p><br>\n<p><a href=\"{reset_password_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">Reset password</a></p><br>\n\nWe are highly expecting you as soon as possible. Hope you\'ll join us.\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(3,'A new user has been joined in {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a new user {name} has been joined in our application invited by {action_by}. Hope you will enjoy his work and collaborations.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Resource</a></p><br>\n\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(4,NULL,'A new user has been joined in {app_name}',NULL,'database','2023-01-27 04:58:22','2023-01-27 04:58:22'),(5,'A new brand has been created in {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a new brand named {name} has been created in our application by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; ; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Brand</a></p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(6,NULL,'A new brand named {name} has been created by {action_by}.',NULL,'database','2023-01-27 04:58:22','2023-01-27 04:58:22'),(7,'A brand has been updated in {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a brand named {name} has been updated in our application by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Brand</a></p><br>\n\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(8,NULL,'A brand named {name} has been updated by {action_by}.',NULL,'database','2023-01-27 04:58:22','2023-01-27 04:58:22'),(9,'A brand has been activated in {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>We are going to inform you that a brand named {name} has been activated from our application by {action_by}.</p>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(10,NULL,'A brand named {name} has been activated by {action_by}.',NULL,'database','2023-01-27 04:58:22','2023-01-27 04:58:22'),(11,'A brand has been deactivated in {app_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>We are going to inform you that a brand named {name} has been deactivated from our application by {action_by}.</p>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:22','2023-01-27 04:58:22'),(12,NULL,'A brand named {name} has been deactivated by {action_by}.',NULL,'database','2023-01-27 04:58:22','2023-01-27 04:58:22'),(13,'A new campaign has been created in {brand_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a new brand named {name} has been created in our application by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; ; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Campaign</a></p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:23','2023-01-27 04:58:23'),(14,NULL,'A new campaign named {name} has been created by {action_by}.','A new campaign named {name} has been created by {action_by}.','database','2023-01-27 04:58:23','2023-02-02 05:26:07'),(15,'A campaign has been updated in {brand_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a campaign named {name} has been updated in our application by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Campaign</a></p><br>\n\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:23','2023-01-27 04:58:23'),(16,NULL,'A campaign named {name} has been updated by {action_by}.',NULL,'database','2023-01-27 04:58:23','2023-01-27 04:58:23'),(17,'A campaign has been confirmed in {brand_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>It\'s a piece of good news that a campaign named {name} has been confirmed in {brand_name} brand by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none; box-shadow: 0 4px 4px rgba(0, 0, 0, 0.2)\" target=\"_blank\">View Campaign</a></p><br>\n\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:23','2023-01-27 04:58:23'),(18,NULL,'A campaign named {name} has been confirmed by {action_by}.',NULL,'database','2023-01-27 04:58:23','2023-01-27 04:58:23'),(19,'A campaign has been archived in {brand_name}','<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>We are going to inform you that a campaign named {name} has been archived from our application by {action_by}.</p>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>',NULL,'mail','2023-01-27 04:58:23','2023-01-27 04:58:23'),(20,NULL,'A campaign named {name} has been archived by {action_by}.',NULL,'database','2023-01-27 04:58:23','2023-01-27 04:58:23');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(160) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('e00a9b47-51b5-4e3f-8375-f760bc93b217','App\\Notifications\\Core\\User\\UserInvitationNotification','App\\Models\\Core\\Auth\\User',1,'{\"message\":\"A new user has been joined in <b>Mailer<\\/b>\",\"name\":\"rootCapture\'s Enterprise Administrator\",\"url\":\"https:\\/\\/rootcapture.com\\/adminenterprise\\/admin\\/users\\/list?user=3\",\"notifier_id\":null}','2023-01-31 09:44:56','2023-01-31 08:34:46','2023-01-31 09:44:56');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_histories`
--

DROP TABLE IF EXISTS `password_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_histories`
--

LOCK TABLES `password_histories` WRITE;
/*!40000 ALTER TABLE `password_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(160) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('cms@mailinator.com','MTY3NjAxMDI4Mi45MTI=','2023-02-10 06:24:42'),('cms@mailinator.com','MTY3NjAxMDM4Mi43MTg5','2023-02-10 06:26:22'),('cms@mailinator.com','MTY3NjI4NTM3NC4yNTQ0','2023-02-13 10:49:34'),('cms@mailinator.com','MTY3NjI4NTQxMy40Mjk2','2023-02-13 10:50:13'),('cms@mailinator.com','MTY3NjI4NTgwMi41NTE5','2023-02-13 10:56:42'),('admin@rootcapture.com','MTY3NzY0OTk3MC43MjUz','2023-03-01 05:52:50');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_type_id_foreign` (`type_id`),
  CONSTRAINT `permissions_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,1,'view_brands','brands_and_groups',NULL,NULL),(2,1,'create_brands','brands_and_groups',NULL,NULL),(3,1,'update_brands','brands_and_groups',NULL,NULL),(4,1,'delete_brands','brands_and_groups',NULL,NULL),(5,1,'create_brand_groups','brands_and_groups',NULL,NULL),(6,1,'view_brand_groups','brands_and_groups',NULL,NULL),(7,1,'update_brand_groups','brands_and_groups',NULL,NULL),(8,1,'delete_brand_groups','brands_and_groups',NULL,NULL),(9,NULL,'invite_user','users',NULL,NULL),(10,NULL,'view_users','users',NULL,NULL),(11,NULL,'update_users','users',NULL,NULL),(12,NULL,'delete_users','users',NULL,NULL),(13,NULL,'attach_roles_users','users',NULL,NULL),(14,NULL,'detach_roles_users','users',NULL,NULL),(15,NULL,'view_roles','roles',NULL,NULL),(16,NULL,'create_roles','roles',NULL,NULL),(17,NULL,'update_roles','roles',NULL,NULL),(18,NULL,'delete_roles','roles',NULL,NULL),(19,NULL,'attach_users_to_roles','roles',NULL,NULL),(20,1,'view_settings','app_settings',NULL,NULL),(21,1,'update_settings','app_settings',NULL,NULL),(22,1,'view_delivery_settings','app_settings',NULL,NULL),(23,1,'update_delivery_settings','app_settings',NULL,NULL),(24,1,'view_brand_delivery_settings','brand_settings',NULL,NULL),(25,1,'update_brand_delivery_settings','brand_settings',NULL,NULL),(26,1,'update_brand_privacy_settings','brand_settings',NULL,NULL),(27,1,'view_brand_privacy_settings','brand_settings',NULL,NULL),(28,2,'update_specific_brand_delivery_settings','brand_settings',NULL,NULL),(29,2,'view_specific_brand_delivery_settings','brand_settings',NULL,NULL),(30,NULL,'view_notification_settings','notifications',NULL,NULL),(31,NULL,'update_notification_settings','notifications',NULL,NULL),(32,1,'view_notification_templates','notifications',NULL,NULL),(33,1,'update_notification_templates','notifications',NULL,NULL),(34,NULL,'view_custom_fields','custom_fields',NULL,NULL),(35,NULL,'create_custom_fields','custom_fields',NULL,NULL),(36,NULL,'update_custom_fields','custom_fields',NULL,NULL),(37,NULL,'delete_custom_fields','custom_fields',NULL,NULL),(38,2,'view_sns_subscription','amazon_ses',NULL,NULL),(39,2,'confirm_sns_subscription','amazon_ses',NULL,NULL),(40,2,'view_emails','emails',NULL,NULL),(41,2,'delete_emails','emails',NULL,NULL),(42,2,'view_campaigns','campaigns',NULL,NULL),(43,2,'create_campaigns','campaigns',NULL,NULL),(44,2,'update_campaigns','campaigns',NULL,NULL),(45,2,'delete_campaigns','campaigns',NULL,NULL),(46,2,'delivery_settings_campaigns','campaigns',NULL,NULL),(47,2,'audiences_campaigns','campaigns',NULL,NULL),(48,2,'template_campaigns','campaigns',NULL,NULL),(49,2,'confirm_campaigns','campaigns',NULL,NULL),(50,2,'email_logs_campaigns','campaigns',NULL,NULL),(51,2,'subscribers_campaigns','campaigns',NULL,NULL),(52,2,'test_campaign','campaigns',NULL,NULL),(53,2,'duplicate_campaigns','campaigns',NULL,NULL),(54,2,'pause_or_resume_campaigns','campaigns',NULL,NULL),(55,2,'view_lists','lists',NULL,NULL),(56,2,'create_lists','lists',NULL,NULL),(57,2,'update_lists','lists',NULL,NULL),(58,2,'delete_lists','lists',NULL,NULL),(59,2,'dynamic_subscribers_lists','lists',NULL,NULL),(60,2,'view_segments','segments',NULL,NULL),(61,2,'create_segments','segments',NULL,NULL),(62,2,'update_segments','segments',NULL,NULL),(63,2,'delete_segments','segments',NULL,NULL),(64,2,'view_brand_segment_counts','segments',NULL,NULL),(65,2,'copy_segments','segments',NULL,NULL),(66,2,'view_subscribers','subscriber',NULL,NULL),(67,2,'create_subscribers','subscriber',NULL,NULL),(68,2,'update_subscribers','subscriber',NULL,NULL),(69,2,'delete_subscribers','subscriber',NULL,NULL),(70,2,'import_subscribers','subscriber',NULL,NULL),(71,2,'generate_subscriber_api_url','subscriber',NULL,NULL),(72,2,'view_imported_subscribers','subscriber',NULL,NULL),(73,2,'bulk_import_subscribers','subscriber',NULL,NULL),(74,2,'quick_import_subscribers','subscriber',NULL,NULL),(75,2,'add_to_blacklist_subscribers','subscriber',NULL,NULL),(76,2,'remove_from_blacklist_subscribers','subscriber',NULL,NULL),(77,2,'view_subscribers_black_lists','subscriber',NULL,NULL),(78,2,'add_to_lists_subscribers','subscriber',NULL,NULL),(79,2,'remove_from_lists_subscribers','subscriber',NULL,NULL),(80,2,'bulk_destroy_subscribers','subscriber',NULL,NULL),(81,2,'update_status_subscribers','subscriber',NULL,NULL),(82,NULL,'view_templates','templates',NULL,NULL),(83,NULL,'create_templates','templates',NULL,NULL),(84,NULL,'update_templates','templates',NULL,NULL),(85,NULL,'delete_templates','templates',NULL,NULL),(86,1,'manage_dashboard','dashboard',NULL,NULL),(87,2,'campaigns_count_brands','dashboard',NULL,NULL),(88,2,'campaigns_count_app','dashboard',NULL,NULL),(89,2,'email_statistics_brands','dashboard',NULL,NULL),(90,1,'email_statistics_app','dashboard',NULL,NULL),(91,2,'subscribers_count_brands','dashboard',NULL,NULL),(92,2,'manage_brand_dashboard','dashboard',NULL,NULL),(93,1,'subscribers_count_app','dashboard',NULL,NULL),(94,1,'check_for_updates','update',NULL,NULL),(95,1,'update_app','update',NULL,NULL),(96,1,'view_blog','content_management_system',NULL,NULL),(97,1,'add_blog','content_management_system',NULL,NULL),(98,1,'edit_blog','content_management_system',NULL,NULL),(99,1,'delete_blog','content_management_system',NULL,NULL),(100,1,'blog_administration','manage_by_admin',NULL,NULL),(101,1,'view_tenants','manage_by_admin',NULL,NULL),(102,1,'add_tenants','manage_by_admin',NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profiles_user_id_foreign` (`user_id`),
  CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permission` (
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `meta` text DEFAULT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_permission_role_id_foreign` (`role_id`),
  CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (10,1,NULL),(13,1,NULL),(10,2,NULL),(13,2,NULL),(10,3,NULL),(13,3,NULL),(10,4,NULL),(13,4,NULL),(10,5,NULL),(13,5,NULL),(10,6,NULL),(13,6,NULL),(10,7,NULL),(13,7,NULL),(10,8,NULL),(13,8,NULL),(10,9,NULL),(13,9,NULL),(10,10,NULL),(13,10,NULL),(10,11,NULL),(13,11,NULL),(10,12,NULL),(13,12,NULL),(10,13,NULL),(13,13,NULL),(10,14,NULL),(13,14,NULL),(10,15,NULL),(10,16,NULL),(10,17,NULL),(10,18,NULL),(10,19,NULL),(10,20,NULL),(10,21,NULL),(10,22,NULL),(10,23,NULL),(10,24,NULL),(10,25,NULL),(10,26,NULL),(10,27,NULL),(10,28,NULL),(10,29,NULL),(10,30,NULL),(10,31,NULL),(10,32,NULL),(10,33,NULL),(10,34,NULL),(10,35,NULL),(10,36,NULL),(10,37,NULL),(10,38,NULL),(10,39,NULL),(10,40,NULL),(10,41,NULL),(10,42,NULL),(10,43,NULL),(10,44,NULL),(10,45,NULL),(10,46,NULL),(10,47,NULL),(10,48,NULL),(10,49,NULL),(10,50,NULL),(10,51,NULL),(10,52,NULL),(10,53,NULL),(10,54,NULL),(10,55,NULL),(10,56,NULL),(10,57,NULL),(10,58,NULL),(10,59,NULL),(10,60,NULL),(10,61,NULL),(10,62,NULL),(10,63,NULL),(10,64,NULL),(10,65,NULL),(10,66,NULL),(10,67,NULL),(10,68,NULL),(10,69,NULL),(10,70,NULL),(10,71,NULL),(10,72,NULL),(10,73,NULL),(10,74,NULL),(10,75,NULL),(10,76,NULL),(10,77,NULL),(10,78,NULL),(10,79,NULL),(10,80,NULL),(10,81,NULL),(10,82,NULL),(10,83,NULL),(10,84,NULL),(10,85,NULL),(10,86,NULL),(10,87,NULL),(10,88,NULL),(10,89,NULL),(10,90,NULL),(10,91,NULL),(10,92,NULL),(10,93,NULL),(10,94,NULL),(13,94,NULL),(10,95,NULL),(13,95,NULL),(3,96,NULL),(10,96,NULL),(10,97,NULL),(10,98,NULL),(10,99,NULL),(10,100,NULL),(13,100,NULL),(10,101,NULL),(13,101,NULL),(10,102,NULL),(13,102,NULL);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1),(3,3),(4,10),(5,3);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `type_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_brand_id_foreign` (`brand_id`),
  KEY `roles_type_id_foreign` (`type_id`),
  KEY `roles_created_by_foreign` (`created_by`),
  KEY `roles_name_index` (`name`),
  CONSTRAINT `roles_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `roles_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `roles_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'App admin',1,1,NULL,1,1,NULL,NULL),(2,'Brand admin',1,1,1,2,NULL,'2023-01-27 04:58:21','2023-01-27 04:58:21'),(3,'Content Administrator',0,0,NULL,1,1,'2023-01-31 02:47:08','2023-01-31 02:47:08'),(5,'Brand admin',1,1,3,2,1,'2023-03-10 02:43:58','2023-03-10 02:43:58'),(7,'Brand admin',1,1,5,2,1,'2023-05-27 10:10:36','2023-05-27 10:10:36'),(8,'Brand admin',1,1,6,2,1,'2023-05-27 10:11:42','2023-05-27 10:11:42'),(9,'Brand admin',1,1,7,2,1,'2023-05-27 10:12:36','2023-05-27 10:12:36'),(10,'MyTestRole',0,0,NULL,1,1,'2023-05-27 10:44:54','2023-05-27 10:44:54'),(11,'Brand admin',1,1,8,2,1,'2023-06-08 00:18:55','2023-06-08 00:18:55'),(12,'Brand admin',1,1,9,2,1,'2023-06-08 00:19:10','2023-06-08 00:19:10'),(13,'Test role',0,0,NULL,1,1,'2023-06-08 00:31:02','2023-06-08 00:31:02');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `segments`
--

DROP TABLE IF EXISTS `segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `segments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `segment_logic` longtext DEFAULT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `segments_brand_id_foreign` (`brand_id`),
  KEY `segments_created_by_foreign` (`created_by`),
  CONSTRAINT `segments_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `segments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `segments`
--

LOCK TABLES `segments` WRITE;
/*!40000 ALTER TABLE `segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(120) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` longtext DEFAULT NULL,
  `settingable_type` varchar(160) DEFAULT NULL,
  `settingable_id` bigint(20) unsigned DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 0,
  `public` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settingable_index` (`settingable_type`,`settingable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'purchase_code','f44c6931-b9b6-46ab-86e4-dbc2ba42d2cc',NULL,NULL,'purchase_code',0,1,'2023-01-27 04:58:19','2023-01-27 04:58:19'),(2,'company_name','rootCapture',NULL,NULL,'app',0,1,NULL,'2023-02-03 03:30:54'),(3,'company_logo','',NULL,NULL,'app',0,1,NULL,NULL),(4,'company_icon','',NULL,NULL,'app',0,1,NULL,NULL),(5,'company_banner','',NULL,NULL,'app',0,1,NULL,NULL),(6,'language','en',NULL,NULL,'app',0,1,NULL,NULL),(7,'date_format','d-m-Y',NULL,NULL,'app',0,1,NULL,NULL),(8,'time_format','h',NULL,NULL,'app',0,1,NULL,NULL),(9,'time_zone','UTC',NULL,NULL,'app',0,1,NULL,NULL),(10,'currency_symbol','$',NULL,NULL,'app',0,1,NULL,NULL),(11,'decimal_separator','.',NULL,NULL,'app',0,1,NULL,NULL),(12,'thousand_separator',',',NULL,NULL,'app',0,1,NULL,NULL),(13,'number_of_decimal','2',NULL,NULL,'app',0,1,NULL,NULL),(14,'currency_position','prefix_with_space',NULL,NULL,'app',0,1,NULL,NULL),(15,'track_open_in_campaigns','1','App\\Models\\Core\\App\\Brand\\Brand',9,'brand_default_privacy',0,1,'2023-01-27 04:58:23','2023-06-08 00:19:10'),(16,'track_clicks_in_your_campaigns','1','App\\Models\\Core\\App\\Brand\\Brand',9,'brand_default_privacy',0,1,'2023-01-27 04:58:23','2023-06-08 00:19:10'),(17,'track_location_in_your_campaigns','1','App\\Models\\Core\\App\\Brand\\Brand',9,'brand_default_privacy',0,1,'2023-01-27 04:58:23','2023-06-08 00:19:10'),(18,'from_name','eyJpdiI6IjdIMk5jVkl4cy82bDZiSVpQT0lEbnc9PSIsInZhbHVlIjoiUHI5YUE5NG5BMWY0c1ppOGZocFBGSnQxSjk2aTZTcDVvaXFwblFmc2thRT0iLCJtYWMiOiJhMzU0MDQxMDU1ZjZkMzIzZTllY2FkZjQ1ZjAwNTM1NzFlYTA0MTM0ZDBlMWI0NDhjNjZhOTE3YTlkMzYzMDA1IiwidGFnIjoiIn0=',NULL,NULL,'default_mail_email_name',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(19,'from_email','eyJpdiI6IjQ1c0RlcDk4WVI2Nm84eW40T0syMUE9PSIsInZhbHVlIjoiR3lzWjFRQ3NMWnRZY3VUejRTak95aUpzbVdqZS9pNk5ETEM0S3greE0zamRvK2lla1ZGR2ZzRmIxNDlSbFkyUiIsIm1hYyI6IjJjNjE3YTI4NWEwN2FlZGVjMDExMzIxNzcwYzUwNjg4MDU1ODI0OTYwMjUxMjE5YjA3OGI4NThkMWMyYWUzNTkiLCJ0YWciOiIifQ==',NULL,NULL,'default_mail_email_name',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(20,'provider','eyJpdiI6IjAxL2VVUWtMbEg4VXJ0RmlmcTFPS3c9PSIsInZhbHVlIjoidjhZTUwrRms0c3hzNzVZN2dacFFqZz09IiwibWFjIjoiN2Q0ZjY3NzJiOWU3ZTUzODRhNjk5YmExOTE4NWUwMDU2NzE0ZTNjMzFlYTZlYWVkYTI0MmNhYWY4YjMyMWQyZiIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(21,'smtp_daily_quota','eyJpdiI6IjhNVFdRSmFyVmk0MVFXcWtkSnprdnc9PSIsInZhbHVlIjoiNXRwMUxPQy8rTi9sbG1JL3dDaTl6dz09IiwibWFjIjoiNjE5YjAyZTRmNjk5ZmJiNzk0ZDExZjU5MjNiNmJjZjBiMmI0ZDgxZDU2YmI0OWVhYjE2NDI5Y2UwNzM5MTlkZCIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:57'),(22,'smtp_hourly_quota','eyJpdiI6IjFwd05YVzAzVlRwWkllZkRUV2lYV2c9PSIsInZhbHVlIjoiM3dRYm9teG4waWlsMWZ0WXhuYVBRdz09IiwibWFjIjoiNzU2Y2QwODY0Y2UyMmNlMTc5ODI2OTQxMDdjN2U1MzZlYzlhMWM3NzNhZDc0ZTY3MWI4ZTFhNzNhNzE2OWRlMSIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:57'),(23,'smtp_monthly_quota','eyJpdiI6InJacDVlNXVsS25yQkpVeG5FWVpMRnc9PSIsInZhbHVlIjoiZTgwekN4RHdKa3FhN2w0VmpmejhvUT09IiwibWFjIjoiOGRjYzIxNGMwOTkwZDE5NDI4MDVmOTcxOTZhNjM1ZDg2ZmRkNWMxOGQyNGVmZDQ0YmMzNTQ4MzMzYWE1MThlNiIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:57'),(24,'smtp_encryption','eyJpdiI6IjFmcmsyN251T0c5blVXblRiWEFvRVE9PSIsInZhbHVlIjoiQ0FyeWRUK0V1UjN0b1prZnFoZ0xnQT09IiwibWFjIjoiMGI3ZTQ4ZDAzYWFjMGE4Mzk4ZDU2M2YyZGIwMzhmNWZjNzljODdjOGE1MGFiZWIwNzc0ZTI3YTQ1MWYzZWFlMCIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:57'),(25,'smtp_password','eyJpdiI6IlY3N3R4VmM0M08zZll5eHFESXEyTkE9PSIsInZhbHVlIjoiZEo5M2tySExHaXZOSFBIQVJ6Qm9xcUNkRk9aelRSR2JGczJiQWFpaS9OUT0iLCJtYWMiOiI3NjM2NTI5MTZiNzEzYzQ0MzkzYTdjNDE5ZDI4NDIzNTIyMzU4MTk4NjdhMjNiNGNkYzY3ZGVlMjk4N2E2MjE2IiwidGFnIjoiIn0=',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(26,'smtp_host','eyJpdiI6IklwMVhOSHlTblVOR241UkV6WWlxOGc9PSIsInZhbHVlIjoidVMwNVZGaW8wWnY5c0VUTFJwcnl6d21sMDEyaFdJYUVxeU9sUTR1Y2pHQT0iLCJtYWMiOiI1Y2JlZmMyYzY4YjI3ZGY2Y2QzMDQ0Mzk3OWRhYTQ2YjBhNTY4NWY2YjA0Yjg2ZGJmODZjYzI0MmJhNGVjNTk1IiwidGFnIjoiIn0=',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(27,'smtp_port','eyJpdiI6IjA2MTBNdnRheW1ScmU3YnBGdzBoVHc9PSIsInZhbHVlIjoiV2d6djFRa0RzQVpmTjFVQk5KaUxndz09IiwibWFjIjoiN2IzZWI0Y2NiZTc4MmNlMWFkZTE2NDExMDkwOWU0M2IwOWQ3MDQ0MzY5ZWI3YWVjYTg0ZTJkMmZjZWQ4YzRmZCIsInRhZyI6IiJ9',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:56'),(28,'smtp_user_name','eyJpdiI6Ik9lNFRkUlZFOHM2b1EvVXJOQkU1eGc9PSIsInZhbHVlIjoiTnpOT0lYakxnTzJYeWlNZjExekNWdGtUZUVtK0ZwRVA0Mlp1QmxzN0pVUWhwckFQZDVkQVhJN3k5WjUycnJhRiIsIm1hYyI6IjgzMmEwNGM4NmViMmEwZTA2ZjU1MjUxMjVmYzNmZjgxZjY2MzAwNWE3NGRmOTBmY2FmZDhlMzM0ZTAyZGY0YzgiLCJ0YWciOiIifQ==',NULL,NULL,'smtp',0,1,'2023-01-31 07:29:18','2023-01-31 07:33:57'),(29,'default_mail','smtp',NULL,NULL,'mail',0,1,'2023-01-31 07:29:18','2023-01-31 07:29:18');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sns_subscriptions`
--

DROP TABLE IF EXISTS `sns_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sns_subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `confirm_url` text NOT NULL,
  `is_confirmed` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sns_subscriptions_brand_id_foreign` (`brand_id`),
  CONSTRAINT `sns_subscriptions_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sns_subscriptions`
--

LOCK TABLES `sns_subscriptions` WRITE;
/*!40000 ALTER TABLE `sns_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sns_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` VALUES (1,'status_deleted','','',NULL,NULL),(2,'status_processing','purple','campaign',NULL,NULL),(3,'status_sent','success','campaign',NULL,NULL),(4,'status_draft','warning','campaign',NULL,NULL),(5,'status_confirmed','primary','campaign',NULL,NULL),(6,'status_dynamic','','list',NULL,NULL),(7,'status_imported','','list',NULL,NULL),(8,'status_subscribed','success','subscriber',NULL,NULL),(9,'status_unsubscribed','purple','subscriber',NULL,NULL),(10,'status_blacklisted','secondary','subscriber',NULL,NULL),(11,'status_active','success','user',NULL,NULL),(12,'status_inactive','danger','user',NULL,NULL),(13,'status_invited','purple','user',NULL,NULL),(14,'status_sent','success','email',NULL,NULL),(15,'status_bounced','danger','email',NULL,NULL),(16,'status_delivered','info','email',NULL,NULL),(17,'status_active','success','brand',NULL,NULL),(18,'status_inactive','danger','brand',NULL,NULL);
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_category`
--

DROP TABLE IF EXISTS `sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_category`
--

LOCK TABLES `sub_category` WRITE;
/*!40000 ALTER TABLE `sub_category` DISABLE KEYS */;
INSERT INTO `sub_category` VALUES (1,'Sub Cat 1',1,1,'2023-07-10 10:49:07','2023-07-15 10:13:45'),(2,'Sub Cat 2',1,1,'2023-07-11 10:56:15','2023-07-11 10:56:15'),(3,'Cat 2 SUb',2,1,'2023-08-05 12:00:37','2023-08-05 12:00:37'),(4,'Cat 2 sub 2',2,1,'2023-08-05 12:00:49','2023-08-05 12:00:49');
/*!40000 ALTER TABLE `sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(160) NOT NULL,
  `status_id` bigint(20) unsigned NOT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscribers_brand_id_email_unique` (`brand_id`,`email`),
  KEY `subscribers_status_id_foreign` (`status_id`),
  KEY `subscribers_created_by_foreign` (`created_by`),
  CONSTRAINT `subscribers_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscribers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `subscribers_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers`
--

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject` text DEFAULT NULL,
  `default_content` longtext DEFAULT NULL,
  `custom_content` longtext DEFAULT NULL,
  `brand_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `templates_brand_id_foreign` (`brand_id`),
  KEY `templates_created_by_foreign` (`created_by`),
  KEY `templates_updated_by_foreign` (`updated_by`),
  CONSTRAINT `templates_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `templates_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (1,'teest',NULL,'<p><br />{brand_name}{app_link}</p>',NULL,1,NULL,'2023-06-08 02:45:50','2023-06-08 02:45:50');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_setting`
--

DROP TABLE IF EXISTS `tenant_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_token` varchar(100) NOT NULL,
  `kb_freeze` tinyint(4) NOT NULL DEFAULT 0,
  `course_freeze` tinyint(4) DEFAULT 0,
  `enterprise_support` tinyint(4) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_setting`
--

LOCK TABLES `tenant_setting` WRITE;
/*!40000 ALTER TABLE `tenant_setting` DISABLE KEYS */;
INSERT INTO `tenant_setting` VALUES (2,'WnTd5Ds4hzbxrfqJLA7Z',1,1,1,'2023-09-19 18:16:32'),(3,'zUPRXxnbemJCuhaVQA8r',1,0,0,'2023-09-20 17:22:29');
/*!40000 ALTER TABLE `tenant_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(80) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `types_alias_unique` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types`
--

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT INTO `types` VALUES (1,'App','app',NULL,NULL),(2,'Brand','brand',NULL,NULL);
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(160) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `status_id` bigint(20) unsigned NOT NULL,
  `invitation_token` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_status_id_foreign` (`status_id`),
  KEY `users_created_by_foreign` (`created_by`),
  CONSTRAINT `users_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'rootCapture\'s Enterprise','Administrator','admin@rootcapture.com','$2y$10$azV9d07FUkUXGWDqSYRRJu7GMwhZkwuPyWb7L4DVBkeRKu.SLUfDq',NULL,NULL,11,NULL,NULL,'2023-01-27 04:58:20','2023-01-27 04:58:20',NULL),(3,'cms','rootcapture','cms@mailinator.com','$2y$10$azV9d07FUkUXGWDqSYRRJu7GMwhZkwuPyWb7L4DVBkeRKu.SLUfDq',NULL,1,11,'Y21zQG1haWxpbmF0b3IuY29tLWludml0YXRpb24tZnJvbS11cw==',NULL,'2023-01-31 07:39:06','2023-02-14 04:58:23',NULL),(4,NULL,NULL,'dulgajvips@gmail.com',NULL,NULL,1,13,'ZHVsZ2Fqdmlwc0BnbWFpbC5jb20taW52aXRhdGlvbi1mcm9tLXVz',NULL,'2023-05-27 10:45:53','2023-05-27 10:45:53',NULL),(5,NULL,NULL,'test@gmail.com',NULL,NULL,1,13,'dGVzdEBnbWFpbC5jb20taW52aXRhdGlvbi1mcm9tLXVz',NULL,'2023-06-08 00:30:49','2023-06-08 00:30:49',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (1,'V - 1.0',1,'2023-08-06 09:00:24','2023-08-06 09:00:24'),(2,'V2.0',1,'2023-08-06 09:15:50','2023-08-06 09:15:50');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rootCapMailer'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-17 18:53:29
